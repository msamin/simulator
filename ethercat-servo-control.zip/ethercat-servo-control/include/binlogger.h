#ifndef BINLOGGER_H
#define BINLOGGER_H

#include <string>
#include <list>
#include <thread>
#include <mutex>
#include <ctime>
#include <chrono>

#pragma pack(4)
typedef struct {uint16_t transport, reserved;} T_2x16;
typedef struct {uint32_t start:1; uint32_t running:1; uint32_t ununsed:30;} T_U32;
typedef struct ST_BIN_MOTOR {
    int32_t speed_current;
    union {int32_t rawspeed_current; uint32_t dough_length;};
    int32_t speed_requested;
    union {uint32_t mstate_all; T_U32 mstate;};
    uint32_t status_sys, error_sys;
    uint32_t status_hw, error_hw;
    int32_t position;
    union {int32_t position_raw; T_2x16 u16;};
    int32_t torque;
    void clear() {
        speed_current = rawspeed_current = speed_requested = 0;
        mstate_all = 0;
        status_hw = error_hw = 0;
        status_sys = error_sys = 0;
        position = position_raw = 0;
        torque = 0;
    }
} tBINMOTOR;
typedef struct ST_BIN_LOG {
    uint16_t size;
    uint16_t recording:1;
    uint16_t btn_left:1;
    uint16_t btn_right:1;
    uint16_t btn_stop:1;
    uint16_t cage_opened:1;
    uint16_t trigger_hw:1;
    uint16_t trigger_sw:1;
    uint16_t trigger_filtered:1;
    uint16_t pause:1;
    uint16_t transport:1;
    uint16_t gap_reached:1;
    uint16_t unused:5;
    int64_t timestamp;
    uint32_t midstep;
    tBINMOTOR motor[4];
    void clear() {
        for(int i=0; i<4; i++) motor[i].clear();
        size = sizeof(struct ST_BIN_LOG);
        recording = 0;
        btn_left = btn_stop = btn_right = 0;
        cage_opened = 0;
        trigger_hw = trigger_sw = trigger_filtered = 0;
        timestamp = 0;
        midstep = 0;
    }
} tBINLOG;
#pragma pack()

class BinLogger
{
public:
    BinLogger();
    ~BinLogger();
    void exit();
    void endData();
    void addData(const tBINLOG &dta);

private:
    bool needExit;
    bool is_running;
    std::mutex mux;
    std::thread *thread;
    std::string dirName;
    std::string baseName;
    int currList;
    int elems_written;
    std::list<tBINLOG> list[2];
    void init(const std::string& dirname, const std::string& subdirname, const std::string& basename = "binfile");
    static void start(void *ptr);
    void run();
    void renameFiles();
};

#ifndef NO_BINDATA
extern BinLogger binlog;
#endif

#endif // BINLOGGER_H
