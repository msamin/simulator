#ifndef AVERAGE_H
#define AVERAGE_H

template<class T, class B, int N>
class Average
{
public:
    Average() {reset();}
    ~Average() {}
    void reset() {cnt = off = 0; sum = B(0);}
    void add(T v) {
        if(cnt==N) {
            // buffer full of data
            sum -= buf[off];
            buf[off] = v;
            if(off+1>=N) off = 0;
            else off++;
            sum += v;
        } else {
            // buffer not full
            buf[cnt] = v;
            sum += v;
            cnt++;
        }
    }
    T value() const {
        if(cnt==0) return T(0);
        return T(sum/cnt);
    }
private:
    int off,cnt;
    B sum;
    T buf[N];
};

#endif
