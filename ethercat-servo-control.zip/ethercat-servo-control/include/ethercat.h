#pragma once
#include <r88d_pdos.hpp>
#include <omron_constants.hpp>
#include <global_state.hpp>

#if NUMBER_MOTORS == 4
const static ec_pdo_entry_reg_t domain1_regs[] = {
    {0, 0, omron::vendor, omron::R88D_400W, 0x6040, 0x00, &offset[0].control,nullptr},             /* Controlword */
    {0, 0, omron::vendor, omron::R88D_400W, 0x60ff, 0x00, &offset[0].target_velocity,nullptr},     /* Target velocity */
    {0, 0, omron::vendor, omron::R88D_400W, 0x607a, 0x00, &offset[0].target_position,nullptr},     /* Target position */
    {0, 0, omron::vendor, omron::R88D_400W, 0x60fe, 0x01, &offset[0].digital_out,nullptr},         /* Digital Outputs */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6041, 0x00, &offset[0].status,nullptr},              /* Statusword */
    {0, 0, omron::vendor, omron::R88D_400W, 0x603f, 0x00, &offset[0].error,nullptr},               /* Error code */
    {0, 0, omron::vendor, omron::R88D_400W, 0x606c, 0x00, &offset[0].actual_velocity,nullptr},     /* Actual Velocity */
    {0, 0, omron::vendor, omron::R88D_400W, 0x606b, 0x00, &offset[0].target_velocity_raw,nullptr}, /* Velocity Demand (read only)*/
    {0, 0, omron::vendor, omron::R88D_400W, 0x6064, 0x00, &offset[0].position,nullptr},            /* Position actual value */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6062, 0x00, &offset[0].target_position_raw,nullptr}, /* Position demand (read only) */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6077, 0x00, &offset[0].torque,nullptr},              /* Torque actual value */
    {0, 0, omron::vendor, omron::R88D_400W, 0x4601, 0x81, &offset[0].digital_in,nullptr},          /* Digital inputs */
    {0, 1, omron::vendor, omron::R88D_750W, 0x6040, 0x00, &offset[1].control,nullptr},             /* Controlword */
    {0, 1, omron::vendor, omron::R88D_750W, 0x60ff, 0x00, &offset[1].target_velocity,nullptr},     /* Target velocity */
    {0, 1, omron::vendor, omron::R88D_750W, 0x607a, 0x00, &offset[1].target_position,nullptr},     /* Target position */
    {0, 1, omron::vendor, omron::R88D_750W, 0x60fe, 0x01, &offset[1].digital_out,nullptr},         /* Digital Outputs */
    {0, 1, omron::vendor, omron::R88D_750W, 0x6041, 0x00, &offset[1].status,nullptr},              /* Statusword */
    {0, 1, omron::vendor, omron::R88D_750W, 0x603f, 0x00, &offset[1].error,nullptr},               /* Error code */
    {0, 1, omron::vendor, omron::R88D_750W, 0x606c, 0x00, &offset[1].actual_velocity,nullptr},     /* Actual Velocity */
    {0, 1, omron::vendor, omron::R88D_750W, 0x606b, 0x00, &offset[1].target_velocity_raw,nullptr}, /* Velocity Demand (read only)*/
    {0, 1, omron::vendor, omron::R88D_750W, 0x6064, 0x00, &offset[1].position,nullptr},            /* Position actual value */
    {0, 1, omron::vendor, omron::R88D_750W, 0x6062, 0x00, &offset[1].target_position_raw,nullptr}, /* Position demand (read only) */
    {0, 1, omron::vendor, omron::R88D_750W, 0x6077, 0x00, &offset[1].torque,nullptr},              /* Torque actual value */
    {0, 1, omron::vendor, omron::R88D_750W, 0x4601, 0x81, &offset[1].digital_in,nullptr},          /* Digital inputs */
    {0, 2, omron::vendor, omron::R88D_400W, 0x6040, 0x00, &offset[2].control,nullptr},             /* Controlword */
    {0, 2, omron::vendor, omron::R88D_400W, 0x60ff, 0x00, &offset[2].target_velocity,nullptr},     /* Target velocity */
    {0, 2, omron::vendor, omron::R88D_400W, 0x607a, 0x00, &offset[2].target_position,nullptr},     /* Target position */
    {0, 2, omron::vendor, omron::R88D_400W, 0x60fe, 0x01, &offset[2].digital_out,nullptr},         /* Digital Outputs */
    {0, 2, omron::vendor, omron::R88D_400W, 0x6041, 0x00, &offset[2].status,nullptr},              /* Statusword */
    {0, 2, omron::vendor, omron::R88D_400W, 0x603f, 0x00, &offset[2].error,nullptr},               /* Error code */
    {0, 2, omron::vendor, omron::R88D_400W, 0x606c, 0x00, &offset[2].actual_velocity,nullptr},     /* Actual Velocity */
    {0, 2, omron::vendor, omron::R88D_400W, 0x606b, 0x00, &offset[2].target_velocity_raw,nullptr}, /* Velocity Demand (read only)*/
    {0, 2, omron::vendor, omron::R88D_400W, 0x6064, 0x00, &offset[2].position,nullptr},            /* Position actual value */
    {0, 2, omron::vendor, omron::R88D_400W, 0x6062, 0x00, &offset[2].target_position_raw,nullptr}, /* Position demand (read only) */
    {0, 2, omron::vendor, omron::R88D_400W, 0x6077, 0x00, &offset[2].torque,nullptr},              /* Torque actual value */
    {0, 2, omron::vendor, omron::R88D_400W, 0x4601, 0x81, &offset[2].digital_in,nullptr},          /* Digital inputs */
    {0, 3, omron::vendor, omron::R88D_100W, 0x6040, 0x00, &offset[3].control,nullptr},             /* Controlword */
    {0, 3, omron::vendor, omron::R88D_100W, 0x60ff, 0x00, &offset[3].target_velocity,nullptr},     /* Target velocity */
    {0, 3, omron::vendor, omron::R88D_100W, 0x607a, 0x00, &offset[3].target_position,nullptr},     /* Target position */
    {0, 3, omron::vendor, omron::R88D_100W, 0x60fe, 0x01, &offset[3].digital_out,nullptr},         /* Digital Outputs */
    {0, 3, omron::vendor, omron::R88D_100W, 0x6041, 0x00, &offset[3].status,nullptr},              /* Statusword */
    {0, 3, omron::vendor, omron::R88D_100W, 0x603f, 0x00, &offset[3].error,nullptr},               /* Error code */
    {0, 3, omron::vendor, omron::R88D_100W, 0x606c, 0x00, &offset[3].actual_velocity,nullptr},     /* Actual Velocity */
    {0, 3, omron::vendor, omron::R88D_100W, 0x606b, 0x00, &offset[3].target_velocity_raw,nullptr}, /* Velocity Demand (read only)*/
    {0, 3, omron::vendor, omron::R88D_100W, 0x6064, 0x00, &offset[3].position,nullptr},            /* Position actual value */
    {0, 3, omron::vendor, omron::R88D_100W, 0x6062, 0x00, &offset[3].target_position_raw,nullptr}, /* Position demand (read only) */
    {0, 3, omron::vendor, omron::R88D_100W, 0x6077, 0x00, &offset[3].torque,nullptr},              /* Torque actual value */
    {0, 3, omron::vendor, omron::R88D_100W, 0x4601, 0x81, &offset[3].digital_in,nullptr},          /* Digital inputs */
    {0,0,0,0,0,0,nullptr,nullptr}
};
/*#elif NUMBER_MOTORS == 1
const static ec_pdo_entry_reg_t domain1_regs[] = {
    {0, 0, omron::vendor, omron::R88D_200W, 0x6040, 0x00, &offset[0].control},             // Controlword
    {0, 0, omron::vendor, omron::R88D_200W, 0x60ff, 0x00, &offset[0].target_velocity},     // Target velocity
    {0, 0, omron::vendor, omron::R88D_200W, 0x607a, 0x00, &offset[0].target_position},     // Target position
    {0, 0, omron::vendor, omron::R88D_200W, 0x60fe, 0x01, &offset[0].digital_out},         // Digital Outputs
    {0, 0, omron::vendor, omron::R88D_200W, 0x6041, 0x00, &offset[0].status},              // Statusword
    {0, 0, omron::vendor, omron::R88D_200W, 0x603f, 0x00, &offset[0].error},               // Error code
    {0, 0, omron::vendor, omron::R88D_200W, 0x606c, 0x00, &offset[0].actual_velocity},     // Actual Velocity
    {0, 0, omron::vendor, omron::R88D_200W, 0x606b, 0x00, &offset[0].target_velocity_raw}, // Velocity Demand (read only)
    {0, 0, omron::vendor, omron::R88D_200W, 0x6064, 0x00, &offset[0].position},            // Position actual value
    {0, 0, omron::vendor, omron::R88D_200W, 0x6062, 0x00, &offset[0].target_position_raw}, // Position demand (read only)
    {0, 0, omron::vendor, omron::R88D_200W, 0x6077, 0x00, &offset[0].torque},              // Torque actual value
    {0, 0, omron::vendor, omron::R88D_200W, 0x4601, 0x81, &offset[0].digital_in},          // Digital inputs
    {0}
};*/
#elif NUMBER_MOTORS == 2
const static ec_pdo_entry_reg_t domain1_regs[] = {
    {0}
};
#else
  #error "NUMBER_MOTORS needs to be 2 or 4"
#endif

void check_domain1_state();
void check_master_state();
void check_slave_config_states();
void setup_master();

void initialize_devices();
void reset_device_parameters();
void setup_device_parameters();
void clearEcoStarStarupError();
void reboot(ec_slave_config_t *slave);

void configure_for_position_control(ec_slave_config_t *slave);
void configure_common_sdos(ec_slave_config_t *slave);
void configure_for_velocity_control(ec_slave_config_t *slave);
void write_to_flash(ec_slave_config_t *slave);
