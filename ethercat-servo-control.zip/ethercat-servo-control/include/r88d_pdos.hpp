#pragma once
#include "ecrt.h"

/* Master 0, Slave 0, "R88D-1SN04H-ECT"
 * Vendor ID:       0x00000083
 * Product code:    0x000000b0
 * Revision number: 0x00010001
 */

static ec_pdo_entry_info_t slave_0_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x60ff, 0x00, 32},
    {0x607a, 0x00, 32},
    {0x60fe, 0x01, 32},
    {0x6041, 0x00, 16},
    {0x603f, 0x00, 16},
    {0x606c, 0x00, 32},
    {0x606b, 0x00, 32},
    {0x6064, 0x00, 32},
    {0x6062, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x4601, 0x81, 32},
};

static ec_pdo_info_t slave_0_pdos[] = {
    {0x1600, 4, slave_0_pdo_entries + 0},
    {0x1a00, 8, slave_0_pdo_entries + 4},
};

static ec_sync_info_t slave_0_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_0_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_0_pdos + 1, EC_WD_DISABLE},
    {0xff, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE}
};

/* Master 0, Slave 1, "R88D-1SN08H-ECT"
 * Vendor ID:       0x00000083
 * Product code:    0x000000b1
 * Revision number: 0x00010001
 */

static ec_pdo_entry_info_t slave_1_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x60ff, 0x00, 32},
    {0x607a, 0x00, 32},
    {0x60fe, 0x01, 32},
    {0x6041, 0x00, 16},
    {0x603f, 0x00, 16},
    {0x606c, 0x00, 32},
    {0x606b, 0x00, 32},
    {0x6064, 0x00, 32},
    {0x6062, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x4601, 0x81, 32},
};

static ec_pdo_info_t slave_1_pdos[] = {
    {0x1600, 4, slave_1_pdo_entries + 0},
    {0x1a00, 8, slave_1_pdo_entries + 4},
};

static ec_sync_info_t slave_1_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_1_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_1_pdos + 1, EC_WD_DISABLE},
    {0xff, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE}
};

/* Master 0, Slave 2, "R88D-1SN04H-ECT"
 * Vendor ID:       0x00000083
 * Product code:    0x000000b0
 * Revision number: 0x00010001
 */

static ec_pdo_entry_info_t slave_2_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x60ff, 0x00, 32},
    {0x607a, 0x00, 32},
    {0x60fe, 0x01, 32},
    {0x6041, 0x00, 16},
    {0x603f, 0x00, 16},
    {0x606c, 0x00, 32},
    {0x606b, 0x00, 32},
    {0x6064, 0x00, 32},
    {0x6062, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x4601, 0x81, 32},
};

static ec_pdo_info_t slave_2_pdos[] = {
    {0x1600, 4, slave_2_pdo_entries + 0},
    {0x1a00, 8, slave_2_pdo_entries + 4},
};

static ec_sync_info_t slave_2_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_2_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_2_pdos + 1, EC_WD_DISABLE},
    {0xff, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE}
};

/* Master 0, Slave 3, "R88D-1SN01H-ECT"
 * Vendor ID:       0x00000083
 * Product code:    0x000000ae
 * Revision number: 0x00010000
 */

static ec_pdo_entry_info_t slave_3_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x60ff, 0x00, 32},
    {0x607a, 0x00, 32},
    {0x60fe, 0x01, 32},
    {0x6041, 0x00, 16},
    {0x603f, 0x00, 16},
    {0x606c, 0x00, 32},
    {0x606b, 0x00, 32},
    {0x6064, 0x00, 32},
    {0x6062, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x4601, 0x81, 32},
};

static ec_pdo_info_t slave_3_pdos[] = {
    {0x1600, 4, slave_3_pdo_entries + 0},
    {0x1a00, 8, slave_3_pdo_entries + 4},
};

static ec_sync_info_t slave_3_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, slave_3_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, slave_3_pdos + 1, EC_WD_DISABLE},
    {0xff, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE}
};
