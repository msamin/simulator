#pragma once
#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>
#include <nanomsg/reqrep.h>
#include <mutex>
#include <unistd.h>

#include <sheeter2020/servo.pb.h>

#include <r88d.hpp>
#include <global_state.hpp>
#include <ethercat.h>

void nanomsg_publish_loop();
void nanomsg_command_loop();
void handle_command(const sheeter2020::ServoCommandBatch& requests, sheeter2020::ServoReplyBatch& replies);
