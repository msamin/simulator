#pragma once

#include <omron_constants.hpp>
#include <unistd.h>

#include <cstdint>
#include <cassert>
#include <cstdio>

#include <map>
#include <atomic>

/* Collection of offsets for each PDO value
 * Describes the offset of the variable from the process domain pointer
 */

#if NUMBER_MOTORS == 2  //For EcoStar

//Address offset for EcoStar
#define errorStatus_PDO_offset 32
#define digitalInput0_PDO_offset 34
#define digitalInput1_PDO_offset 36
#define digitalOutput0_PDO_offset 38
#define digitalOutput1_PDO_offset 40

#define busCouplerPos 0, 0
#define errorStatus_PDO_entry  0x2002, 0x01

#define digitalInput0Pos 0, 1
#define digitalInput0_PDO_entry  0x6001, 0x01

#define digitalInput1Pos 0, 2
#define digitalInput1_PDO_entry  0x6021, 0x01

#define digitalOutput0Pos 0, 3
#define digitalOutput0_PDO_entry  0x7041, 0x01

#define digitalOutput1Pos 0, 4
#define digitalOutput1Bit0_PDO_entry  0x7060, 0x01
#define digitalOutput1Bit1_PDO_entry  0x7060, 0x02
#define digitalOutput1Bit2_PDO_entry  0x7060, 0x03
#define digitalOutput1Bit3_PDO_entry  0x7060, 0x04

#define gapMotorServoIndex 1
#define digitalInOutputServoIndex 0

typedef struct {
    uint8_t error = errorStatus_PDO_offset;

    uint8_t safty_guard = digitalInput0_PDO_offset;
    uint8_t left_button = digitalInput0_PDO_offset;
    uint8_t right_button = digitalInput0_PDO_offset;
    uint8_t stop_button = digitalInput0_PDO_offset;
    uint8_t laser_trigger = digitalInput0_PDO_offset;

    uint8_t gap_position = digitalInput1_PDO_offset;

    uint8_t left_motor_on = digitalOutput0_PDO_offset;
    uint8_t right_motor_on = digitalOutput0_PDO_offset;
    uint8_t roller_on = digitalOutput0_PDO_offset;
    uint8_t roller_to = digitalOutput0_PDO_offset;
    uint8_t left_coupling = digitalOutput0_PDO_offset;
    uint8_t right_coupling = digitalOutput0_PDO_offset;
    uint8_t brake = digitalOutput0_PDO_offset;

    uint8_t flour_duster = digitalOutput1_PDO_offset;
    uint8_t dough_reeler_close = digitalOutput1_PDO_offset;
    uint8_t dough_reeler_on = digitalOutput1_PDO_offset;
} offset_t;

#else

#define gapMotorServoIndex 3
#define digitalInOutputServoIndex 1

typedef struct {
    uint32_t control;
    uint32_t error;
    uint32_t status;
    uint32_t position;
    uint32_t target_position;
    uint32_t target_position_raw;
    uint32_t torque;
    uint32_t digital_in;
    uint32_t target_velocity;
    uint32_t target_velocity_raw;
    uint32_t actual_velocity;
    uint32_t digital_out;
} offset_t;

#endif

typedef struct {
    uint32_t error;

    uint8_t safty_guard;
    uint8_t left_button;
    uint8_t right_button;
    uint8_t stop_button;
    uint8_t laser_trigger;

    uint8_t drive_to_left_motor_on ;
    uint8_t drive_to_right_motor_on ;

    uint8_t roller_on;
    uint8_t roller_to;

    uint8_t left_coupling ;
    uint8_t right_coupling ;
    uint8_t brake;

    uint8_t flour_duster;
    uint8_t dough_reeler_close;
    uint8_t dough_reeler_on;

    uint8_t digitalOutput0;
    uint8_t digitalOutput1;

    uint8_t io_reeler_out4;
    uint8_t io_reeler_out5;

    //For Compass
    uint16_t status;
    int32_t target_position;
    int32_t target_position_raw;
    int32_t position;

    int16_t torque;
    int32_t target_velocity;
    int32_t target_velocity_raw;
    int32_t velocity;
    uint32_t digital_in;
    uint8_t servo_mode;
    uint32_t digital_out;
    uint8_t  digital_out_ext;
    uint16_t analog_in_ext;

} process_data_t;

typedef struct {

    //For EcoStar
    uint8_t flour_duster = 0;
    bool flour_duster_new = false;

    uint8_t dough_reeler_close = 0;
    bool dough_reeler_close_new = false;

    uint8_t dough_reeler_on = 0;
    bool dough_reeler_on_new = false;

    uint8_t brake = 0;
    bool brake_new = false;

    uint8_t io_reeler_out4 = 0;
    bool io_reeler_out4_new = false;

    uint8_t io_reeler_out5 = 0;
    bool io_reeler_out5_new = false;

    uint8_t io_leftCoupling_out6 = 0;
    bool io_leftCoupling_out6_new = false;

    uint8_t io_rightCoupling_out8 = 0;
    bool io_rightCoupling_out8_new = false;

    //For Compas
    int32_t target_velocity = 0;
    bool target_velocity_new = false;

    int32_t target_position = 0;
    //uint8_t target_position = 0;
    int target_position_new = 0;

    int32_t target_position_raw = 0;
    //uint8_t target_position = 0;
    bool target_position_raw_new = false;

    uint32_t digital_out = 0;
    bool digital_out_new = false;

    uint32_t control = 0x6; // STARTUP

} command_data_t;

namespace status {
    uint16_t remove_vendor_extension(uint16_t status);
    void read(uint16_t status);
}

#if NUMBER_MOTORS == 2
uint8_t gap_to_position(double gap);
double position_to_gap(uint8_t position);
#else
/** Convert a gap size in mm to a position value in ticks
 *  using a linear function defined by slope (same for all machines)
 *  and offset (calibrated at Rondos for every machine after construction)
 */
int32_t gap_to_position(double gap);

/** Convert a motor position in ticks to a gap size in mm
 *  using the inverse of the linear function as in gap_to_position()
 */
double position_to_gap(int32_t position);

#endif
