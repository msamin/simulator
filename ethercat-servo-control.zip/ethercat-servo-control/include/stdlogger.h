#ifndef STDLOGGER_H
#define STDLOGGER_H

#include <string>
#include <list>
#include <thread>
#include <mutex>
#include <ctime>
#include <chrono>

typedef struct ST_LOG_EVENT {int filehandle; std::chrono::time_point<std::chrono::system_clock> timestamp; std::string text;} tLOGEVENT;

class StdLogger
{
public:
    enum {TRACE=0, INFO=-1, WARN=-2, ALERT=-3, DBG=-4};
    StdLogger(const char *name);
    ~StdLogger();
    void init(const std::string& dirname, const std::string& subdirname, const std::string& basename = "logfile");
    void exit();
    void add(int filehandle, const std::string &text);
    void add(int filehandle, const std::string &text, const char *par, const char *suffix = nullptr);
    void add(int filehandle, const std::string &text, int par, const char *suffix = nullptr);
    void add(int filehandle, const std::string &text, unsigned int par, const char *suffix = nullptr);
    void fmt(const char* sfmt, ...);
    void fmt(FILE*, const char* sfmt, ...);
    void fmt(int lvl, const char* sfmt, ...);
    void save(const char *, const char*, ...) {}

private:
    std::mutex mux;
    bool needExit, is_running;
    std::string dirName;
    std::string baseName;
    int currList;
    int64_t writtenBytes;
    std::thread *thread;
    std::list<tLOGEVENT> list[2];

    static void start(void *ptr);
    void run();
    void renameFiles();
};

extern StdLogger logger;
extern StdLogger logServo;
extern StdLogger logMoves;
extern StdLogger logMotors;
#define printf logger.fmt
#define fprintf logger.fmt

#endif // STDLOGGER_H
