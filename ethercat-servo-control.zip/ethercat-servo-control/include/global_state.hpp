#pragma once
#include <r88d.hpp>
#include <ecrt.h>
#include <mutex>
#include <vector>
#include <array>
#include <atomic>

//#define NUMBER_MOTORS 4

// EtherCAT global variables
namespace ec {
    extern ec_master_t *master;
    extern ec_master_state_t master_state;

    extern ec_domain_t *domain1;
    extern ec_domain_state_t domain1_state;

    extern ec_slave_config_t*  sc_0;
    extern ec_slave_config_t*  sc_1;
    extern ec_slave_config_t*  sc_2;
    extern ec_slave_config_t*  sc_3;
    extern ec_slave_config_t*  sc_ext_0;
    extern ec_slave_config_t*  sc_ext_1;

    extern ec_slave_config_t*  sc_digiIn_0;
    extern ec_slave_config_t*  sc_digiIn_1;
    extern ec_slave_config_t*  sc_digiOut_0;
    extern ec_slave_config_t*  sc_digiOut_1;

    extern ec_slave_config_state_t sc_state_0;
    extern ec_slave_config_state_t sc_state_1;
    extern ec_slave_config_state_t sc_state_2;
    extern ec_slave_config_state_t sc_state_3;
    extern ec_slave_config_state_t sc_state_4;
    extern ec_slave_config_state_t sc_state_ext_0;
    extern ec_slave_config_state_t sc_state_ext_1;
}

// Global process data
extern uint8_t *domain1_pd;
extern process_data_t process_data[NUMBER_MOTORS];
extern process_data_t process_data_buffer[NUMBER_MOTORS];
extern std::array<std::atomic<uint32_t>, NUMBER_MOTORS> din_latch;
extern std::array<std::atomic<uint32_t>, NUMBER_MOTORS> dout_latch;
extern std::mutex lock_process_data[NUMBER_MOTORS];

// Global process data for extra coupler
extern process_data_t process_data_ext;
extern process_data_t process_data_buffer_ext;
extern std::mutex lock_process_data_ext;

// Global command data
extern command_data_t command_data[NUMBER_MOTORS];
extern std::mutex lock_command_data[NUMBER_MOTORS];

// offsets for PDO entries
extern offset_t offset[NUMBER_MOTORS];
