#ifndef SYSVARIABLE
# define SYSVARIABLE extern
# define SYSDEFAULT(x)
#else
# define SYSFUNCTION_DEFINE
# define SYSDEFAULT(x) = x
#endif

#define MAX_ACC_TRY 99

namespace SystemConfig {
  enum MachineType {COMPASS, RONDOSTAR, ECOSTAR};
  SYSVARIABLE MachineType typ;

  // depends of machine type
  SYSVARIABLE double speed100; // 1500(actualy it should be 1477.27) for compass, 1193.18 for RondoStar, 965.909 for EcoStar
  //SYSVARIABLE double gapsize_limit;
  SYSVARIABLE double autoreel_length;
  SYSVARIABLE double reel_length SYSDEFAULT(1400.0); // mm distance of manual reeler to table center (drum)
  SYSVARIABLE double cutomat_extra SYSDEFAULT(800.0); // mm extra more move beside table center

  //SYSVARIABLE bool transport SYSDEFAULT(false);
  SYSVARIABLE bool cutomat_exists SYSDEFAULT(false);
  SYSVARIABLE bool cutomat_at_right_side SYSDEFAULT(false);
  SYSVARIABLE bool autoreel_exists SYSDEFAULT(false);
  SYSVARIABLE bool autoreel_at_right_side SYSDEFAULT(true);
  SYSVARIABLE double autoreel_length_extra SYSDEFAULT(40.0);
  SYSVARIABLE bool manualreel_exists SYSDEFAULT(false);
  SYSVARIABLE bool manualreel_at_right_side SYSDEFAULT(false);
  SYSVARIABLE double manualreel_length_extra SYSDEFAULT(40.0);
  SYSVARIABLE bool transport_at_right_side SYSDEFAULT(false);
  SYSVARIABLE int stop_pos_long SYSDEFAULT(200);
  SYSVARIABLE int stop_pos_short SYSDEFAULT(20);
  SYSVARIABLE int stop_pos_fold SYSDEFAULT(300);
  SYSVARIABLE bool safe_stop SYSDEFAULT(false);
  SYSVARIABLE int trigger_ignore_ticks SYSDEFAULT(5000000);
  SYSVARIABLE bool drum_mode SYSDEFAULT(false);
  SYSVARIABLE bool dynamic_mode SYSDEFAULT(false);
  SYSVARIABLE double ticks2mm_belt SYSDEFAULT(329500.0);
  SYSVARIABLE double ticks2mm_drum SYSDEFAULT(329500.0);
  SYSVARIABLE double volume_factor SYSDEFAULT(100.0);
  SYSVARIABLE double runmode_factor SYSDEFAULT(1.136);
  SYSVARIABLE double runmode_factor_dynamic SYSDEFAULT(1.0);
  SYSVARIABLE double trigger_correction_ms SYSDEFAULT(195.0);
  SYSVARIABLE int rotate_side SYSDEFAULT(0);
  SYSVARIABLE int fold_side SYSDEFAULT(0);
  SYSVARIABLE double transp_length_before SYSDEFAULT(100.0);
  SYSVARIABLE double transp_length_extra SYSDEFAULT(40.0);
  SYSVARIABLE double transp_a SYSDEFAULT(1.0);
  SYSVARIABLE double transp_c SYSDEFAULT(0.0);
  enum TransportMode {NONE=0, FBT=1, TT_EU=2, TT_US=3};
  SYSVARIABLE TransportMode transport_mode SYSDEFAULT(TransportMode::NONE);
  SYSVARIABLE int stop_pos_correction SYSDEFAULT(200);
  SYSVARIABLE int stop_pos_correction_transfer SYSDEFAULT(200);
  SYSVARIABLE int flourduster_delay SYSDEFAULT(0);
  SYSVARIABLE double ecostar_speed_left SYSDEFAULT(7.5); // cm/s
  SYSVARIABLE double ecostar_speed_right SYSDEFAULT(7.5); // cm/s
  SYSVARIABLE double length_correction_constant SYSDEFAULT(-30.0); // mm
  SYSVARIABLE int ecostar_stop_delay SYSDEFAULT(650); // ms

#ifdef SYSFUNCTION_DEFINE
  SYSVARIABLE void init_system_config(SystemConfig::MachineType t) {
      if(t==SystemConfig::COMPASS && (SystemConfig::typ==SystemConfig::RONDOSTAR || SystemConfig::typ==SystemConfig::COMPASS)) {
          SystemConfig::typ = SystemConfig::COMPASS;
          //SystemConfig::gapsize_limit = 65.0;
          SystemConfig::speed100 = 1500.0; // 1477.27
          SystemConfig::autoreel_length = 1600.0;
          //if(opt_transport) SystemConfig::transport = true;
      } else if(t==SystemConfig::ECOSTAR && SystemConfig::typ==SystemConfig::ECOSTAR) {
          SystemConfig::typ = SystemConfig::ECOSTAR;
          //SystemConfig::gapsize_limit = 45.0;
          SystemConfig::speed100 = 965.909;
          SystemConfig::autoreel_length = 1300.0;
      } else if(SystemConfig::typ==SystemConfig::COMPASS || SystemConfig::typ==SystemConfig::RONDOSTAR) {
          SystemConfig::typ = SystemConfig::RONDOSTAR;
          //SystemConfig::gapsize_limit = 55.0;
          SystemConfig::speed100 = 1252.0; //1193.18;
          SystemConfig::autoreel_length = 1300.0;
      }
  }
  SYSVARIABLE void init_system_config() {
      SystemConfig::transport_mode = SystemConfig::TransportMode::NONE;
#ifdef NUMBER_MOTORS
#if NUMBER_MOTORS == 2
      char *mtype = "ECOSTAR";
      char *opt_transport_text = nullptr;
#else
      char *mtype = std::getenv("MACHINE_TYPE");
      char *opt_transport_text = std::getenv("OPT_TRANSPORT");
#endif
#else
      char *mtype = std::getenv("MACHINE_TYPE");
      char *opt_transport_text = std::getenv("OPT_TRANSPORT");
#endif
      bool opt_transport = opt_transport_text && opt_transport_text[0]=='1' && opt_transport_text[1] == 0;
      std::string mtp(mtype?mtype:"");
      if(mtp.compare("COMPASS")==0 || mtp.compare("COMPAS")==0) {
          SystemConfig::typ = SystemConfig::COMPASS;
          if(opt_transport) SystemConfig::transport_mode = SystemConfig::TransportMode::FBT;
      } else if(mtp.compare("ECOSTAR")==0) {
          SystemConfig::typ = SystemConfig::ECOSTAR;
      } else {
          SystemConfig::typ = SystemConfig::RONDOSTAR;
      }
      init_system_config(SystemConfig::typ);
  }
#else
  SYSVARIABLE void init_system_config();
  SYSVARIABLE void init_system_config(SystemConfig::MachineType t);
#endif
}
