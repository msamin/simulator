#ifndef SDO_WRITER_H
#define SDO_WRITER_H

#include <ecrt.h>

class SDOWriter {
public:
    SDOWriter();
    ~SDOWriter();
    bool init32(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr);
    bool init16(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr);
    bool init8(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr);
    bool start_write(uint value);
    bool check_write();

private:
    enum WriteStatus {ST_NEW, ST_BUSY, ST_READY};
    WriteStatus write_status;
    int m_addr, m_subaddr;
    size_t bytesize;
    uint m_value;
    int count;
    ec_sdo_request_t *req;
    bool init(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr, size_t size);
};

#endif // SDO_WRITER_H
