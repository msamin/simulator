#include <map>
#include <stdint.h>
#include <sstream>

namespace errors {
const std::map<uint16_t, std::string> known_errors  = {
    {0, "No Error"},
    {0x12, "Overvoltage Error"},
    {0x13, "Insufficient main power supply voltage"},
    {0x14, "Overcurrent Error"},
    {0x15, "Overheating Error"},
    {0x16, "Overload Error"},
    {0x18, "Regeneration Overload Error"},
    {0x20, "Runaway Detected"},
    {0x21, "Encoder communication error"},
    {0x24, "Excessive position deviation Error"},
    {0x26, "Excessive speed Error"},
    {0x27, "Absolute value cleared"},
    {0x28, "Pulse output overspeed Error"},
    {0x29, "Following Error counter overflow"},
    {0x33, "GPIO allocation duplicate"},
    {0x34, "Software Limit Exceeded"},
    {0x35, "FPGA WDT System Error"},
    {0x36, "Non-volatile memory data Error"},
    {0x37, "Non-volatile memory hardware Error"},
    {0x38, "Drive Prohibition Error"},
    {0x41, "Absolute encoder counter overflow Error"},
    {0x43, "Encoder memory Error"},
    {0x44, "1-Rotation counter Error"},
    {0x45, "Absolute encoder multi-rotation Error"},
    {0x47, "Overspeed Error"},
    {0x58, "Main circuit temperature monitoring failure"},
    {0x59, "Fan Error"},
    {0x62, "Control right release Error"},
    {0x70, "Safety Parameter Error"},
    {0x83, "General Ethercat Error"},
    {0x87, "Error Stop Input (ESTP)"},
    {0x88, "ESC initialization Error"},
    {0x90, "Mailbox/PDO/SyncManager Error"},
    {0x91, "Command Error"},
    {0x93, "Electronic gear setting error"},
    {0x94, "Function setting error"},
    {0x95, "Motor replacement detected"},
    {0x97, "Brake interlock Error"},
    // WARNINGS
    {0xA0, "Overload Warning"},
    {0xA1, "Regen. Overload Warning"},
    {0xA3, "Fan Rotation Warning"},
    {0xA4, "Encoder Communication Warning"},
    {0xA6, "Motor Wibration Warning"},
    {0xA7, "Lifetime Warning"},
    {0xAB, "Encoder Overflow Warning"},
    {0xB0, "Data Setting Warning"},
    {0xB1, "Command Warning"},
    {0xB2, "Communication Warning"}
};

inline std::string get_description(uint16_t error_code) {
    auto search = known_errors.find(error_code&0xFFu);
    if (search != known_errors.end()) {
        return search->second;
    }
    else {
        std::stringstream err;
        err << "Unrecognized Error code: 0x" << std::hex << error_code;
        return err.str();
    }
}
}
