#pragma once

#include <sheeter2020/servo.pb.h>

#include <chrono>
#include <atomic>

/* The index of the servo which has all the GPIOs
 * This will usually be the second servo (750W) with id == 1
 */

#if NUMBER_MOTORS == 2
constexpr int GPIO_IDX = 0;
constexpr int LEFT_BELT_IDX = 0;
constexpr int ROLLER_IDX = 2;
constexpr int RIGHT_BELT_IDX = 3;
constexpr int GAP_IDX = 1;
#else
constexpr int GPIO_IDX = 1;
constexpr int LEFT_BELT_IDX = 0;
constexpr int ROLLER_IDX = 1;
constexpr int RIGHT_BELT_IDX = 2;
constexpr int GAP_IDX = 3;
#endif

struct machine_interface_t {
    using clock = std::chrono::steady_clock;
    using time_point = std::chrono::time_point<clock>;
    using Status = sheeter2020::ServoStatusBatch;
    using Command = sheeter2020::ServoCommandBatch;

    machine_interface_t();
    ~machine_interface_t();

    Status wait_for_new_status();
    void send_servo_request(const Command &cmd);

    static bool is_safety_cage_open(const sheeter2020::ServoStatusBatch& newStatus);
    static bool is_stop_button_pressed(const sheeter2020::ServoStatusBatch &newStatus);
    bool is_stop_button_pressed() const;
    static bool is_left_button_pressed(const sheeter2020::ServoStatusBatch &newStatus);
    bool is_left_button_pressed() const;
    static bool is_right_button_pressed(const sheeter2020::ServoStatusBatch &newStatus);
    bool is_right_button_pressed() const;
    bool is_gapposition_reached();
    void set_infeed_percentage(int32_t newInfeed);
    void reset_all_servo_errors();
    bool turn_all_servos_on();
    void stop_all_servos();
    void turn_off_servo(const int index);
    void start_gapsize(const double gapsize_mm);
    void start_belts4cutomat(const int32_t velocity);
    void start_to_center(const int32_t velocity);
    void start_belts(const int32_t velocity, const bool flourduster, const double feedingSpeedFactor, const double extractionSpeedFactor);
    void change_belts_speed(const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor);
    //void start_transport_belt(const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor);
    void open_autohaspel();
    void close_autohaspel();
    void clear_ecostar_autohaspel_output();
    void stop_autohaspel();

    uint32_t current_rightbelt_position() const;
    uint32_t current_rightbelt_rawposition() const;
    uint32_t current_leftbelt_position() const;
    uint32_t current_leftbelt_rawposition() const;
    uint32_t current_drum_position() const;
    uint32_t current_drum_rawposition() const;
    int current_gapsize() const;
    int current_target_gapsize() const;
    int current_belts_direction() const {return m_current_belts_direction;}
    void change_duster(bool val);

private:
    int m_servo_cmd_s; // socket
    int m_servo_cmd_e; // endpoint
    int m_servo_status_s; // socket
    int m_servo_status_e; // endpoint

    int32_t m_current_rightbelt_position;
    int32_t m_current_rightbelt_rawposition;
    int32_t m_current_leftbelt_position;
    int32_t m_current_leftbelt_rawposition;
    int32_t m_current_drum_position;
    int32_t m_current_drum_rawposition;
    int m_current_belts_direction;
    int32_t m_infeed_percentage = 0;
    bool m_log_servo_delay;
    int servo_pause_ms;

    bool m_last_gapsize_reached;

    time_point m_ts_last_servo_status;
    time_point m_ts_current_servo_status;
    time_point m_ts_earliest_next_reset;    // prevent spamming the servo drive with reset commands
    time_point m_ts_earliest_next_turn_on;  // prevent spamming the servo drive with ON commands

    Status m_current_status;

    void set_speeds(Command& commands, const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor);
};
