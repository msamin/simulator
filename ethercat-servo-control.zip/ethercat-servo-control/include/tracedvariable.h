#ifndef TRACEDVARIABLE_H
#define TRACEDVARIABLE_H

#include <stdlogger.h>
#include <utility>

template<class T>
class TracedVariable
{
public:
    TracedVariable() : var(0), name("unknown_variable") {
        //traceme();
    }

    TracedVariable(T initvalue) : var(initvalue), name("unknown_variable") {
        //traceme();
    }

    TracedVariable(std::pair<T,const char*> initvalue) : var(initvalue.first), name(initvalue.second) {
        traceme();
    }

    inline void setName(const char *varname) {
        name = varname;
        traceme();
    }

    inline T& operator=(const T& value) {
        if(var != value) {
            var = value;
            traceme();
        }
        return var;
    }

    inline bool operator<(const T& value) {
        return var < value;
    }

    inline bool operator==(const T& val) {
        return var == val;
    }

    inline operator T() const {return var;}

private:
    T var = 0;
    const char *name;
    inline void traceme() {
        if(typeid(var)==typeid(int)) fprintf(StdLogger::TRACE,"###### var %s := %d", name, var);
        else if(typeid(var)==typeid(unsigned int)) fprintf(StdLogger::TRACE,"###### var %s := %u", name, var);
        else if(typeid(var)==typeid(bool)) fprintf(StdLogger::TRACE,"###### var %s := %s", name, var?"TRUE":"FALSE");
        else if(typeid(var)==typeid(double)) fprintf(StdLogger::TRACE,"###### var %s := %lf", name, var);
        else if(typeid(var)==typeid(float)) fprintf(StdLogger::TRACE,"###### var %s := %f", name, var);
        else fprintf(StdLogger::TRACE,"###### var %s := %d", name, int(var));
    }
};

#define TRACED_VAR(name, typ, startval) TracedVariable<typ> name = std::pair<typ,const char*>(startval,#name)
#define TRACED_VAR_NAME(name) name.setName(name)

#endif // TRACEDVARIABLE_H
