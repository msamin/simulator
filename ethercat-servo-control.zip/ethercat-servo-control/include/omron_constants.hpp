#pragma once
#include <stdio.h>
#include <stdint.h>

// Magic numbers for identifying omron devices on ethercat
namespace omron {
    // Omron R88D vendor + product identifiers
    constexpr uint16_t vendor = 0x00000083;

    // R88D-1SN01H-ECT 200V/100W ServoDrive
    constexpr uint16_t R88D_100W = 0x000000ae;

    // R88D-1SN02H-ECT 200V/200W ServoDrive
    constexpr uint16_t R88D_200W = 0x000000af;

    // R88D-1SN04H-ECT 200V/400W ServoDrive
    constexpr uint16_t R88D_400W = 0x000000b0;

    // R88D-1SN08H-ECT 200V/750W ServoDrive
    constexpr uint16_t R88D_750W = 0x000000b1;

    // ECC-201 Coupler
    constexpr uint16_t ECC_201 = 0x00000083;

    // Klemen vendor
    constexpr uint16_t klemen_vendor = 0x00000001;

    // Digital input ID4442
    constexpr uint16_t ID_4442 = 0x00114442;

    // Analog input AD2204
    constexpr uint16_t AD_2204 = 0x00212204;


    // Omron coupler and unit vendor + product identifiers
    constexpr uint16_t  coupler_vendor = 0x00000083;

    constexpr uint16_t  unit_vendor = 0x00000001;

    // Coupler prodict id
    constexpr uint16_t OMRON_ECC201 = 0x00000083;

    // Digital input id
    constexpr uint16_t OMRON_ID4442 = 0x00114442;

    // Ditital input id
    constexpr uint16_t OMRON_ID4342 = 0x00114342;

    // Digital output id
    constexpr uint16_t OMRON_OC4633 = 0x00144633;

    // digital output id
    constexpr uint16_t OMRON_OD3256 = 0x00133256;
}

namespace status_bit {
    // Single Bits that can be read from the status register (0x6041) in all modes
    // Some bits have different meanings, depending on the active mode:
    // for example bit 12 is both "setpoing acknowledged" in PP mode and "zero-speed" in pv mode
    enum :uint16_t {
        READY_SWITCH_ON    = (1u <<  0),
        SWITCHED_ON        = (1u <<  1),
        OPERATION_ENABLED  = (1u <<  2),
        FAULT              = (1u <<  3),
        VOLTAGE_ENABLED    = (1u <<  4),
        QUICKSTOP          = (1u <<  5),
        SWITCH_ON_DISABLED = (1u <<  6),
        WARNING            = (1u <<  7),
        PP_TARGET_REACHED  = (1u << 10),
        PV_TARGET_REACHED  = (1u << 10),
        HM_TARGET_REACHED  = (1u << 10),
        INTERNAL_LIMIT_ACT = (1u << 11),
        PP_SETPOINT_ACK    = (1u << 12),
        PV_ZERO_SPEED      = (1u << 12),
        HM_HOMING_ATTAINED = (1u << 12),
        PP_FOLLOW_ERROR    = (1u << 13),
        HM_HOMING_ERROR    = (1u << 13),
    };
}

namespace status {
    namespace mon {
        enum :uint32_t {
            MON1  = (1ul <<  0),
            MON2  = (1ul <<  1),
            MON3  = (1ul <<  2),
            MON4  = (1ul <<  3),
            MON5  = (1ul <<  4),
            MON6  = (1ul <<  5),
            MON7  = (1ul <<  6),
            MON8  = (1ul <<  7)
        };
    }

    namespace dout {
        enum :uint32_t {
            BKIR = (1ul << 0),
            OUT1 = (1ul << 16),
            OUT2 = (1ul << 17),
            OUT3 = (1ul << 18),
            GSEL = (1ul << 24),
        };
    }

    enum :uint16_t {
        NOT_READY          = 0x0,
        SWITCH_ON_DISABLED = status_bit::QUICKSTOP | status_bit::SWITCH_ON_DISABLED,
        READY_SWITCH_ON    = status_bit::QUICKSTOP | status_bit::READY_SWITCH_ON,
        SWITCHED_ON        = READY_SWITCH_ON | status_bit::SWITCHED_ON,
        OPERATION_ENABLED  = SWITCHED_ON | status_bit::OPERATION_ENABLED,
        FAULT_REACTION     = OPERATION_ENABLED | status_bit::FAULT,
        FAULT              = status_bit::QUICKSTOP | status_bit::FAULT
    };
}

namespace cmd_bit {
    enum :uint16_t {
        SWITCH_ON        = 0x01,
        ENABLE_VOLTAGE   = 0x02,
        QUICKSTOP        = 0x04,
        ENABLE_OPERATION = 0x08,

        // For Profile Position Mode (pp)
        NEW_SETPOINT     = 0x10,
        IMMEDIATE        = 0x20,
        ABSOLUTE         = 0x40,

        // For Profile Velocity Mode (pv)
        RESET            = 0x80,
        HALT             = 0x100
    };
}


namespace cmd {
    enum :uint16_t {
        RESET = cmd_bit::RESET,
        ENABLE_SYSTEM = 0x06, // This is from a DSP 420 Implementation Guide
        TURN_ON = cmd_bit::SWITCH_ON|cmd_bit::ENABLE_VOLTAGE|cmd_bit::QUICKSTOP| \
                  cmd_bit::ENABLE_OPERATION|cmd_bit::IMMEDIATE,
        TURN_OFF = cmd_bit::HALT,
        STOP = cmd_bit::HALT
    };
}
