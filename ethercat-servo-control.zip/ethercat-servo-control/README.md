# Rondo Sheeter2020 Servo Control System

This repository contains the software interfacing the servo motors of the Sheeter2020 using ethercat.

It depends on the code generated from the protobuf definition files in [the sheeter2020-comm repository](https://gitlab.virtualbaker.com/rondo/sheeter2020-comm), please install those first.

It also uses the user-space components of the [IgH EtherCAT Master for Linux](https://www.etherlab.org/en/ethercat/index.php).
We have a copy of the repository [here](https://gitlab.virtualbaker.com/rondo/etherlab-master).

## Important information for the `R88D-1SN0X` Servo development

### Wiring
The driver needs both 24V for the Controller and 230V / 400V for the Servo. The connectors are labeled L1, L3, 24V and 0V.

The CN1 connector has clamps for hardware-safety features. If you are not using these, place the orange short wires as described in the Manual (22+23, 24+26, 3+5, 6+7) otherwise the servo will NOT leave STO mode (Safety Torque Off).

### Ethercat
General process to interface with servo:

- Get etherlab master running, check engine is online with `ethercat slaves`
- Set engine to desired PDO Mapping using ethercat download (see below)
- Get C headers using `ethercat cstruct` and save to source file
- Put the process data that you want to read/write into your domain
- Setup master, domain, slaves, configuration and PDO mapping using etherlab API
- Run cyclic task that does
    * Read process data
    * Do something with data
    * Write process data

### State change Commands
These commands change the state of the driver's internal state machine.

#### Write
Control Word at `0x6040` with offset F1 is mapped into PDO

|  Bit  | Description             |
| ----- | ----------------------- |
|   0   | Switch on               |
|   1   | Enable voltage          |
|   2   | Quick stop              |
|   3   | Enable operation        |
|  4-6  | Operation mode specific |
|   7   | Fault reset             |
|   8   | Halt                    |
|   9   | Operation mode specific |
|  10   | Reserved                |
|  11   | P_CL                    |
|  12   | N_CL                    |
| 13-15 | Manufacturer specific   |

#### Examples
- Switch from `FAULT` to `SWITCH_ON_DISABLED`: 0x80 == `0b10000000`
- Switch from `SWITCH_ON_DISABLED` to `STATUS_READY_SWITCH_ON`: 0x06 == `0b110`
- Switch from `STATUS_READY_SWITCH_ON` to `STATUS_OPERATION_ENABLED`: 0x2F == `0b101111`
- Switch from `STATUS_OPERATION_ENABLED` to `SWITCH_ON_DISABLED`: 0x100 == `0b100000000`

#### Code
```C++
EC_WRITE_U16(domain1_pd + offset.control, 0x80);
```

### Modes of operation
Different modes of operation define what the target values are.
For testing, I am using Cyclic synchronous velocity mode (CSV) which disables profile
generation and directly follows a target velocity.
The mode can only be changed in `PREOP` mode!

#### Write
Control Word 0x6060

| Value  | Description                                   |
| ------ | --------------------------------------------- |
|   0    | Not specified                                 |
|   1    | Profile position mode (pp)                    |
|   3    | Profile velocity mode (pv) 6 Homing mode (hm) |
|   8    | Cyclic synchronous position mode (csp)        |
|   9    | Cyclic synchronous velocity mode (csv)        |
|   10   | Cyclic synchronous torque mode (cst)          |

#### Code
Set mode to CSV
```C++
ecrt_slave_config_sdo8(sc_r88d, 0x6060, 0, 0x9);
```

### PDO mappings
In order to read/write process data, sender and receiver have to use a common PDO mapping that defines the format of the process data. The PDO mapping is saved in the header file[info_r88d.h](include/info_r88d.h).

The R88D-1SN02H-ECT has multiple PDO mapping presets that contain different variables.
The variable `slave_0_pdos` contains the two addresses that MUST be used with this PDO mapping. Currently the output data is set to mapping `0x1702` and input data to `0x1B04`.
This corresponds to these mappings (i586-e1-04_r88m-1___r88d-1sn_-ect.pdf, page )

##### RxPDO: 259th receive PDO Mapping (0x1702)
- Controlword (0x6040)
- Target position (0x607A)
- Target velocity (0x60FF)
- Target torque (0x6071)
- Modes of operation (0x6060)
- Touch probe function (0x60B8)
- Max profile velocity (0x607F)

##### TxPDO: 261th trans- mit PDO Mapping (0x1B04)
- Error code (0x603F)
- Statusword (0x6041)
- Position actual value (0x6064)
- Torque actual value (0x6077)
- Modes of operation display (0x6061)
- Touch probe status (0x60B9)
- Touch probe 1 positive edge (0x60BA)
- Touch probe 2 positive edge (0x60BC)
- Digital inputs (0x60FD)
- Velocity actual value (0x606C)

The mappings are stored in 0x1c12:1 and 0x1c13:1. Both have an index 0 that acts as a write protection.

##### Manual Setup
To set the desired PDO mappings manually, you can use these commands
```
ethercat download 0x1c12 0 --type uint8 0
ethercat download 0x1c12 1 --type uint16 0x1702
ethercat download 0x1c12 0 --type uint8 1

ethercat download 0x1c13 0 --type uint8 0
ethercat download 0x1c13 1 --type uint16 0x1B04
ethercat download 0x1c13 0 --type uint8 1
```


#### Digital Outputs
60FE
 01 Physical Outputs (U32)
 02 Bit Mask (U32)

Bit 16: OUT1
Bit 17: OUT2
Bit 18: OUT3



# Calibration
Each machine should have the same ration of gap-servo shaft revolutions to change in gap size.
Calibration only has to compensate the offset of the absolute encoder value. By sending a "Home Offset"
value to index 0x607c, subindex 0x0, the "actual position" can be calibrated to 0 at a predefined state.
We will use a gapsize of 4mm for calibration, so every machine will have:

- a common slope of 14279107.0
- a common point of p(4mm) = 0 ticks

The calibration MUST be done with an open security cage to prevent any movement. When the cage is
open, it should be possible to move the gap to the pre-defined gapsize using an allan key.
Calibration MUST then be done BEFORE restarting ethercat master and BEFORE closing the security cage
to prevent unpredictable servo movement.
