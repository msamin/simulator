#!/bin/bash

RESTORE_FILE="recover_motorsettings.bash"

echo '#!/bin/bash' > $RESTORE_FILE
echo 'set -e'  >> $RESTORE_FILE
echo "/etc/init.d/servo-control stop" >> $RESTORE_FILE
echo 'sleep 3' >> $RESTORE_FILE

echo 'SERVOS="0 1 2 3"' >> $RESTORE_FILE
echo 'for p in $SERVOS; do
    echo "resetting to factory default"
    ethercat download -p ${p} 0x1011 0x1 --type octet_string load
done' >> $RESTORE_FILE
echo 'sleep 3' >> $RESTORE_FILE


maxGapVelocity=$(ethercat upload -p 3 0x3040 0xF1 --type int32)
maxGapVelocity=($maxGapVelocity)
maxGapVelocityHex=${maxGapVelocity[1]}
echo "current max gap velocity profile is $maxGapVelocityHex"

accGap=$(ethercat upload -p 3 0x3040 0xF3 --type int32)
accGap=($accGap)
accGapHex=${accGap[1]}
echo "current acc gap velocity profile is $accGapHex"

decGap=$(ethercat upload -p 3 0x3040 0xF4 --type int32)
decGap=($decGap)
decGapHex=${decGap[1]}
echo "current dec gap velocity profile is $decGapHex"

accLeft=$(ethercat upload -p 0 0x3021 0x01 --type uint32)
accLeft=($accLeft)
accLeftHex=${accLeft[1]}
echo "current acc left belt is $accLeftHex"

decLeft=$(ethercat upload -p 0 0x3021 0x02 --type uint32)
decLeft=($decLeft)
decLeftHex=${decLeft[1]}
echo "current dec left belt is $decLeftHex"


accDrum=$(ethercat upload -p 1 0x3021 0x01 --type uint32)
accDrum=($accDrum)
accDrumHex=${accDrum[1]}
echo "current acc drum belt is $accDrumHex"

decDrum=$(ethercat upload -p 1 0x3021 0x02 --type uint32)
decDrum=($decDrum)
decDrumHex=${decDrum[1]}
echo "current dec drum belt is $decDrumHex"

accRight=$(ethercat upload -p 2 0x3021 0x01 --type uint32)
accRight=($accRight)
accRightHex=${accRight[1]}
echo "current acc right belt is $accRightHex"

decRight=$(ethercat upload -p 2 0x3021 0x02 --type uint32)
decRight=($decRight)
decRightHex=${decRight[1]}
echo "current dec right belt is $decRightHex"


echo 'for p in $SERVOS; do
    echo "Setting up PDOs for servo $p"
    ethercat download -p ${p} 0x1600 0 --type uint8 0
    ethercat download -p ${p} 0x1600 1 --type uint32 0x60400010
    ethercat download -p ${p} 0x1600 2 --type uint32 0x60ff0020
    ethercat download -p ${p} 0x1600 3 --type uint32 0x607a0020
    ethercat download -p ${p} 0x1600 4 --type uint32 0x60fe0020
    ethercat download -p ${p} 0x1600 0 --type uint8 4
    ethercat download -p ${p} 0x1A00 0 --type uint8 0
    ethercat download -p ${p} 0x1A00 1 --type uint32 0x60410010
    ethercat download -p ${p} 0x1A00 2 --type uint32 0x603f0010
    ethercat download -p ${p} 0x1A00 3 --type uint32 0x606c0020
    ethercat download -p ${p} 0x1A00 4 --type uint32 0x606b0020
    ethercat download -p ${p} 0x1A00 5 --type uint32 0x60640020
    ethercat download -p ${p} 0x1A00 6 --type uint32 0x60620020
    ethercat download -p ${p} 0x1A00 7 --type uint32 0x60770010
    ethercat download -p ${p} 0x1A00 8 --type uint32 0x46010020
    ethercat download -p ${p} 0x1A00 0 --type uint8 8
    ethercat download -p ${p} 0x1c12 0 --type uint8 0
    ethercat download -p ${p} 0x1c12 1 --type uint16 0x1600
    ethercat download -p ${p} 0x1c12 0 --type uint8 1
    ethercat download -p ${p} 0x1c13 0 --type uint8 0
    ethercat download -p ${p} 0x1c13 1 --type uint16 0x1A00
    ethercat download -p ${p} 0x1c13 0 --type uint8 1
done

for p in ${SERVOS}; do
    echo "Setting up GPIOs for Servo $p"
    # Disable other GPIOS
    ethercat download -p${p} 0x4630 0x01 --type int32 0x00
    ethercat download -p${p} 0x4631 0x01 --type int32 0x00
    ethercat download -p${p} 0x4632 0x01 --type int32 0x00
    ethercat download -p${p} 0x4633 0x01 --type int32 0x00
    ethercat download -p${p} 0x4634 0x01 --type int32 0x00
    ethercat download -p${p} 0x4635 0x01 --type int32 0x00
    ethercat download -p${p} 0x4636 0x01 --type int32 0x00
    ethercat download -p${p} 0x4637 0x01 --type int32 0x00

    # IN 1: MON1
    ethercat download -p${p} 0x4638 0x01 --type int32 0x1
    ethercat download -p${p} 0x4638 0x02 --type int32 0x1

    # IN 2: MON2
    ethercat download -p${p} 0x4639 0x01 --type int32 0x2
    ethercat download -p${p} 0x4639 0x02 --type int32 0x0

    # IN 3: MON3
    ethercat download -p${p} 0x463A 0x01 --type int32 0x3
    ethercat download -p${p} 0x463A 0x02 --type int32 0x0

    # IN 4: MON4
    ethercat download -p${p} 0x463B 0x01 --type int32 0x4
    ethercat download -p${p} 0x463B 0x02 --type int32 0x1

    # IN 5: MON5
    ethercat download -p${p} 0x463C 0x01 --type int32 0x5
    ethercat download -p${p} 0x463C 0x02 --type int32 0x0

    # IN 6: MON6
    ethercat download -p${p} 0x463D 0x01 --type int32 0x6
    ethercat download -p${p} 0x463D 0x02 --type int32 0x0

    # IN 7: MON7
    ethercat download -p${p} 0x463E 0x01 --type int32 0x7
    ethercat download -p${p} 0x463E 0x02 --type int32 0x0   # do not Invert!

    # IN 8: MON8
    ethercat download -p${p} 0x463F 0x01 --type int32 0x8
    ethercat download -p${p} 0x463F 0x02 --type int32 0x0

    # Output functions - Bitmask:
    # 1. Enable Remote Outputs 1,2,3: R-OUT1, R-OUT2, R-OUT3
    # 2. Disable gain switching (G-SEL)
    # 3. Disable Brake Interlock Output (BKIR)
    ethercat download -p${p} 0x4602 0x01 --type uint32 0x00070000

    # Error Output Disable
    ethercat download -p${p} 0x4650 0x01 --type int32 0x00

    # Servo Ready Disable
    ethercat download -p${p} 0x4651 0x01 --type int32 0x0

    # R-OUT 1: Port selection: OUT1 (0x01)
    ethercat download -p${p} 0x465C 0x01 --type int32 0x01
    # R-OUT 1: Logic selection: 0 == NO
    ethercat download -p${p} 0x465C 0x02 --type int32 0x00

    # R-OUT 2: Port selection: OUT2 (0x02)
    ethercat download -p${p} 0x465D 0x01 --type int32 0x02
    # R-OUT 2: Logic selection: 0 == NO
    ethercat download -p${p} 0x465D 0x02 --type int32 0x00

    # R-OUT 3: Port selection: OUT3 (0x04)
    ethercat download -p${p} 0x465E 0x01 --type int32 0x04
    # R-OUT 3: Logic selection: 0 == NO
    ethercat download -p${p} 0x465E 0x02 --type int32 0x00
done

for p in ${SERVOS}; do
    # Set first order IIR filter for acceleration/deceleration
    # only applies to velocity modes
    acc_val=50
    decc_val=50

    ethercat download -p ${p} 0x3021 0x3 --type int32 0x1
    ethercat download -p ${p} 0x3021 0x4 --type int32 0xc350

    # Set first order FIR filter for position control
    ethercat download -p ${p} 0x3011 0x1 --type uint32 0x1
    ethercat download -p ${p} 0x3011 0x2 --type uint32 1000
    ethercat download -p ${p} 0x3011 0x3 --type uint32 0x0
    ethercat download -p ${p} 0x3011 0x4 --type uint32 0x10

    # Disable brakes on stop/fault
    # 0 is free run
    # -5 is deceleration stop torque + dynamic brakes
    ethercat download -p ${p} 0x3b20 0x1 --type uint16 0x0
    ethercat download -p ${p} 0x3b20 0x2 --type uint16 0x0
    ethercat download -p ${p} 0x3b20 0x4 --type uint16 0x0

    # Disable all drive software position prohibitions
    ethercat download -p ${p} 0x3b11 0x1 --type uint32 0x0

    echo "Set maximum torque"
    ethercat download -p ${p} 0x6072 0x00 --type uint16 0x1388

    echo "Set maximum profile velocity to ~100%"
    ethercat download -p ${p} 0x6081 0x00 --type uint32 0x7fffffff

    echo "Set maximum acceleration to 100%"
    ethercat download -p ${p} 0x6083 0x00 --type uint32 0x7fffffff

    echo "Set maximum deceleration to 100%"
    ethercat download -p ${p} 0x6084 0x00 --type uint32 0x7fffffff

done

echo "Enable software limits for gap servo"
ethercat download -p 3 0x3b11 0x1 --type int32 0x0
ethercat download -p 3 0x3b11 0x2 --type int32 0x2
ethercat download -p 3 0x3b11 0x3 --type int32 0x17dc2a73
ethercat download -p 3 0x3b11 0x4 --type int32 0x4e129b3f

echo "Set position command gain for gap servo"
ethercat download -p 3 0x3120 0x1 --type int32 5000

echo "Set position following error window for gap servo to the maximum, effectively disabling follow erro check for gap servo"
ethercat download -p3 0x3B50 0x05 --type uint32 0xffffffff' >> $RESTORE_FILE


echo 'echo "write back the stored acc dec for gap motor"'>> $RESTORE_FILE

echo "ethercat download -p 3 0x3040 0xF1 --type int32 $maxGapVelocityHex" >> $RESTORE_FILE
echo "ethercat download -p 3 0x3040 0xF3 --type int32 $accGapHex" >> $RESTORE_FILE
echo "ethercat download -p 3 0x3040 0xF4 --type int32 $decGapHex" >> $RESTORE_FILE

echo 'echo "write back the stored acc dec for belt motors"'>> $RESTORE_FILE
echo "ethercat download -p 0 0x3021 0x01 --type int32 $accLeftHex" >> $RESTORE_FILE
echo "ethercat download -p 0 0x3021 0x02 --type int32 $decLeftHex" >> $RESTORE_FILE

echo "ethercat download -p 2 0x3021 0x01 --type int32 $accRightHex" >> $RESTORE_FILE
echo "ethercat download -p 2 0x3021 0x02 --type int32 $decRightHex" >> $RESTORE_FILE

echo 'echo "write back the stored acc dec for drum motors"'>> $RESTORE_FILE
echo "ethercat download -p 1 0x3021 0x01 --type int32 $accDrumHex" >> $RESTORE_FILE
echo "ethercat download -p 1 0x3021 0x02 --type int32 $decDrumHex" >> $RESTORE_FILE

echo 'echo "Disabling the motor brake for all servos"
for p in $SERVOS; do
    ethercat download -p ${p} -t int32 0x4610 0x01 0x00
done

echo "Disable runaway error"
ethercat download -p3 0x3B71 0x01 --type int32 0 || true # Prevent failing on older servo drives

echo "Saving to non volatile flash"
for p in ${SERVOS}; do
    ethercat download -p ${p} 0x1010 0x1 --type octet_string save
done

echo "waiting for write to complete"
sleep 10

for p in ${SERVOS}; do
    ethercat download -p ${p} 0x2400 0x1 --type octet_string tesera
done' >> $RESTORE_FILE

echo 'sleep 5' >> $RESTORE_FILE

echo "/etc/init.d/servo-control restart" >> $RESTORE_FILE
echo 'sleep 3' >> $RESTORE_FILE

chmod 770 $RESTORE_FILE


