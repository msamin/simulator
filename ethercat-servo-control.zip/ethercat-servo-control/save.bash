#!/bin/bash

ethercat download -p0 0x1010 0x01 --type octet_string save
ethercat download -p1 0x1010 0x01 --type octet_string save
ethercat download -p2 0x1010 0x01 --type octet_string save
ethercat download -p3 0x1010 0x01 --type octet_string save
