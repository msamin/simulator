# Sysmac Studio Drive Configuration XML Files

This folder contains XML files with a complete ethercat slave configuration description exported from the Sysmac Studio Drive Edition software.

They contain the complete configuration of a servo drive and can be loaded on other drives for debugging etc.
