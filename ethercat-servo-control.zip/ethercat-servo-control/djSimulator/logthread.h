#ifndef LOGTHREAD_H
#define LOGTHREAD_H

#include <QThread>
#include <QMutex>
#include <QList>
#include <QHash>
//#include "logmodel.h"

typedef struct ST_TLOG_EVENT {int filehandle; qint64 timestamp; QString text;} tMAINLOGEVENT;

class LogThread : public QThread
{
    Q_OBJECT
public:
    enum {TRACE=0, INFO=-1, WARN=-2, ALERT=-3, DBG=-4};
    explicit LogThread(QObject *parent = 0);
    ~LogThread();
    void init(const QString& dirname, const QString& subdirname, const QString& basename = "logfile");
    void exit();
    void add(int fhandle, const QString &text);
    void save(const char *filenr, const char *buf);

    //LogModel mdl;
    enum
    {
        timeRole = Qt::DisplayRole,
        descrRole = Qt::UserRole+1
    };
    QHash<int, QByteArray> names;

private:
    QMutex mux;
    bool needExit;
    QString dirName;
    QString baseName;
    int currList;
    qint64 writtenBytes;
    QList<tMAINLOGEVENT> list[2];

    void run();
    void renameFiles();

signals:

public slots:

};

#endif // LOGTHREAD_H
