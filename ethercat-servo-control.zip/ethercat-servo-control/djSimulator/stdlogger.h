#ifndef STDLOGGER_H
#define STDLOGGER_H

#include <string>
#include <list>
#include <thread>
#include <mutex>
#include <ctime>

class StdLogger
{
public:
    enum {TRACE=0, INFO=-1, WARN=-2, ALERT=-3, DBG=-4};
    StdLogger(const char *name = nullptr);
    ~StdLogger();
    void init(const std::string& dirname, const std::string& subdirname, const std::string& basename = "logfile");
    void exit();
    void add(int filehandle, const std::string &text);
    void add(int filehandle, const std::string &text, const char *par, const char *suffix = nullptr);
    void add(int filehandle, const std::string &text, int par, const char *suffix = nullptr);
    void add(int filehandle, const std::string &text, unsigned int par, const char *suffix = nullptr);
    void fmt(const char* sfmt, ...);
    void fmt(FILE*, const char* sfmt, ...);
    void fmt(int lvl, const char* sfmt, ...);
    void save(const char *filenr, const char* sfmt, ...);

private:
    std::mutex mux;
    bool needExit, is_running;
    std::string dirName;
    std::string baseName;
    int currList;
    int64_t writtenBytes;
    std::thread *thread;
    const char *logname;

    static void start(void *ptr);
    void run();
    void renameFiles();
};

extern StdLogger logger;
extern StdLogger logServo;
extern StdLogger logMoves;
#ifndef NO_DEF_PRINTF
#define fprintf logger.fmt
#define printf logger.fmt
#endif

#endif // STDLOGGER_H
