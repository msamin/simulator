#ifndef RECIPEINTERPRETERBRIDGE_H
#define RECIPEINTERPRETERBRIDGE_H

#include <QObject>

class RecipeInterpreterBridge : public QObject
{
    Q_OBJECT
public:
    RecipeInterpreterBridge(QObject *parent = nullptr);
    void start();
    void stop();
};

#endif // RECIPEINTERPRETERBRIDGE_H
