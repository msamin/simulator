#include "logthread.h"
#include <QMutexLocker>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QDateTime>
#include <QStringList>
#include <QStandardItem>
#include <QList>
#include <iostream>

#define MAX_WRITTEN_BYTES 100000LL

LogThread::LogThread(QObject *parent) :
    QThread(parent)
{
    needExit = false;
    currList = 0;
    writtenBytes = 0;

    names[timeRole] = "time";
    names[descrRole] = "descr";
    /*mdl.setItemRoleNames(names);
    mdl.setColumnCount(2);
    mdl.setHorizontalHeaderLabels(QStringList()<<"time"<<"description");

    mdl.log(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"), "Hello world");*/
}

LogThread::~LogThread()
{
    exit();
}

void LogThread::init(const QString &dirname, const QString& subdirname, const QString& basename)
{
    if(!dirname.isEmpty() && !subdirname.isEmpty())
    {
        baseName = basename;
        dirName = dirname.trimmed() + "/" + subdirname;
        QDir(dirname).mkpath(subdirname);

        renameFiles();
        writtenBytes = 0;

        add(INFO, "program started");

        start();
    }
}

void LogThread::renameFiles()
{
    QFile f(dirName + QString("/%1%2.log").arg(baseName).arg(9));
    if(f.exists()) f.remove();
    for(int i=8; i>=0; i--)
    {
        f.setFileName(dirName + QString("/%1%2.log").arg(baseName).arg(i));
        if(f.exists()) f.rename(dirName + QString("/%1%2.log").arg(baseName).arg(i+1));
    }
}

void LogThread::exit()
{
    if(!needExit)
    {
        add(INFO, "program stopped");
        needExit = true;

        if(isRunning())
        {
            wait(5000);
        }
    }
}

void LogThread::run()
{
    while(true)
    {
        mux.lock();
        int idx = currList;
        currList = (currList+1)&1;
        mux.unlock();

        if(list[idx].size()>0)
        {
            QFile logFile(dirName + QString("/%1%2.log").arg(baseName).arg(0));
            QTextStream logStream;
            QString txt;
            foreach(const tMAINLOGEVENT &data, list[idx])
            {
                qint64 t_bin = data.timestamp;
                QDateTime t = QDateTime::fromMSecsSinceEpoch(t_bin);
                QString t_str = QString("%1-%2-%3 %4:%5:%6.%7 ")
                        .arg(t.date().year(),4,10,QChar('0'))
                        .arg(t.date().month(),2,10,QChar('0'))
                        .arg(t.date().day(),2,10,QChar('0'))
                        .arg(t.time().hour(),2,10,QChar('0'))
                        .arg(t.time().minute(),2,10,QChar('0'))
                        .arg(t.time().second(),2,10,QChar('0'))
                        .arg(t.time().msec()%1000,3,10,QChar('0'))
                        ;

                if(!logFile.isOpen())
                {
                    if(logFile.open(QFile::Append | QFile::Text))
                    {
                        logStream.setDevice(&logFile);
                        logStream.setCodec("UTF-8");
                        //lastDay = t.date().day();
                    }
                }

                if(logFile.isOpen())
                {
                    //QStringList lst = data.text.split("\n");
                    QString txt1 = data.text;
                    txt1.replace("\n","\\n");
                    const char *grp;
                    switch(data.filehandle) {
                    case 1: grp = "[stdout] "; break;
                    case 2: grp = "[stderr] "; break;
                    case INFO: grp = "[info] "; break;
                    case WARN: grp = "[warning] "; break;
                    case ALERT: grp = "[critical] "; break;
                    case DBG: grp = "[debug] "; break;
                    case TRACE: grp = "[trace] "; break;
                    default: grp = "[unknown] "; break;
                    }
                    //foreach (const QString txt1, lst) {
                        txt = t_str + grp + txt1 + "\n";
                        logStream << txt;
#if defined(__x86_64__) && defined(QT_DEBUG)
                        std::cout << txt.toStdString(); std::cout.flush();
#endif
                        writtenBytes += txt.length();
                        //mdl.log(t.toString("yyyy-MM-dd hh:mm:ss"), txt1);
                    //}
                }
            }

            if(logFile.isOpen())
            {
                logStream.flush();
                logFile.close();

                /*if(writtenBytes>MAX_WRITTEN_BYTES)
                {
                    renameFiles();
                    writtenBytes = 0;
                }*/
            }
            list[idx].clear();
            this->usleep(50);
        }
        else
        {
            if(needExit) break;
            this->usleep(200);
        }
    }
}

void LogThread::add(int fhandle, const QString &text)
{
    QMutexLocker lock(&mux);
    qint64 t = QDateTime::currentMSecsSinceEpoch();
    tMAINLOGEVENT ev;
    //QStringList lst = text.split("\n");
    //foreach (const QString txt, lst) {
        ev.filehandle = fhandle;
        ev.timestamp = t;
        ev.text = text;
        list[currList].append(ev);
    //}
    Q_UNUSED(lock);
}

void LogThread::save(const char *filenr, const char *buf)
{
#ifdef __x86_64__
    QFile f(QString("%1/status-%2.log").arg(dirName).arg(filenr?filenr:"unknown"));
    if(f.open(QFile::Text|QFile::WriteOnly|QFile::Truncate)) {
        f.write(buf);
        f.close();
    }
#endif
}
