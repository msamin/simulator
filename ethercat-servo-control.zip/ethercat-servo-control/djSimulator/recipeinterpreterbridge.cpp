#include "recipeinterpreterbridge.h"
#include <recipe_interpreter.hpp>

#include <thread>

RecipeInterpreterBridge::RecipeInterpreterBridge(QObject *parent) : QObject(parent)
{
}

/*extern bool needRecipeInterpreterExit;
extern uint32_t cntRcvServoStatus;
extern uint32_t cntSndServoCmd;
extern uint32_t cntRcvServoCmd;
extern uint32_t cntRcvMoveCmd;
extern uint32_t cntSndMoveStatus;
extern uint32_t cntSndMoveCmd;*/

void RecipeInterpreterBridge::start()
{
    new std::thread(interpreter_loop);
}

void RecipeInterpreterBridge::stop()
{
    /*if(!needRecipeInterpreterExit) {
        needRecipeInterpreterExit = true;
        qDebug("ServoStatus(R):%u ServoCmd(SR):%u/%u MoveCmd(SR):%u/%u MoveStatus(S):%u",
               cntRcvServoStatus, cntSndServoCmd, cntRcvServoCmd, cntSndMoveCmd, cntRcvMoveCmd, cntSndMoveStatus);
    }*/
}
