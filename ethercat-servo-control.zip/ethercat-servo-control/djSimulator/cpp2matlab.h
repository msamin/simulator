#ifndef CPP2MATLAB_H
#define CPP2MATLAB_H
#include <fstream>
#include <iostream>
using namespace std;

class cpp2matlab
{
public:
    cpp2matlab();
        ofstream myfile;

        void write2file(int motor_id, int motor_vel);



        ~cpp2matlab();
};

#endif // CPP2MATLAB_H
