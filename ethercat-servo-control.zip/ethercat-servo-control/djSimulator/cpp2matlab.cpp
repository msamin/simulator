#include "cpp2matlab.h"
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>


cpp2matlab::cpp2matlab()
{

    //writing for once in the text file

   // myfile.open("/home/muhammad-precibake/Desktop/cpp2matlab.dat");


    //appending the file with new content in the end

   myfile.open("/home/muhammad-precibake/Desktop/cpp2matlab.dat", fstream::app);



    //---------------------------------------------


}

void cpp2matlab::write2file(int motor_id, int motor_vel)

{
    time_t now;
    struct tm nowLocal;
    now=time(NULL);
   nowLocal = *localtime(&now);

   myfile << nowLocal.tm_mday <<nowLocal.tm_mon+1<<nowLocal.tm_year+1900<<"  "<<nowLocal.tm_hour<<nowLocal.tm_min<<nowLocal.tm_sec<<" ; "<<motor_id<<" ; "<<motor_vel<<"\n";

//   myfile << nowLocal.tm_mday << "; " << new_account.name_owner << "; " << new_account.amount_avail;



}


cpp2matlab::~cpp2matlab()
{
        myfile.close();

}
