#include "mainwindow.h"
#include <QApplication>

#define SYSVARIABLE
#include <systemconfig.h>

#include "logthread.h"
LogThread mainlogger;
#include <stdlogger.h>
StdLogger logger;
StdLogger logServo("servcmd");
StdLogger logMoves("moves");

static void myMessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    Q_UNUSED(context);
    //Q_UNUSED(msg);

    int tp = 1;
    switch(type) {
    case QtMsgType::QtInfoMsg: tp = LogThread::INFO; break;
    case QtMsgType::QtWarningMsg: tp = LogThread::WARN; break;
    case QtMsgType::QtCriticalMsg: tp = LogThread::ALERT; break;
    case QtMsgType::QtDebugMsg: tp = LogThread::DBG; break;
    case QtMsgType::QtFatalMsg: tp = LogThread::ALERT; break;
    }
    mainlogger.add(tp, msg);
}

int main(int argc, char *argv[])
{
    int ret = 0;

    // set SYSTEM CONFIGURATION
    SystemConfig::init_system_config();

    QApplication app(argc, argv);

#ifdef __x86_64__not_always_working
    // assure only one app is running
    QTcpSocket appLock;
    if(!appLock.bind(QHostAddress::LocalHost,8085)) {
        QString err = appLock.errorString();
        qDebug("simulator already running or network error !!! (%s)",err.toLocal8Bit().constData());
        return 0;
    }
#endif

    qDebug("LOG file in %s/LOG",app.applicationDirPath().toLocal8Bit().constData());
    mainlogger.init(app.applicationDirPath(),"LOG");
    qInstallMessageHandler(myMessageOutput);

    //app.setApplicationDisplayName("Sheeter2020 Simulator");
    app.setOrganizationName("PreciBake");
    //app.setWindowIcon(QIcon(":/pics/main_icon.svg"));

    MainWindow w;
    w.setWindowTitle("Sheeter2020 Simulator");
    w.setWindowIcon(QIcon(":/pics/main_icon.svg"));
    w.show();
    ret = app.exec();

    qInstallMessageHandler(nullptr);
    return ret;
}
