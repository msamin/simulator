#include "simulatorform.h"
#include "ui_simulatorform.h"
#include <QMouseEvent>
#include <QWheelEvent>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QPainter>
#include <QPen>
#include <QDateTime>
#include <QPolygon>
#include <systemconfig.h>
#include <qmath.h>



#include "cpp2matlab.h"


#define START_DOUGH_WIDTH 400.0 // mm
#define NEXT_DOUGH_WIDTH 650.0 // mm

SimulatorForm::SimulatorForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SimulatorForm)
{
    ui->setupUi(this);

    w_dough = START_DOUGH_WIDTH;
    btnwidth = 40;
    transportDir = 0;
    transportValue = 0;
    transportSignal = false;
    pressButton = 0;
    duster = reel.close = reel.on = trigger = false;
    reel.angle = 0.0;
    reel.close = true;
    turnedOn = true;
    table_length = 1600.0; // mm
    tickcnt = 0;
    gap = 45.0;
    vol = gap*w_dough*300; // mm*mm
    dough_pos = -1000.0; // center=0.0
    dough_len = vol / gap / w_dough;

    qsrand(uint(QDateTime::currentMSecsSinceEpoch()));
    for(int i=0; i<4; i++) {
        motor[i].speed = 0;
        if(i!=3) motor[i].pos = quint32(qrand());
        motor[i].dash = 0;
    }
    motor[3].pos = quint32(qRound(gap*10.0));

    servoRecipe = new ServoCommandServer("127.0.0.1");
    servoRecipe->setMotorPosition(0,motor[0].pos);
    servoRecipe->setMotorPosition(1,motor[1].pos);
    servoRecipe->setMotorPosition(2,motor[2].pos);
    servoMovementsBridge = new RecipeInterpreterBridge();

    connect(servoRecipe, &ServoCommandServer::drumDriveSpeedChanged, this, &SimulatorForm::on_speed_drum);
    connect(servoRecipe, &ServoCommandServer::leftBeltSpeedChanged, this, &SimulatorForm::on_speed_left);
    connect(servoRecipe, &ServoCommandServer::rightBeltSpeedChanged, this, &SimulatorForm::on_speed_right);
    connect(servoRecipe, &ServoCommandServer::outFlourDusterChanged, this, &SimulatorForm::on_duster);
    connect(servoRecipe, &ServoCommandServer::outReelerMoveChanged, this, &SimulatorForm::on_reeler_go);
    connect(servoRecipe, &ServoCommandServer::outReelerCloseChanged, this, &SimulatorForm::on_reeler_close);
    connect(servoRecipe, &ServoCommandServer::gapSizeChanged, this, &SimulatorForm::on_gap_pos);

    transTimer.setSingleShot(false);
    connect(&transTimer, &QTimer::timeout, this, &SimulatorForm::on_transport_tick);

    reel.ticker.setSingleShot(false);
    connect(&reel.ticker, &QTimer::timeout, this, &SimulatorForm::on_reel_tick);

    ticker.setSingleShot(false);
    connect(&ticker, &QTimer::timeout, this, &SimulatorForm::on_tick);
    ticker.start(20);

    servoRecipe->start();
    servoMovementsBridge->start();

}

SimulatorForm::~SimulatorForm()
{
    delete ui;

    servoMovementsBridge->stop();

    servoRecipe->deleteLater();
    servoMovementsBridge->deleteLater();
}

/*void SimulatorForm::on_turn_on()
{
    turnedOn = servoRecipe->turnedOn();
}*/

void SimulatorForm::on_speed_drum()
{
    motor[1].speed = servoRecipe->drumDriveSpeed();
    qDebug("set drum speed to %.10lf", motor[1].speed);
    double speed = motor[1].speed;

    cpp2matlab abc;
    abc.write2file(1,(speed/10));



}

void SimulatorForm::on_speed_left()
{
    motor[0].speed = servoRecipe->leftBeltSpeed();
    qDebug("set left speed to %.10lf", motor[0].speed);

    double speed = motor[0].speed;

    cpp2matlab abc;
    abc.write2file(0,(speed/10));
}

void SimulatorForm::on_speed_right()
{
    motor[2].speed = servoRecipe->rightBeltSpeed();
    qDebug("set right speed to %.10lf", motor[2].speed);

    double speed = motor[2].speed;

    cpp2matlab abc;
    abc.write2file(2,(speed/10));
}

void SimulatorForm::on_gap_pos()
{
    double gg,g = servoRecipe->gapSize();
    gg = g;
    if(g<-10992) g = -10992;
    else if(g>-8400) g = -8400;
    motor[3].pos = quint32(qRound(2.0 + (g+10992)*(650-2)/(10992-8400)));
    qDebug("set gapsize to %u (raw=%.10lf)", motor[3].pos, gg);
    gg = dough_len;
    gap = 0.1*motor[3].pos;
    dough_len = vol / gap / w_dough;
    g = dough_pos;
    if(dough_pos>0.0) {
        dough_pos = dough_pos + (dough_len-gg)/2;
    } else {
        dough_pos = dough_pos - (dough_len-gg)/2;
    }
    qDebug("dough pos changed from %.2lf to %.2lf while length changed from %.2lf to %.2lf", g, dough_pos, gg, dough_len);
    check_trigger();
}

void SimulatorForm::on_duster()
{
    duster = servoRecipe->outFlourDuster();
}

void SimulatorForm::on_reeler_go()
{
    reel.on = servoRecipe->outReelerMove();
    if(reel.on) reel.ticker.start(100);
}

void SimulatorForm::on_reeler_close()
{
    reel.close = !servoRecipe->outReelerClose();
}

void SimulatorForm::wheelEvent(QWheelEvent *event)
{
    if(event->delta()>0) {
        transportValue = qMin(transportValue+200,8000);
        update();
        servoRecipe->setTransportValue(transportValue);
    } else if(event->delta()<0) {
        transportValue = qMax(transportValue-200,0);
        update();
        servoRecipe->setTransportValue(transportValue);
    }
}

void SimulatorForm::on_transport_tick()
{
    if(transportDir>0) {
        transportValue = qMin(transportValue+transportDir,8000);
        update();
        servoRecipe->setTransportValue(transportValue);
    } else if(transportDir<0) {
        transportValue = qMax(transportValue+transportDir,0);
        update();
        servoRecipe->setTransportValue(transportValue);
    }
}

void SimulatorForm::mousePressEvent(QMouseEvent *event)
{
    //qDebug("button press %s %s", event->buttons()==Qt::LeftButton?"LEFT":"!LEFT",event->modifiers()==Qt::Key_Shift?"SHIFT":"!SHIFT");
    if(event->buttons()!=Qt::LeftButton) {
        QWidget::mousePressEvent(event);
        return;
    }
    if(event->modifiers()!=Qt::NoModifier) {
        QWidget::mousePressEvent(event);
        return;
    }

    int x = event->x();
    int y = event->y();
    int toleft = width()/6;
    int leftPart = width()/10;
    bool noSpeed = qAbs(motor[0].speed)<0.001 && qAbs(motor[1].speed)<0.001 && qAbs(motor[2].speed)<0.001;
    if(x>=0 && x<btnwidth) {
        // start left
        servoRecipe->leftButtonPressed(true);
        pressButton = 1;
        update();
        event->accept();
        return;
    } else if(x>=width()-btnwidth && x<width()) {
        // start right
        servoRecipe->rightButtonPressed(true);
        pressButton = 2;
        update();
        event->accept();
        return;
    } else if(x>=width()/2-leftPart/2 && x<=width()/2+leftPart/2 && y<=height()/3) {
        // stop
        if(motor[0].speed==0.0 && w_dough==START_DOUGH_WIDTH) {
            w_dough = NEXT_DOUGH_WIDTH;
        }
        servoRecipe->stopButtonPressed(true);
        pressButton = 3;
        update();
        event->accept();
        return;
    } else if(x>=width()/2-toleft-leftPart/2 && x<=width()/2-toleft+leftPart/2 && y<=height()/3 && SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE) {
        // transport
        int bw = leftPart;
        int cx = x - (width()/2-toleft-bw/2);
        if(cx<bw/3) {
            // decrease
            transportDir = -200;
            transTimer.start(200);
            on_transport_tick();
        } else if(cx>bw-bw/3) {
            // increase
            transportDir = 200;
            transTimer.start(200);
            on_transport_tick();
        } else {
            // on/off
            transportSignal = !transportSignal;
            transportDir = 0;
            if(transTimer.isActive()) transTimer.stop();
        }
        update();
        servoRecipe->setTransportBit(transportSignal);
    } else if(x>width()/2-leftPart/2 && x<width()/2+leftPart/2 && y>height()*2/3) {
        // cage open
        turnedOn = !turnedOn;
        servoRecipe->setTurnedOn(turnedOn);
        update();
    } else if(x>150 && x>width()/4-leftPart && x<width()/4+leftPart && y>height()*2/3 && noSpeed) {
        // place on left side
        w_dough = START_DOUGH_WIDTH;
        dough_pos = -1000.0;
        motor[3].pos = 650;
        gap = 0.1 * motor[3].pos;
        dough_len = vol / gap / w_dough;
        check_trigger();
    } else if(x<width()-150 && x>width()*3/4-leftPart && x<width()*3/4+leftPart && y>height()*2/3 && noSpeed) {
        // place on right side
        w_dough = START_DOUGH_WIDTH;
        dough_pos = 1000.0;
        motor[3].pos = 650;
        gap = 0.1 * motor[3].pos;
        dough_len = vol / gap / w_dough;
        check_trigger();
    }
    QWidget::mousePressEvent(event);
}

void SimulatorForm::mouseReleaseEvent(QMouseEvent *event)
{
    transportDir = 0;
    if(transTimer.isActive()) transTimer.stop();

    if(pressButton==0) {
        QWidget::mouseReleaseEvent(event);
        return;
    }

    if(pressButton==1) {
        pressButton = 0;
        servoRecipe->leftButtonPressed(false);
        update();
    } else if(pressButton==2) {
        pressButton = 0;
        servoRecipe->rightButtonPressed(false);
        update();
    } else if(pressButton==3) {
        pressButton = 0;
        servoRecipe->stopButtonPressed(false);
        update();
    }
    QWidget::mouseReleaseEvent(event);
}

void SimulatorForm::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);

    QFont fnt = painter.font();
    fnt.setPixelSize(height()*26/100);
    fnt.setBold(false);
    painter.setFont(fnt);
    painter.fillRect(event->rect(),QColor(0xFF,0xFF,0xE0));

    // draw Buttons
    painter.setPen(QColor(0xC0,0xC0,0xC0));
    QPolygon pol;
    int pr = 4;

    // BUTTON LEFT
    pol.clear();
    pol << QPoint(pr,pr) << QPoint(pr,height()-pr) << QPoint(btnwidth,height()/2);
    painter.setBrush(pressButton==1?QColor(0xB0,0xB0,0xB0):QColor(0xF0,0xF0,0xE0));
    painter.drawPolygon(pol);

    // BUTTON RIGHT
    pol.clear();
    pol << QPoint(width()-pr,pr) << QPoint(width()-pr,height()-pr) << QPoint(width()-btnwidth,height()/2);
    painter.setBrush(pressButton==2?QColor(0xB0,0xB0,0xB0):QColor(0xF0,0xF0,0xE0));
    painter.drawPolygon(pol);

    // BUTTON STOP
    pol.clear();
    pr = height()*15/20;
    pol << QPoint(width()/2-pr,2) << QPoint(width()/2+pr,2) << QPoint(width()/2+pr*3/4,height()/3) << QPoint(width()/2-pr*3/4,height()/3);
    painter.setBrush(pressButton==3?QColor(0xB0,0xB0,0xB0):QColor(0xF0,0xF0,0xE0));
    painter.drawPolygon(pol);

    // BUTTON TRANSPORT
    int toleft = width()/6;
    int leftPart = width()/10;
    if(SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE) {
        pol.clear();
        pol << QPoint(width()/2-leftPart/2-toleft,2) << QPoint(width()/2+leftPart/2-toleft,2) << QPoint(width()/2+leftPart/2-toleft,height()/3) << QPoint(width()/2-leftPart/2-toleft,height()/3);
        painter.setBrush(QColor(0xF0,0xF0,0xE0));
        painter.drawPolygon(pol);
    }

    // POSITION MARKER LEFT
    pol.clear();
    int marksize = height()/5;
    pol << QPoint(width()/4-marksize,height()) << QPoint(width()/4+marksize,height()) << QPoint(width()/4,height()-marksize);
    painter.setBrush(QColor(0xF0,0xF0,0xE0));
    painter.drawPolygon(pol);

    // POSITION MARKER RIGHT
    pol.clear();
    pol << QPoint(width()*3/4-marksize,height()) << QPoint(width()*3/4+marksize,height()) << QPoint(width()*3/4,height()-marksize);
    painter.setBrush(QColor(0xF0,0xF0,0xE0));
    painter.drawPolygon(pol);

    QPen dpen(QColor(0,0,0));
    //painter.setPen(QColor(0x80,0x80,0x80));
    //painter.drawText(0,0,width()/5,height(),Qt::AlignLeft|Qt::AlignVCenter,QString("%1 %2 %3").arg(QDateTime::currentMSecsSinceEpoch()%1000,3,10,QChar('0')).arg(dough_pos,0,'f',3).arg(dough_len,0,'f',3));
    //painter.drawText(0,0,width()/2,height(),Qt::AlignLeft|Qt::AlignVCenter,QString("%1 %2 %3").arg(motor[0].pos,10,10,QChar('0')).arg(motor[1].pos,10,10,QChar('0')).arg(motor[2].pos,10,10,QChar('0')));
    //painter.drawText(0,0,width()/2,height(),Qt::AlignLeft|Qt::AlignVCenter,QString("L:%1 cm").arg(dough_len/10.0,0,'f',2));
    painter.setPen(dpen);
    fnt.setBold(true);
    painter.setFont(fnt);

    int r = height()*15/20;
    int l = width() - 2*r;
    //painter.fillRect(QRect(r,height()-2,l,1), QColor(0,0,0));

    QPen pen(QColor(0x80,0x80,0x80));
    QVector<qreal> dashes;
    dashes << 8 << 4;
    pen.setDashPattern(dashes);

    pen.setDashOffset(motor[0].dash);
    pen.setStyle(Qt::CustomDashLine);
    painter.setPen(pen);
    painter.drawLine(r,height()-2,width()/2-1,height()-2);

    pen.setDashOffset(motor[2].dash);
    pen.setStyle(Qt::CustomDashLine);
    painter.setPen(pen);
    painter.drawLine(width()/2+1,height()-2,width()-r,height()-2);

    painter.setPen(dpen);

    // draw dough

    double dl = vol / gap / w_dough;
    int w = qRound(dl*l/(table_length*2));
    if(w<1) w = 1;
    int h = qRound(1.5*gap*l/(table_length*2));
    if(h<1) h = 1;
    int x = qRound(dough_pos*l/(table_length*2)) + width()/2 - w/2;
    painter.fillRect(QRect(x,height()-4-h,w,h), QColor(0xEB,0xC3,0x64));

    painter.setPen(turnedOn?QColor(0,0,0):QColor(255,0,0));

    // show gap value
    //painter.drawText(x+w/2-width()/5/2,height()/2,width()/5,height()/2-3,Qt::AlignHCenter|Qt::AlignBottom,QString("%1").arg(gap,0,'f',2));

    // show flour duster

    if(duster) {
        QPen sav = painter.pen(), pen(QColor(255,0,0));
        pen.setStyle(Qt::DotLine);
        pen.setWidth(2);
        painter.setPen(pen);
        painter.drawLine(width()/2-10, height()/3, width()/2+10, height()/3);
        painter.setPen(sav);
    }

    // show auto-reeler

    if(SystemConfig::autoreel_exists) {
        bool right = SystemConfig::autoreel_at_right_side;
        QPen sav = painter.pen();
        //pen.setWidth(2);
        painter.setPen(reel.on?QColor(255,0,0):QColor(0,0,0));
        /*painter.drawLine(width()-r, height()*2/3, width()-r, height()-2);
        if(rclose) {
            painter.drawLine(width()-r-1, height()-4, width()-r+1, height()-4);
            painter.drawLine(width()-r-2, height()-5, width()-r+2, height()-5);
        } else {
            painter.drawLine(width()-r-1, height()*2/3+2, width()-r+1, height()*2/3+2);
            painter.drawLine(width()-r-2, height()*2/3+3, width()-r+2, height()*2/3+3);
        }*/
        double x = right ? (width()-r) : r;
        double cx,cy,r=0.33*height();
        cy = qSin(reel.angle)*r;
        cx = qCos(reel.angle)*r;
        painter.drawLine(x, height()-2, x+(right?cx:-cx), height()-2-cy);
        if(reel.angle>0.0) painter.drawEllipse(QPointF(x+(right?cx:-cx), height()-2-cy),r/4,r/4);
        painter.setPen(sav);
    }

    // show speeds

    QChar ch;
    int percent[3] = {0,0,0};
    int ratio[2] = {0,0};
    for(int i=0; i<3; i++) {
        if(motor[i].speed==0.0) continue;
        if(SystemConfig::typ==SystemConfig::MachineType::ECOSTAR || SystemConfig::speed100<=0.01) continue;
        percent[i] = int(std::abs(std::round(motor[i].speed * 100.0 / SystemConfig::speed100)));
    }
    if(percent[1]>0) {
        ratio[0] = int(std::round(100.0 * std::abs(motor[0].speed * 100.0 / SystemConfig::speed100) / std::abs(motor[1].speed * 100.0 / SystemConfig::speed100)));
        ratio[1] = int(std::round(100.0 * std::abs(motor[2].speed * 100.0 / SystemConfig::speed100) / std::abs(motor[1].speed * 100.0 / SystemConfig::speed100)));
    }
    ch = motor[0].speed>0.0?'>':motor[0].speed<0.0?'<':' ';
    painter.drawText(r,2,width()/5,height()/2,Qt::AlignLeft|Qt::AlignTop,QString("%1 %2 %3").arg(ch).arg(qAbs(motor[0].speed/10.0),0,'f',1).arg(ch));
    ch = motor[1].speed>0.0?'>':motor[1].speed<0.0?'<':' ';
    painter.drawText(width()/2-width()/5/2,2,width()/5,height()/2,Qt::AlignHCenter|Qt::AlignTop,QString("%1 %2 %3").arg(ch).arg(qAbs(motor[1].speed/10.0),0,'f',1).arg(ch));
    ch = motor[2].speed>0.0?'>':motor[2].speed<0.0?'<':' ';
    painter.drawText(width()-r-width()/5,2,width()/5,height()/2,Qt::AlignRight|Qt::AlignTop,QString("%1 %2 %3").arg(ch).arg(qAbs(motor[2].speed/10.0),0,'f',1).arg(ch));
    if(ratio[0] || ratio[1]) {
        fnt.setPixelSize(int(std::round(height()/5)));
        painter.setFont(fnt);

        painter.drawText(r,2,width()/5,height()/2,Qt::AlignLeft|Qt::AlignBottom,QString("%1%2 (%3)").arg(percent[0]).arg('%').arg(ratio[0]));
        painter.drawText(width()/2-width()/5/2,2,width()/5,height()/2,Qt::AlignHCenter|Qt::AlignBottom,QString("%1%2").arg(percent[1]).arg('%'));
        painter.drawText(width()-r-width()/5,2,width()/5,height()/2,Qt::AlignRight|Qt::AlignBottom,QString("%1%2 (%3)").arg(percent[2]).arg('%').arg(ratio[1]));

        fnt.setPixelSize(int(std::round(height()/4)));
        painter.setFont(fnt);
    }

    // show transport
    painter.setPen(transportSignal?QColor(0xFF,0,0):QColor(0x80,0x80,0x80));
    if(SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE)
        painter.drawText(width()/2-width()/5/2-toleft,2,width()/5,height()/2,Qt::AlignHCenter|Qt::AlignTop,QString("%1").arg(transportValue));

    // show trigger+drum

    //painter.fillRect(QRect(width()/2-6,height()-4,12,4),trigger?QColor(255,0,0):QColor(0,0,0));
    //painter.fillRect(QRect(width()/2-5,height()-3,10,2),trigger?QColor(255,255,0):QColor(0xF0,0xF0,0xE0));
    leftPart = height()/8;
    painter.setPen(trigger?QColor(255,0,0):QColor(0xC0,0xC0,0xC0));
    painter.setBrush(trigger?QColor(255,255,0):QColor(0xF0,0xF0,0xE0));
    painter.drawRect(QRect(width()/2-leftPart,height()-leftPart-1,leftPart*2,leftPart));

    // show gapsize
    painter.setPen(QColor(0,0,0));
    painter.drawText(width()/2-width()/10,height()/2-leftPart-3,width()/5,height()/2-3,Qt::AlignHCenter|Qt::AlignBottom,QString("%1").arg(gap,0,'f',2));

    // show machine type
    QString mt = "unknown";
    switch(SystemConfig::typ) {
    case SystemConfig::ECOSTAR: mt = "EcoStar"; break;
    case SystemConfig::RONDOSTAR: mt = "RondoStar"; break;
    case SystemConfig::COMPASS: mt = "Compass 4.0"; break;
    }
    painter.drawText(width()*3/4-width()/10,0,width()/5,height()/2-3,Qt::AlignHCenter|Qt::AlignTop,mt);

    fnt.setPixelSize(height()/4);
    fnt.setBold(false);
    painter.setFont(fnt);
    painter.setBrush(Qt::NoBrush);
    painter.setPen(QColor(0,128,0));

    // HW cutomat
    bool b = SystemConfig::cutomat_at_right_side;
    pr = height()*76/100;
    if(SystemConfig::cutomat_exists) painter.drawText(b?(width()/2+pr):(width()/2-pr*3),0,pr*2,height()/3,(b?Qt::AlignLeft:Qt::AlignRight)|Qt::AlignTop," C ");

    // HW transport
    if(SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE) {
        b = SystemConfig::transport_at_right_side;
        painter.drawText(b?(width()-pr):0,height()*2/3,pr,height()/3,(b?Qt::AlignRight:Qt::AlignLeft)|Qt::AlignBottom," T ");
    }

    // HW manual reeler
    b = SystemConfig::manualreel_at_right_side;
    x = width()/2+(b?0.5:-0.5)*(l*SystemConfig::reel_length/ /*SystemConfig::*/table_length);
    if(SystemConfig::manualreel_exists) painter.drawEllipse(QPoint(x,height()-2),height()/6,height()/6);

    // HW aut reeler
    b = SystemConfig::autoreel_at_right_side;
    x = b ? (width()-r) : r;
    if(SystemConfig::autoreel_exists) painter.drawEllipse(QPoint(x,height()-2),height()/6,height()/6);
}

void SimulatorForm::on_tick()
{
    int steps = 12;
    double f = 0.01, fadd=329500.0*0.9/*280000.0*/, add;
    qint64 tmp;
    if(qAbs(motor[0].speed)>0.0001 && turnedOn) {
        // left belt
        add = motor[0].speed * f;
        tmp = motor[0].pos;
        tmp += qRound(add*fadd);
        motor[0].pos = quint32(tmp);
        servoRecipe->setMotorPosition(0,motor[0].pos);
        if(motor[0].speed>0.0) {
            // to right
            motor[0].dash = (motor[0].dash+1)%steps;
            if(dough_pos<=0.0) {
                if(dough_pos<table_length*9) dough_pos += add;
            }
        } else {
            // to left
            motor[0].dash = (motor[0].dash+steps-1)%steps;
            if(dough_pos<=0.0) {
                if(dough_pos>-table_length*9) dough_pos += add;
            }
        }
    }
    if(qAbs(motor[2].speed)>0.0001 && turnedOn) {
        // right belt
        add = motor[2].speed * f;
        tmp = motor[2].pos;
        tmp += qRound(add*fadd);
        motor[2].pos = quint32(tmp);
        servoRecipe->setMotorPosition(2,motor[2].pos);
        if(motor[2].speed>0.0) {
            // to right
            motor[2].dash = (motor[2].dash+1)%steps;
            if(dough_pos>=0.0) {
                if(dough_pos<table_length*9) dough_pos += add;
            }
        } else {
            // to left
            motor[2].dash = (motor[2].dash+steps-1)%steps;
            if(dough_pos>=0.0) {
                if(dough_pos>-table_length*9) dough_pos += add;
            }
        }
    }
    if(qAbs(motor[1].speed)>0.0001 && turnedOn) {
        // drum
        add = motor[1].speed * f;
        tmp = motor[1].pos;
        tmp += qRound(add*fadd);
        motor[1].pos = quint32(tmp);
        servoRecipe->setMotorPosition(1,motor[1].pos);
    }

    check_trigger();
    if(tickcnt==0) update();
    if(turnedOn) tickcnt = (tickcnt+1)%10;
}

void SimulatorForm::check_trigger()
{
    double beg,end;
    beg = dough_pos - dough_len/2;
    end = beg + dough_len;
    if(trigger) {
        if(end<0.0 || beg>0.0) {
            qDebug("trigger=OFF");
            trigger = false;
            servoRecipe->setLaserStatus(trigger);
        }
    } else {
        if(beg<0.0 && end>0.0) {
            qDebug("trigger=ON");
            trigger = true;
            servoRecipe->setLaserStatus(trigger);
        }
    }
}

void SimulatorForm::resizeEvent(QResizeEvent *event)
{
    btnwidth = qMax(event->size().height()*3/4,40);
    QWidget::resizeEvent(event);
}

void SimulatorForm::on_reel_tick()
{
    if(!reel.on) {
        reel.ticker.stop();
        return;
    }

    double pi2=3.1415/2.0;
    double step = pi2/10;

    if(reel.close) {
        reel.angle -= step;
        if(reel.angle<0.0) reel.angle = 0.0;
        if(reel.angle==0.0) {
            reel.ticker.stop();
            return;
        }
    } else {
        reel.angle += step;
        if(reel.angle>pi2) reel.angle = pi2;
        if(reel.angle>=pi2) {
            reel.ticker.stop();
            return;
        }
    }
}
