#ifndef SIMULATORFORM_H
#define SIMULATORFORM_H

#include <QWidget>
#include <QTimer>

//-----------------------------------------------------------
//addition for new file writing
/*
#include <qmath.h>
#include <fstream>
#include <iostream>
*/

//-----------------------------------------------------------


#include <servocommandserver.h>
#include "recipeinterpreterbridge.h"

namespace Ui {
class SimulatorForm;
}

class SimulatorForm : public QWidget
{
    Q_OBJECT

public:
    explicit SimulatorForm(QWidget *parent = nullptr);
    ~SimulatorForm();



protected:
    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);
    void resizeEvent(QResizeEvent *event);

private:
    Ui::SimulatorForm *ui;
    QTimer ticker, transTimer;
    double table_length, dough_len;
    int tickcnt;
    double gap, vol, dough_pos, w_dough;
    struct ST_MOTOR {
        double speed;
        quint32 pos;
        int dash;
    } motor[4];
    bool duster, turnedOn, trigger;
    int pressButton;
    int transportValue;
    bool transportSignal;
    int transportDir;
    int btnwidth;
    struct ST_REELER {
        bool on,close;
        double angle;
        QTimer ticker;
    } reel;

    ServoCommandServer *servoRecipe;
    RecipeInterpreterBridge *servoMovementsBridge;

    void check_trigger();

private slots:
    void on_tick();
    void on_speed_drum();
    void on_speed_left();
    void on_speed_right();
    void on_gap_pos();
    void on_duster();
    void on_reeler_go();
    void on_reeler_close();
    void on_transport_tick();
    void on_reel_tick();
};

#endif // SIMULATORFORM_H
