#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSettings>
#include <QFileInfo>
#include <QDesktopWidget>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    delete ui->menuBar;
    delete ui->mainToolBar;
    delete ui->statusBar;

    setWindowFlags(windowFlags()|Qt::WindowStaysOnTopHint);

    QFileInfo fi(QApplication::applicationFilePath());
    cfgName = fi.absolutePath() + "/" + fi.completeBaseName() + ".ini";
    QSettings cfg(cfgName, QSettings::IniFormat);
    restoreGeometry(cfg.value("WINDOW/GEOMETRY").toByteArray());
    restoreState(cfg.value("WINDOW/STATE").toByteArray());

    ui->widget->setMaximumHeight(qApp->desktop()->screen()->height()/14);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QSettings cfg(cfgName, QSettings::IniFormat);
    cfg.setValue("WINDOW/GEOMETRY",saveGeometry());
    cfg.setValue("WINDOW/STATE",saveState());

    QMainWindow::closeEvent(event);
}
