#include <QtCore/qglobal.h>
#include <ecrt.h>
#include <ectty.h>

//#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include <nanomsg/nn.h>
#include <nanomsg/tcp.h>
#include <nanomsg/reqrep.h>

#include <comm_data.h>
static tCOMMDATA_SRV2SIM sim_outdata;
static tCOMMDATA_SIM2SRV sim_indata;

#define CNT_SLAVES 10
#define CNT_RESP 200

static int64_t sMaster=0, sDomain=0, sSlaveConfig[CNT_SLAVES];
static bool activated = false;
static bool ecostar = false;
static unsigned int slave_count = 0;

#pragma pack(1)
typedef struct ST_ONE_DRIVE {
    uint16_t control; // 6040.00
    int32_t target_velocity; // 60ff.00
    uint32_t target_position; // 607a.00
    uint32_t digital_out; // 60fe.01

    uint16_t status; // 6041.00
    uint16_t error; // 603f.00
    int32_t velocity; // 606c.00
    int32_t velocity_raw; // 606b.00
    uint32_t position; // 6064.00
    uint32_t position_raw; // 6062.00
    int16_t torque; // 6077.00
    uint32_t digital_in; // 4601.81
} tONEDRIVE;

typedef struct ST_OTHER_DATA {
    uint8_t reserved[32];
    uint16_t error;
    union {uint16_t digital_ext,digitalInput0_PDO;};
    union {uint16_t analog_ext, digitalInput1_PDO;};
    uint16_t digitalOutput0_PDO;
    uint16_t digitalOutput1_PDO;
} tOTHER;
#pragma pack()

typedef struct ST_PREV_DATA {
    uint16_t control;
    int32_t target_velocity;
    uint32_t target_position;
    uint32_t digital_out;
} tPREVDATA;

static tPREVDATA prev_data[4];

typedef tONEDRIVE* tPONEDRIVE;

static uint8_t sDomainData[sizeof(tOTHER) + 4*sizeof(tONEDRIVE) + 1000];

typedef struct ST_REQ {
    size_t size;
    unsigned int index, subindex;
    uint32_t prev, value, reserved[6];
} tREQ;

static tREQ requests[CNT_SLAVES][CNT_RESP];

static int sim_socket=-1, sim_connect=-1;

static void myDebug(const char *fmt, ...)
{
#ifdef QT_DEBUG
    va_list ap;
    va_start(ap,fmt);
    vprintf(fmt,ap);
    va_end(ap);
    printf("\n");
    fflush(stdout);
#else
    Q_UNUSED(fmt);
#endif
}

static void init_all()
{
    for(size_t i=0; i<sizeof(sDomainData); i++) sDomainData[i] = 0;
    for(int i=0; i<4; i++) {
        prev_data[i].control = 0;
        prev_data[i].digital_out = 0;
        prev_data[i].target_position = 0;
        prev_data[i].target_velocity = 0;
    }
    for(int i=0; i<CNT_SLAVES; i++) sSlaveConfig[i] = i;
    for(int i=0; i<CNT_SLAVES; i++) {
        for(int j=0; j<CNT_SLAVES; j++) {
            requests[i][j].size = 0;
            requests[i][j].index = 0;
            requests[i][j].subindex = 0xFFFFu;
            for(int k=0; k<6; k++) requests[i][j].reserved[k] = 0;
            requests[i][j].value = 0;
            requests[i][j].prev = 0;
        }
    }
    sim_indata.size = sizeof(sim_indata);
    sim_outdata.size = sizeof(sim_outdata);
    sim_socket = nn_socket(AF_SP, NN_REQ);
    if(sim_socket>=0) {
        const char *srv = std::getenv("RONDO_SIMULATOR_IP");
        int timeout_ms = 200;
        nn_setsockopt(sim_socket, NN_SOL_SOCKET, NN_RCVTIMEO, &timeout_ms, sizeof(timeout_ms));
        timeout_ms = 300;
        nn_setsockopt(sim_socket, NN_SOL_SOCKET, NN_SNDTIMEO, &timeout_ms, sizeof(timeout_ms));
        sim_connect = nn_connect(sim_socket, srv && *srv ? srv : "tcp://127.0.0.1:8079");
        if(sim_connect<0) {
            int er = nn_errno();
            myDebug("%s nano reply server: error connecting to %s: %s", __FUNCTION__, srv && *srv ? srv : "tcp://127.0.0.1:8079", nn_strerror(er));
        }
    } else {
        int er = nn_errno();
        myDebug("%s nano reply server: error creating socket: %s", __FUNCTION__, nn_strerror(er));
    }
}

void ecrt_master_receive(ec_master_t *master)
{
    //myDebug("%s",__FUNCTION__);
    if(master != (ec_master_t*)&sMaster) return;
    if(ecostar) {

    } else {
        // ext. coupler

        tOTHER *extc = (tOTHER*)&sDomainData[0];
        extc->digital_ext = sim_indata.transp_bit ? 1u : 0u; // transport bit
        extc->analog_ext = uint16_t(sim_indata.transport);

        // servo's

        for(size_t i=0; i<4; i++) {
            tPONEDRIVE drv = tPONEDRIVE(&sDomainData[sizeof(tOTHER)+i*sizeof(tONEDRIVE)]);
            uint16_t ctl = drv->control;

            if(drv->digital_in != sim_indata.servo[i].din) {
                drv->digital_in = sim_indata.servo[i].din;
                myDebug("%s digital in = 0x%08X", __FUNCTION__, drv->digital_in);
            }

            if(drv->status != sim_indata.servo[i].status) {
                drv->status = sim_indata.servo[i].status;
                myDebug("%s servo[%u] status = 0x%04X",__FUNCTION__,i,drv->status);
            }

            if(drv->error != sim_indata.servo[i].error) {
                drv->error = sim_indata.servo[i].error;
                myDebug("%s servo[%u] error = 0x%04X",__FUNCTION__,i,drv->error);
            }

            if(drv->position != sim_indata.servo[i].pos) {
                drv->position = sim_indata.servo[i].pos;
                if(i==3) myDebug("%s servo[%u] position = 0x%08X",__FUNCTION__,i,drv->position);
            }
            if(i<3) {
                drv->velocity_raw = drv->velocity = sim_indata.servo[i].speed;
//                static int prev_speed[3] = {0,0,0};
//                if(sim_indata.servo[i].speed!=prev_speed[i]) {
//                    prev_speed[i] = sim_indata.servo[i].speed;
//                    myDebug("current speed[%d] = %d !!!",i,prev_speed[i]);
//                }
            }
        }
    }
}

void ecrt_domain_process(ec_domain_t *domain)
{
    //myDebug("%s",__FUNCTION__);
    //Q_UNUSED(domain);
}

void ecrt_domain_queue(ec_domain_t *domain)
{
    //myDebug("%s",__FUNCTION__);
    //Q_UNUSED(domain);
}

size_t ecrt_master_send(ec_master_t *master)
{
    //myDebug("%s",__FUNCTION__);
    if(master != (ec_master_t*)&sMaster) return 0;
    if(ecostar) {
        static uint16_t old_out0 = 0;
        static uint16_t old_out1 = 0;
        tOTHER *oth = (tOTHER*)&sDomainData[0];
        if(old_out0 != oth->digitalOutput0_PDO) {
            myDebug("%s digital_out0 := 0x%02hX <===============",__FUNCTION__,oth->digitalOutput0_PDO);
            old_out0 = oth->digitalOutput0_PDO;
        }
        if(old_out1 != oth->digitalOutput1_PDO) {
            myDebug("%s digital_out1 := 0x%02hX <===============",__FUNCTION__,oth->digitalOutput1_PDO);
            old_out1 = oth->digitalOutput1_PDO;
        }
    } else {
        for(size_t i=0; i<4; i++) {
            tPONEDRIVE drv = tPONEDRIVE(&sDomainData[sizeof(tOTHER)+i*sizeof(tONEDRIVE)]);
            if(i==1) {
                sim_outdata.servo[1].dout = drv->digital_out;
            }
            if(drv->digital_out != prev_data[i].digital_out) {
                myDebug("%s servo[%u].digital_out := 0x%08X <===============",__FUNCTION__,i,drv->digital_out);
                prev_data[i].digital_out = drv->digital_out;
            }
            if(i<3) {
                sim_outdata.servo[i].speed = drv->target_velocity;
            } else if(i==3) {
                sim_outdata.servo[i].speed = int(drv->target_position);
            }
            sim_outdata.servo[i].ctrl = drv->control;
            if(drv->target_position != prev_data[i].target_position) {
                myDebug("%s servo[%u].target_position := %u(0x%08X) <===============",__FUNCTION__,i,drv->target_position,drv->target_position);
                prev_data[i].target_position = drv->target_position;
            }
            if(drv->target_velocity != prev_data[i].target_velocity) {
                myDebug("%s servo[%u].target_velocity := %d(0x%08X) <===============",__FUNCTION__,i,drv->target_velocity,drv->target_velocity);
                prev_data[i].target_velocity = drv->target_velocity;
            }
            if(drv->control != prev_data[i].control) {
                myDebug("%s servo[%u].control := 0x%04hX <===============",__FUNCTION__,i,drv->control);
                prev_data[i].control = drv->control;
            }
        }
    }
    for(int i=0; i<CNT_SLAVES; i++) {
        for(int j=0; j<CNT_RESP; j++) {
            if(requests[i][j].prev != requests[i][j].value) {
                switch(requests[i][j].size) {
                case 1:
                    myDebug("%s write BYTE 0x%04X.%u := %u(0x%X) <===============",__FUNCTION__,requests[i][j].index,requests[i][j].subindex,requests[i][j].value&0xFFu,requests[i][j].value&0xFFu);
                    break;
                case 2:
                    myDebug("%s write WORD 0x%04X.%u := %u(0x%X) <===============",__FUNCTION__,requests[i][j].index,requests[i][j].subindex,requests[i][j].value&0xFFFFu,requests[i][j].value&0xFFFFu);
                    break;
                case 4:
                    myDebug("%s write DWORD 0x%04X.%u := %u(0x%X) <===============",__FUNCTION__,requests[i][j].index,requests[i][j].subindex,requests[i][j].value,requests[i][j].value);
                    break;
                case 23:
                    myDebug("%s write STRING 0x%04X.%u := ... <===============",__FUNCTION__,requests[i][j].index,requests[i][j].subindex);
                    break;
                }
                requests[i][j].prev = requests[i][j].value;
            }
        }
    }

    int sock = sim_socket;
    int conn = sim_connect;
    if(sock>=0 && conn>=0) {
        static bool send_ok=true, rcv_ok=true;
        //if(sim_outdata.servo[3].speed==0) myDebug("ERROR: servo[3].target_pos is zero !!!");
        int sent = nn_send(sock,&sim_outdata,sizeof(sim_outdata),0);
        if(sent==sizeof(sim_outdata)) {
            if(!send_ok) {
                send_ok = true;
                myDebug("OK: sim_outdata sent");
            }
            tCOMMDATA_SIM2SRV inbuf;
            int recvd = nn_recv(sock,&inbuf,sizeof(inbuf),0);
            if(recvd==sizeof(inbuf) && inbuf.size==recvd) {
                if(!rcv_ok) {
                    rcv_ok = true;
                    myDebug("OK: sim_indata received");
                }
                //if(inbuf.servo[0].pos==0) myDebug("ERROR: servo[0].pos is zero");
                sim_indata = inbuf;
            } else if(recvd<0) {
                int er = nn_errno();
                if(rcv_ok) {
                    rcv_ok = false;
                    myDebug("ERROR: sim_indata not received: %s", nn_strerror(er));
                }
            } else {
                rcv_ok = false;
                myDebug("ERROR: sim_indata not received: %d of %d bytes", recvd, sizeof(inbuf));
            }
        } else if(sent<0) {
            int er = nn_errno();
            if(send_ok) {
                send_ok = false;
                myDebug("ERROR: sim_outdata not sent: %s", nn_strerror(er));
            }
        } else {
            send_ok = false;
            myDebug("ERROR: sim_outdata not sent: %d of %d bytes", sent, sizeof(sim_outdata));
        }
    } else {
        static int cnt = 0;
        if(cnt<20) {
            cnt++;
            myDebug("ERROR: no sim_connection");
        }
    }

    return 0;
}

static bool is_slave_ok(const ec_slave_config_t *sc)
{
    for(int i=0; i<CNT_SLAVES; i++) {
        if(sc==(ec_slave_config_t*)&sSlaveConfig[i]) return true;
    }
    myDebug("... wrong slave config %p", sc);
    return false;
}

int ecrt_slave_config_pdos(ec_slave_config_t *sc, unsigned int n_syncs, const ec_sync_info_t syncs[])
{
    myDebug("%s tab[%u]",__FUNCTION__, n_syncs);
    if(!is_slave_ok(sc)) return -1;
    return 0;
}

int ecrt_slave_config_reg_pdo_entry(
        ec_slave_config_t *sc, /**< Slave configuration. */
        uint16_t entry_index, /**< Index of the PDO entry to register. */
        uint8_t entry_subindex, /**< Subindex of the PDO entry to register. */
        ec_domain_t *domain, /**< Domain. */
        unsigned int *bit_position /**< Optional address if bit addressing
                                 is desired */
        )
{
    if(!is_slave_ok(sc)) return -1;
    bool sc_ok = true;
    if(slave_count<=*(int*)sc) sc_ok = false;
    myDebug("%s servo[%d] 0x%hX,%u bitpos=%p domain %s%s",__FUNCTION__,*(int*)sc,entry_index,entry_subindex&0xFFu,bit_position,domain!=(ec_domain_t*)&sDomain?"err":"ok",sc_ok?"":", wrong slave !!!");
    if(domain!=(ec_domain_t*)&sDomain) return -1;
    return 0;
}

static void set_value(int n, uint16_t index, uint8_t subindex, uint32_t value)
{
    if(n<0 || n>CNT_SLAVES) return;
    for(int j=0; j<CNT_RESP; j++) {
        if(requests[n][j].size==0) return;
        if(requests[n][j].index==index && requests[n][j].subindex==subindex) {
            requests[n][j].value = value;
            return;
        }
    }
}

int ecrt_slave_config_sdo(ec_slave_config_t *sc, uint16_t index, uint8_t subindex, const uint8_t *data, size_t size)
{
    if(!is_slave_ok(sc)) return -1;
    switch(size) {
    case 1: {
        uint8_t *p = (uint8_t*)&data;
        set_value(*(int*)sc, index, subindex, *p);
        myDebug("%s servo[%d] 0x%04hX.%u BYTE := %u(0x%X)",__FUNCTION__,*(int*)sc,index,subindex&0xFFu,0xFFu&*p,0xFFu&*p);
        break; }
    case 2: {
        uint16_t *p = (uint16_t*)&data;
        set_value(*(int*)sc, index, subindex, *p);
        myDebug("%s servo[%d] 0x%04hX.%u WORD := %u(0x%X)",__FUNCTION__,*(int*)sc,index,subindex&0xFFu,0xFFFFu&*p,0xFFFFu&*p);
        break; }
    case 4: {
        uint32_t *p = (uint32_t*)&data;
        set_value(*(int*)sc, index, subindex, *p);
        myDebug("%s servo[%d] 0x%04hX.%u DWORD := %u(0x%X)",__FUNCTION__,*(int*)sc,index,subindex&0xFFu,*p,*p);
        break; }
    default:
        myDebug("%s servo[%d] 0x%04hX.%u %d bytes ... WARNING!!!",__FUNCTION__,*(int*)sc,index,subindex&0xFFu,size);
        break;
    }
    return 0;
}

int ecrt_slave_config_sdo8(ec_slave_config_t *sc, uint16_t sdo_index, uint8_t sdo_subindex, uint8_t value)
{
    //myDebug("%s",__FUNCTION__);
    return ecrt_slave_config_sdo(sc,sdo_index,sdo_subindex,&value,1);
}

int ecrt_slave_config_sdo16(ec_slave_config_t *sc, uint16_t sdo_index, uint8_t sdo_subindex, uint16_t value)
{
    //myDebug("%s",__FUNCTION__);
    return ecrt_slave_config_sdo(sc,sdo_index,sdo_subindex,(const uint8_t*)&value,2);
}

int ecrt_slave_config_sdo32(ec_slave_config_t *sc, uint16_t sdo_index, uint8_t sdo_subindex, uint32_t value)
{
    //myDebug("%s",__FUNCTION__);
    return ecrt_slave_config_sdo(sc,sdo_index,sdo_subindex,(const uint8_t*)&value,4);
}

ec_master_t *ecrt_request_master(unsigned int master_index)
{
    myDebug("%s(%u)",__FUNCTION__,master_index);
    init_all();
    if(master_index!=0) return nullptr;
    return (ec_master_t*)&sMaster;
}

ec_domain_t *ecrt_master_create_domain(ec_master_t *master)
{
    myDebug("%s",__FUNCTION__);
    if(master != (ec_master_t*)&sMaster) return nullptr;
    return (ec_domain_t*)&sDomain;
}

ec_slave_config_t *ecrt_master_slave_config(ec_master_t *master, uint16_t alias, uint16_t position, uint32_t vendor_id, uint32_t product_code)
{
    if(master == (ec_master_t*)&sMaster && alias==0 && position==0 && slave_count==0) {
        if(vendor_id==0x83 && product_code==0x83) ecostar = true;
        myDebug(ecostar?"... Ecostar":"... Compas/Rondostar");
    }
    myDebug("%s slave %hu.%hu vid=0x%X prod=0x%X",__FUNCTION__, alias, position, vendor_id, product_code);
    if(master != (ec_master_t*)&sMaster) return nullptr;
    if(vendor_id != 0x83 && vendor_id != 1) return nullptr;
    if(alias!=0) return nullptr;
    if(position>=CNT_SLAVES) return nullptr;
    //else if(!ecostar && position>=4) return nullptr; // NO TRANSFER HW
    if(slave_count<=position) slave_count = position+1;
    return (ec_slave_config_t*)&sSlaveConfig[position];
}

int ecrt_master_activate(ec_master_t *master)
{
    myDebug("%s",__FUNCTION__);
    if(activated) return -1;
    activated = true;
    return 0;
}

void ecrt_master_state(const ec_master_t *master, ec_master_state_t *state)
{
    //myDebug("%s",__FUNCTION__);
    if(master != (ec_master_t*)&sMaster) return;
    if(!state) return;
    state->link_up = 1;
    state->al_states = 8;
    state->slaves_responding = slave_count;
}

void ecrt_domain_state(const ec_domain_t *domain, ec_domain_state_t *state)
{
    //myDebug("%s",__FUNCTION__);
    if(domain != (ec_domain_t*)&sDomain) return;
    if(!state) return;
    state->working_counter = 0;
    state->wc_state = ec_wc_state_t::EC_WC_COMPLETE;
    state->redundancy_active = 0;
}

void ecrt_slave_config_state(const ec_slave_config_t *sc, ec_slave_config_state_t *state)
{
    //myDebug("%s",__FUNCTION__);
    if(!is_slave_ok(sc)) return;
    if(!state) return;
    state->online = 1;
    //state->al_state = ecostar ? 8 : (*(int*)sc >= 4 ? 0 : 8); // NO TRANSFER HW
    state->al_state = ecostar ? 8 : (*(int*)sc >= 4 ? 1 : 8); // WITH TRANSFER HW
    state->operational = 1;
}

int ecrt_domain_reg_pdo_entry_list(ec_domain_t *domain, const ec_pdo_entry_reg_t *pdo_entry_regs)
{
    myDebug("%s MEMSIZE: 4 x %u bytes",__FUNCTION__,sizeof(tONEDRIVE));
    if(domain != (ec_domain_t*)&sDomain) return -1;

#ifdef BLA
    {0, 0, omron::vendor, omron::R88D_400W, 0x6040, 0x00, &offset[0].control,nullptr},             /* Controlword */
    {0, 0, omron::vendor, omron::R88D_400W, 0x60ff, 0x00, &offset[0].target_velocity,nullptr},     /* Target velocity */
    {0, 0, omron::vendor, omron::R88D_400W, 0x607a, 0x00, &offset[0].target_position,nullptr},     /* Target position */
    {0, 0, omron::vendor, omron::R88D_400W, 0x60fe, 0x01, &offset[0].digital_out,nullptr},         /* Digital Outputs */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6041, 0x00, &offset[0].status,nullptr},              /* Statusword */
    {0, 0, omron::vendor, omron::R88D_400W, 0x603f, 0x00, &offset[0].error,nullptr},               /* Error code */
    {0, 0, omron::vendor, omron::R88D_400W, 0x606c, 0x00, &offset[0].actual_velocity,nullptr},     /* Actual Velocity */
    {0, 0, omron::vendor, omron::R88D_400W, 0x606b, 0x00, &offset[0].target_velocity_raw,nullptr}, /* Velocity Demand (read only)*/
    {0, 0, omron::vendor, omron::R88D_400W, 0x6064, 0x00, &offset[0].position,nullptr},            /* Position actual value */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6062, 0x00, &offset[0].target_position_raw,nullptr}, /* Position demand (read only) */
    {0, 0, omron::vendor, omron::R88D_400W, 0x6077, 0x00, &offset[0].torque,nullptr},              /* Torque actual value */
    {0, 0, omron::vendor, omron::R88D_400W, 0x4601, 0x81, &offset[0].digital_in,nullptr},          /* Digital inputs */
#endif

    tPONEDRIVE drvtab = tPONEDRIVE(&sDomainData[sizeof(tOTHER)]);
    typedef uint8_t* puint8;
    int off = 0;
    for(int i=0; i<4; i++) {
        uint goff = uint(i)*sizeof(tONEDRIVE) + sizeof(tOTHER);
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].control) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].target_velocity) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].target_position) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].digital_out) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].status) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].error) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].velocity) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].velocity_raw) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].position) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].position_raw) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].torque) - puint8(&drvtab[i])) + goff;
        *pdo_entry_regs[off++].offset = uint(puint8(&drvtab[i].digital_in) - puint8(&drvtab[i])) + goff;
    }
    return 0;
}

uint8_t *ecrt_domain_data(ec_domain_t *domain)
{
    myDebug("%s",__FUNCTION__);
    if(domain != (ec_domain_t*)&sDomain) return nullptr;
    return sDomainData;
}

ec_sdo_request_t *ecrt_slave_config_create_sdo_request(
        ec_slave_config_t *sc, /**< Slave configuration. */
        uint16_t index, /**< SDO index. */
        uint8_t subindex, /**< SDO subindex. */
        size_t size /**< Data size to reserve. */
        )
{
    if(!is_slave_ok(sc)) return nullptr;
    myDebug("%s servo[%d] 0x%hX,%u size=%d", __FUNCTION__, *(int*)sc, index, subindex&0xFFu, size);
    int idx = *(int64_t*)sc;
    if(idx<0 || idx>=10) return nullptr;
    if(size!=1 && size!=2 && size!=4 && size!=23) return nullptr;
    for(int j=0; j<CNT_RESP; j++) {
        if(requests[idx][j].index==index && requests[idx][j].subindex==subindex && requests[idx][j].size==size) {
            return (ec_sdo_request_t*)&requests[idx][j];
        }
    }
    for(int j=0; j<CNT_RESP; j++) {
        if(requests[idx][j].size==0) {
            requests[idx][j].size = size;
            requests[idx][j].index = index;
            requests[idx][j].subindex = subindex;
            return (ec_sdo_request_t*)&requests[idx][j];
        }
    }

    myDebug("... error: no memory");
    return nullptr;
}

uint8_t *ecrt_sdo_request_data(
        ec_sdo_request_t *req /**< SDO request. */
        )
{
//    myDebug("%s",__FUNCTION__);
    if(req) {
        tREQ *r = (tREQ*)req;
        return (uint8_t*)&r->value;
    }
    return nullptr;
}

ec_request_state_t ecrt_sdo_request_state(
        ec_sdo_request_t *req /**< SDO request. */
    )
{
//    myDebug("%s",__FUNCTION__);
    return ec_request_state_t::EC_REQUEST_SUCCESS;
}

void ecrt_sdo_request_write(
        ec_sdo_request_t *req /**< SDO request. */
        )
{
//    if(!req) {
//        myDebug("%s",__FUNCTION__);
//    } else {
//        tREQ *r = (tREQ*)req;
//        myDebug("%s 0x%04X.%u := %u(0x%X)",__FUNCTION__,r->index,r->subindex,r->value,r->value);
//    }
}

void ecrt_sdo_request_read(
        ec_sdo_request_t *req /**< SDO request. */
        )
{
//    myDebug("%s",__FUNCTION__);
}
