// Protobuf + Nanomsg
#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>
#include <nanomsg/reqrep.h>
#include <mutex>
#include <unistd.h>
#include <chrono>

#include <sheeter2020/servo.pb.h>
#include <sheeter2020/servo.pb.cc>

#include <r88d.hpp>
#include <global_state.hpp>
#include <ethercat.h>
#include <stdlogger.h>
#include <recipe_interpreter.hpp>

#include <sdo_writer.h>
extern SDOWriter reqAccGap;
extern SDOWriter reqDecGap;
extern SDOWriter reqMaxVGap;

#include <systemconfig.h>
#define NUMBER_MOTORS_TMP (SystemConfig::typ==SystemConfig::ECOSTAR?2:4)

extern uint32_t servo_sync_counter;
extern int rotate_for_cleaning_step; // 0=unused 1=request 2=busy
extern uint32_t rotate_for_cleaning_ticks;

namespace settings {
    extern int trigger_pin;
    extern int trigger_drive;
}

using namespace std::chrono;
using timestamp = time_point<system_clock, microseconds>;

constexpr uint32_t publish_delay_us = 10000l;

void nanomsg_publish_loop() {
    using sheeter2020::ServoStatus;
    using sheeter2020::ServoStatusBatch;

    static int skip_error[4] = {0,0,0,0};
    #define MAX_SKIP_ERROR 1000

    int nbytes, size;
    int pub = nn_socket(AF_SP, NN_PUB);

    if (pub < 0) {
        int error = nn_errno();
        printf("Error creating publisher: %s", nn_strerror(error));
    }

    int bind = nn_bind(pub, "tcp://0.0.0.0:8080");
    if (bind < 0) {
        int error = nn_errno();
        printf("Error binding: %s", nn_strerror(error));
    }

    ServoStatusBatch stat;
    void *buf = nullptr;

    while(1) {
        stat.Clear();
        timestamp now = time_point_cast<microseconds>(system_clock::now());
        stat.set_timestamp(uint64_t(now.time_since_epoch().count()));

        // publish synchronization state
        stat.set_synchronize_params(servo_sync_counter);

        bool trig_val = false;

        for (uint16_t servo_idx = 0; servo_idx < NUMBER_MOTORS_TMP; servo_idx++) {
            ServoStatus* msg = stat.add_statuses();

            if(skip_error[servo_idx]<MAX_SKIP_ERROR) {
                skip_error[servo_idx]++;
            }

            std::lock_guard<std::mutex> lock(lock_process_data[servo_idx]);

            auto pdb = process_data_buffer[servo_idx];

            msg->set_servo_id(servo_idx);

            if (pdb.error == 0)
                msg->set_error(ServoStatus::NO_ERROR);
            else if (pdb.error == 0xff14)
                msg->set_error(ServoStatus::OVERCURRENT);
            else{
                msg->set_error(ServoStatus::UNKNOWN_ERROR);
                msg->set_lowlevel_error(skip_error[servo_idx]<MAX_SKIP_ERROR ? 0 : pdb.error);
            }

            int gapMotorId = 3;

            if(SystemConfig::typ==SystemConfig::ECOSTAR)
                gapMotorId = 1;

            if(servo_idx == gapMotorId) {
                // the gapsize is in 1/10 mm!
                double target_gap_mm = position_to_gap(pdb.target_position);
                msg->set_target_pos(int(target_gap_mm * 10.0));
                double gap_mm = position_to_gap(pdb.position);
                msg->set_position(int(gap_mm * 10.0));
            } else {
                msg->set_target_pos(pdb.target_position);
                msg->set_position(pdb.position);
            }
            msg->set_target_pos_raw(pdb.target_position);
            msg->set_position_raw(pdb.position);
            msg->set_torque(pdb.torque);

            int32_t target_velo_mm_s = int(static_cast<double>(pdb.target_velocity) / 100000.0 / 4778.0 * 1500.0);
            if (servo_idx == 1)
                target_velo_mm_s /= 0.76;
            msg->set_target_velocity(target_velo_mm_s);
            msg->set_target_velocity_raw(pdb.target_velocity);
            int32_t velo_mm_s = int(static_cast<double>(pdb.velocity) / 100000.0 / 4778.0 * 1500.0);
            if (servo_idx == 1)
                velo_mm_s /= 0.76;

            if(SystemConfig::typ==SystemConfig::ECOSTAR){
                msg->set_velocity(pdb.velocity);
                msg->set_velocity_raw(pdb.velocity);

                if (pdb.error == 0){
                    msg->set_state(ServoStatus::RUNNING);
                }else{
                    msg->set_state(ServoStatus::FAULT);
                }

                //Set digital Inputs
                auto* in = msg->mutable_digital_in();
                if(pdb.safty_guard == 1){
                   in->set_mon1(false);
                }else{
                    in->set_mon1(true);
                }

                in->set_mon2(pdb.left_button);
                in->set_mon3(pdb.right_button);
                if(pdb.stop_button ==1){
                    in->set_mon4(false);
                }else{
                    in->set_mon4(true);
                }

                in->set_mon5(pdb.laser_trigger);

                in->set_mon6(pdb.roller_on);
                in->set_mon7(pdb.roller_to);
                in->set_mon8(pdb.drive_to_left_motor_on);

                // digital outputs
                auto* out = msg->mutable_digital_out();
                out->set_out3(pdb.flour_duster);
                out->set_out2(pdb.dough_reeler_close);
                out->set_out1(pdb.dough_reeler_on);

                // for digital IO output of EcoStar IO page
                out->set_out4(pdb.io_reeler_out4);
                out->set_out5(pdb.io_reeler_out5);
                out->set_out6(pdb.left_coupling);
                out->set_out7(pdb.brake);
                out->set_out8(pdb.right_coupling);

            }else{
                msg->set_velocity(velo_mm_s);
                msg->set_velocity_raw(pdb.velocity);
                msg->set_target_position_reached((pdb.status & status_bit::PP_TARGET_REACHED)?true:false);

                auto _status = status::remove_vendor_extension(pdb.status);
                msg->set_lowlevel_status(pdb.status);
                msg->set_lowlevel_error(skip_error[servo_idx]<MAX_SKIP_ERROR ? 0 : (pdb.error&0xFFFu));

                if (_status == status::READY_SWITCH_ON || _status == status::SWITCH_ON_DISABLED || _status == status::SWITCHED_ON)
                    msg->set_state(ServoStatus::STANDBY);
                else if (_status == status::OPERATION_ENABLED || pdb.error == 0xffb1) {
                    msg->set_state(ServoStatus::RUNNING);
                } else if (_status == status::NOT_READY)
                    msg->set_state(ServoStatus::STARTUP);
                else
                    msg->set_state(ServoStatus::FAULT);
                if (pdb.error != 0 && pdb.error != 0xffb1)
                    msg->set_state(ServoStatus::FAULT);

                {
                    //Set ext digital inputs connected on the gap motor
                    if(servo_idx == gapMotorId){
                        auto* inProtection = msg->mutable_digital_in_protection();
                        inProtection->set_circularbreak(din_latch[servo_idx] & status::mon::MON5);
                        inProtection->set_flourrelay(din_latch[servo_idx] & status::mon::MON6);
                    }
                    //Set digital Inputs
                    auto* in = msg->mutable_digital_in();
                    in->set_mon1(din_latch[servo_idx] & status::mon::MON1);
                    in->set_mon2(din_latch[servo_idx] & status::mon::MON2);
                    in->set_mon3(din_latch[servo_idx] & status::mon::MON3);
                    in->set_mon4(din_latch[servo_idx] & status::mon::MON4);
                    if(servo_idx==settings::trigger_drive) {
                        if(settings::trigger_pin==7)
                            trig_val = (din_latch[servo_idx] & status::mon::MON7); // redirected INPUT7 to INPUT5
                        else if(settings::trigger_pin==8)
                            trig_val = (din_latch[servo_idx] & status::mon::MON8); // redirected INPUT8 to INPUT5
                        else if(settings::trigger_pin==6)
                            trig_val = (din_latch[servo_idx] & status::mon::MON6); // redirected INPUT6 to INPUT5
                        else
                            trig_val = (din_latch[servo_idx] & status::mon::MON5); // no redirect, so INPUT5
                    }
                    in->set_mon6(din_latch[servo_idx] & status::mon::MON6);
                    in->set_mon7(din_latch[servo_idx] & status::mon::MON7);
                    in->set_mon8(din_latch[servo_idx] & status::mon::MON8);
                    din_latch[servo_idx] = 0;
                    // digital outputs
                    auto* out = msg->mutable_digital_out();
                    out->set_bkir(dout_latch[servo_idx] & status::dout::BKIR);
                    out->set_out1(dout_latch[servo_idx] & status::dout::OUT1);
                    out->set_out2(dout_latch[servo_idx] & status::dout::OUT2);
                    out->set_out3(dout_latch[servo_idx] & status::dout::OUT3);
                    out->set_gsel(dout_latch[servo_idx] & status::dout::GSEL);
                    dout_latch[servo_idx] = 0;

                    //for external coupler
                    if(SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE){
                        std::lock_guard<std::mutex> lock(lock_process_data_ext);
                        auto pdb_ext = process_data_buffer_ext;
                        auto* inputs_ext = msg->mutable_ext_coupler();
                        inputs_ext->set_digital_in_ext(pdb_ext.digital_out_ext);
                        inputs_ext->set_analog_in_ext(pdb_ext.analog_in_ext);
                    }
                }
            }



        }
        stat.mutable_statuses(1)->mutable_digital_in()->set_mon5(trig_val);


        size = stat.ByteSize();
        buf = malloc(size_t(size));
        stat.SerializeToArray(buf, size);

        nbytes = nn_send(pub, buf, size_t(size), 0);
        free(buf);
        if (nbytes < 0) {
            int error = nn_errno();
            printf("Error sending message: %s", nn_strerror(error));
        }

        usleep(publish_delay_us);
    }
}

void nanomsg_command_loop() {
    int rep = nn_socket(AF_SP, NN_REP);

    if (rep < 0) {
        int error = nn_errno();
        printf("Error creating reply socket: %s", nn_strerror(error));
    }

    int bind = nn_bind(rep, "tcp://0.0.0.0:8081");
    if (bind < 0) {
        int error = nn_errno();
        printf("Error binding reply to 127.0.0.1:8081: %s", nn_strerror(error));
    }

    int nbytes;
    sheeter2020::ServoCommandBatch requests;
    sheeter2020::ServoReplyBatch replies;
    void *inbuf = nullptr;
    void *outbuf = nullptr;

    printf("Waiting for requests\n");

    while (1) {
        inbuf = nullptr;
        replies.Clear();

        nbytes = nn_recv(rep, &inbuf, NN_MSG, 0);
        if (nbytes < 0) {
            int error = nn_errno();
            printf("Error receiving request: %s", nn_strerror(error));
            if(inbuf) nn_freemsg(inbuf);
        } else {
            requests.Clear();
            requests.ParseFromArray(inbuf, nbytes);

            if(requests.has_config()) {
                const ::sheeter2020::ServoConfig& scfg = requests.config();
                if(scfg.has_machine()) {
                    bool ok = true;
                    switch(scfg.machine()) {
                    case ::sheeter2020::ServoConfig::ECOSTAR:
                        if(SystemConfig::typ!=SystemConfig::ECOSTAR) ok = false;
                        break;
                    case ::sheeter2020::ServoConfig::RONDOSTAR:
                        if(SystemConfig::typ==SystemConfig::ECOSTAR)
                            ok = false;
                        else if(SystemConfig::typ!=SystemConfig::RONDOSTAR) {
                            SystemConfig::init_system_config(SystemConfig::RONDOSTAR);
                        }
                        break;
                    case ::sheeter2020::ServoConfig::COMPAS:
                        if(SystemConfig::typ==SystemConfig::ECOSTAR)
                            ok = false;
                        else if(SystemConfig::typ!=SystemConfig::COMPASS) {
                            SystemConfig::init_system_config(SystemConfig::COMPASS);
                        }
                        break;
                    }

                    if(!scfg.has_stamp()) ok = false;
                    if(!scfg.has_safestop()) ok = false;
                    if(!scfg.has_ticksbelt()) ok = false;
                    if(!scfg.has_ticksdrum()) ok = false;
                    if(!scfg.has_cutomatopt()) ok = false;
                    if(!scfg.has_transportopt()) ok = false;
                    if(!scfg.has_autoreeleropt()) ok = false;
                    if(!scfg.has_triggerignore()) ok = false;
                    if(!scfg.has_trigger_correction_ms()) ok = false;
                    if(!scfg.has_cutomatdistance()) ok = false;
                    if(!scfg.has_manualreeleropt()) ok = false;
                    if(!scfg.has_stopshortdistance()) ok = false;
                    if(!scfg.has_autoreelerdistance()) ok = false;
                    if(!scfg.has_stoprotatedistance()) ok = false;
                    if(!scfg.has_manualreelerdistance()) ok = false;
                    if(!scfg.has_fold_side()) ok = false;
                    if(!scfg.has_rotate_side()) ok = false;
                    if(!scfg.has_transportdistance()) ok = false;
                    if(!scfg.has_transportcalcpara()) ok = false;
                    if(!scfg.has_transportcalcparc()) ok = false;
                    if(!scfg.has_stopfolddistance()) ok = false;
                    if(!scfg.has_stop_pos_correction()) ok = false;
                    if(!scfg.has_acceleration_gap()) ok = false;
                    if(!scfg.has_deceleration_gap()) ok = false;

                    if(!scfg.has_runmode_factor()) ok = false;
                    if(!scfg.has_volume_factor()) ok = false;
                    if(!scfg.has_dynamic_speed()) ok = false;
                    if(!scfg.has_drum_mode()) ok = false;
                    if(!scfg.has_transportextra()) ok = false;
                    if(!scfg.has_autoreelerextra()) ok = false;
                    if(!scfg.has_manualreelerextra()) ok = false;
                    if(!scfg.has_max_speed_gap()) ok = false;

                    if(ok) {
                        #define TRC(art, name) do { \
                            if(*#art=='B') logServo.fmt("new set " #name " = %s", bool(name) ? "TRUE":"FALSE"); \
                            else if(*#art=='I') logServo.fmt("new set " #name " = %d", int(name)); \
                            else if(*#art=='U') logServo.fmt("new set " #name " = %u", uint(name)); \
                            else if(*#art=='D') logServo.fmt("new set " #name " = %.3lf", double(name)); \
                        } while(0)

                        if(scfg.ticksbelt()>0.0) SystemConfig::ticks2mm_belt = scfg.ticksbelt();
                        TRC(D, SystemConfig::ticks2mm_belt);
                        if(scfg.ticksdrum()>0.0) SystemConfig::ticks2mm_drum = scfg.ticksdrum();
                        TRC(D, SystemConfig::ticks2mm_drum);
                        SystemConfig::trigger_correction_ms = scfg.trigger_correction_ms();
                        TRC(D, SystemConfig::trigger_correction_ms);
                        if(scfg.runmode_factor()>0.0) SystemConfig::runmode_factor = scfg.runmode_factor();
                        TRC(D, SystemConfig::runmode_factor);
                        if(scfg.volume_factor()>0.0) SystemConfig::volume_factor = scfg.volume_factor();
                        TRC(D, SystemConfig::volume_factor);
                        SystemConfig::dynamic_mode = scfg.dynamic_speed();
                        TRC(B, SystemConfig::dynamic_mode);
                        SystemConfig::drum_mode = scfg.drum_mode();
                        TRC(B, SystemConfig::drum_mode);
                        SystemConfig::safe_stop = scfg.safestop()>0;
                        TRC(B, SystemConfig::safe_stop);
                        SystemConfig::cutomat_at_right_side = scfg.cutomatopt()>0;
                        TRC(B, SystemConfig::cutomat_at_right_side);
                        SystemConfig::cutomat_exists = scfg.cutomatopt()!=0;
                        TRC(B, SystemConfig::cutomat_exists);
                        if(scfg.cutomatdistance()>0.0) SystemConfig::cutomat_extra = scfg.cutomatdistance();
                        TRC(D, SystemConfig::cutomat_extra);
                        SystemConfig::transport_at_right_side = scfg.transportopt()>0;
                        TRC(B, SystemConfig::transport_at_right_side);
                        switch(std::abs(scfg.transportopt())) {
                        case SystemConfig::TransportMode::FBT:
                            SystemConfig::transport_mode = SystemConfig::FBT;
                            break;
                        case SystemConfig::TransportMode::TT_EU:
                            SystemConfig::transport_mode = SystemConfig::TT_EU;
                            break;
                        case SystemConfig::TransportMode::TT_US:
                            SystemConfig::transport_mode = SystemConfig::TT_US;
                            break;
                        case SystemConfig::TransportMode::NONE:
                            SystemConfig::transport_mode = SystemConfig::NONE;
                            break;
                        }
                        TRC(I, SystemConfig::transport_mode);
                        SystemConfig::autoreel_exists = scfg.autoreeleropt()!=0;
                        TRC(B, SystemConfig::autoreel_exists);
                        SystemConfig::autoreel_at_right_side = scfg.autoreeleropt()>0;
                        TRC(B, SystemConfig::autoreel_at_right_side);
                        if(scfg.autoreelerdistance()>0.0) SystemConfig::autoreel_length = scfg.autoreelerdistance();
                        TRC(D, SystemConfig::autoreel_length);
                        if(scfg.autoreelerextra()>1.0) SystemConfig::autoreel_length_extra = scfg.autoreelerextra();
                        TRC(D, SystemConfig::autoreel_length_extra);
                        if(scfg.triggerignore()>0) SystemConfig::trigger_ignore_ticks = scfg.triggerignore();
                        TRC(I, SystemConfig::trigger_ignore_ticks);
                        SystemConfig::manualreel_exists = scfg.manualreeleropt()!=0;
                        TRC(B, SystemConfig::manualreel_exists);
                        SystemConfig::manualreel_at_right_side = scfg.manualreeleropt()>0;
                        TRC(B, SystemConfig::manualreel_at_right_side);
                        if(scfg.manualreelerdistance()>0.0) SystemConfig::reel_length = scfg.manualreelerdistance();
                        TRC(D, SystemConfig::reel_length);
                        if(scfg.manualreelerextra()>1.0) SystemConfig::manualreel_length_extra = scfg.manualreelerextra();
                        TRC(D, SystemConfig::manualreel_length_extra);
                        if(scfg.stopshortdistance()>=1.0) SystemConfig::stop_pos_short = int(scfg.stopshortdistance());
                        TRC(I, SystemConfig::stop_pos_short);
                        if(scfg.stoprotatedistance()>=1.0) SystemConfig::stop_pos_long = int(scfg.stoprotatedistance());
                        TRC(I, SystemConfig::stop_pos_long);

                        if(scfg.stop_pos_correction()>=0.0) SystemConfig::stop_pos_correction = int(scfg.stop_pos_correction());
                        TRC(I, SystemConfig::stop_pos_correction);
                        if(scfg.has_stop_pos_correction_transfer() && scfg.stop_pos_correction_transfer()>=0.0) SystemConfig::stop_pos_correction_transfer = int(scfg.stop_pos_correction_transfer());
                        TRC(I, SystemConfig::stop_pos_correction_transfer);

                        if(scfg.has_length_correction_constant()) SystemConfig::length_correction_constant = int(scfg.length_correction_constant());
                        TRC(D, SystemConfig::length_correction_constant);

                        if(scfg.stopfolddistance()>=1.0) SystemConfig::stop_pos_fold = int(scfg.stopfolddistance());
                        TRC(I, SystemConfig::stop_pos_fold);
                        SystemConfig::fold_side = scfg.fold_side();
                        TRC(I, SystemConfig::fold_side);
                        SystemConfig::rotate_side = scfg.rotate_side();
                        TRC(I, SystemConfig::rotate_side);
                        if(scfg.transportdistance()>1.0) SystemConfig::transp_length_before = scfg.transportdistance();
                        TRC(D, SystemConfig::transp_length_before);
                        if(scfg.transportextra()>1.0) SystemConfig::transp_length_extra = scfg.transportextra();
                        TRC(D, SystemConfig::transp_length_extra);
                        SystemConfig::transp_a = scfg.transportcalcpara();
                        TRC(D, SystemConfig::transp_a);
                        SystemConfig::transp_c = scfg.transportcalcparc();
                        TRC(D, SystemConfig::transp_c);

                        int acc_gs = scfg.acceleration_gap();
                        int dec_gs = scfg.deceleration_gap();
                        int max_v_gs = scfg.max_speed_gap();
                        TRC(I,acc_gs);
                        TRC(I,dec_gs);
                        TRC(I, max_v_gs);
                        if(max_v_gs>=0) {
                            reqMaxVGap.start_write(uint(max_v_gs));
                        }
                        if(acc_gs>0 && dec_gs>0) {
                            reqAccGap.start_write(uint(acc_gs));
                            reqDecGap.start_write(uint(dec_gs));
                        }

                        SystemConfig::flourduster_delay = scfg.has_flourduster_delay() ? scfg.flourduster_delay() : 0;
                        TRC(I, SystemConfig::flourduster_delay);

                        SystemConfig::ecostar_speed_left = scfg.has_ecostar_speed_left() ? scfg.ecostar_speed_left() : 7.5;
                        SystemConfig::ecostar_speed_right = scfg.has_ecostar_speed_right() ? scfg.ecostar_speed_right() : 7.5;
                        TRC(D, SystemConfig::ecostar_speed_left);
                        TRC(D, SystemConfig::ecostar_speed_right);

                        SystemConfig::ecostar_stop_delay = scfg.has_ecostar_stop_delay() ? scfg.ecostar_stop_delay() : 650;
                        TRC(I, SystemConfig::ecostar_stop_delay);

                        servo_sync_counter = scfg.stamp();
                        TRC(U, servo_sync_counter);
                    } else {

                    }
                }
            }


            for (int i = 0; i < requests.commands_size(); i++) {
                const sheeter2020::ServoCommand& request = requests.commands().Get(i);
                auto reply = replies.add_replies();
                reply->set_status(sheeter2020::ServoReply::OK);

                uint32_t servo_idx = request.has_servo_id() ? request.servo_id() : 0xFFFFFFFFu;
                if(servo_idx>=4) {
                    reply->set_status(sheeter2020::ServoReply::ERROR);
                    break;
                }

                {
                    std::lock_guard<std::mutex> lock(lock_command_data[servo_idx]);
                    switch (request.command()) {
                        case sheeter2020::ServoCommand::RESET:
                            printf("RESET motor %i!\n", servo_idx);
                            command_data[servo_idx].control = cmd::RESET;
                            break;
                        case sheeter2020::ServoCommand::TURN_ON:
                            printf("TURN_ON motor %i!\n", servo_idx);
                            command_data[servo_idx].control = cmd::TURN_ON;
                            break;
                        case sheeter2020::ServoCommand::STOP:
                            printf("STOP motor %i!\n", servo_idx);
                            command_data[servo_idx].control = cmd::STOP;
                            break;
                        case sheeter2020::ServoCommand::TURN_OFF:
                            printf("TURN_OFF motor %i!\n", servo_idx);
                            command_data[servo_idx].control = cmd::TURN_OFF;
                            break;
                        case sheeter2020::ServoCommand::SET_VELOCITY:
                            if (request.has_target_velocity()) {
                                // requested velocity in mm/s
                                int32_t target_velo_mm_s = request.target_velocity();
                                if (target_velo_mm_s >= -2000 && target_velo_mm_s <= 2000) {
                                    double factor = 1.0;
                                    if (servo_idx == 1) {
                                        // Ugly hack correcting the roller speed
                                        factor = 0.76;
                                    }
                                    // requested velocity in ticks/s
                                    // 1500 mm/s == 4778 * 100000 ticks/s for belts
                                    // 1500 mm/s == 4778 * 100000 * 0.76 ticks/s for roller
                                    // TODO: ??? for gap motor
                                    double velo_ticks_s = static_cast<double>(target_velo_mm_s) *
                                        100000.0 * factor / 1500.0 * 4778.0;

                                    if(SystemConfig::typ==SystemConfig::ECOSTAR){
                                        if(target_velo_mm_s > 0)
                                            target_velo_mm_s = 1;
                                        else if(target_velo_mm_s < 0)
                                            target_velo_mm_s = -1;

                                        printf("SET_VELOCITY  direction  %d\n", target_velo_mm_s);
                                        command_data[servo_idx].target_velocity = target_velo_mm_s;
                                        command_data[servo_idx].target_velocity_new = true;

                                    }else{
                                        printf("SET_VELOCITY %d mm/s = %.3lf ticks/s for servo motor %d\n", target_velo_mm_s, velo_ticks_s, servo_idx);
                                        command_data[servo_idx].target_velocity =
                                            static_cast<int32_t>(velo_ticks_s);
                                        command_data[servo_idx].target_velocity_new = true;
                                    }

                                } else {
                                    printf("SET_VELOCITY %i out of range!\n", request.target_velocity());
                                    printf("Valid velocity range: -2000 to 2000 mm/s!\n");
                                    reply->set_status(sheeter2020::ServoReply::ERROR);
                                }
                            } else {
                                printf("SET_VELOCITY without target_velocity!\n");
                                reply->set_status(sheeter2020::ServoReply::ERROR);
                            }
                            break;
                        case sheeter2020::ServoCommand::SET_POSITION:
                            if (request.has_target_position()) {
                                double new_target_pos = request.target_position()/10.0;
                                double maxGap = 65.0;
                                if(SystemConfig::typ==SystemConfig::ECOSTAR)
                                    maxGap = 45.0;
                                if (new_target_pos >= 0.2 and new_target_pos <= maxGap) {
                                    printf("SET_POSITION %.3lf for servo motor %d\n", new_target_pos, servo_idx);
                                    command_data[servo_idx].target_position = gap_to_position(new_target_pos);
                                    command_data[servo_idx].target_position_new = 3;
                                } else {
                                    printf("SET_POSITION %.3lf out of range! Valid range is from 0.2 to 65 mm\n", new_target_pos);
                                    reply->set_status(sheeter2020::ServoReply::ERROR);
                                }
                            } else {
                                printf("SET_POSITION without target_position!\n");
                                reply->set_status(sheeter2020::ServoReply::ERROR);
                            }
                            break;
                       case sheeter2020::ServoCommand::SET_POSITION_RAW:
                            if (request.has_target_position_raw() && request.has_target_velocity()) {
                                // for cleaning
                                int32_t new_target_pos = request.target_position_raw();
                                // requested velocity in mm/s
                                int32_t target_velo_mm_s = request.target_velocity();
                                if (target_velo_mm_s >= -2000 && target_velo_mm_s <= 2000) {
                                    double factor = 1.0;
                                    if (servo_idx == 1) {
                                        // Ugly hack correcting the roller speed
                                        factor = 0.76;
                                    }
                                    // requested velocity in ticks/s
                                    // 1500 mm/s == 4778 * 100000 ticks/s for belts
                                    // 1500 mm/s == 4778 * 100000 * 0.76 ticks/s for roller
                                    // TODO: ??? for gap motor
                                    double velo_ticks_s = static_cast<double>(target_velo_mm_s) *
                                        100000.0 * factor / 1500.0 * 4778.0;

                                    if(SystemConfig::typ==SystemConfig::ECOSTAR){
                                        if(target_velo_mm_s > 0)
                                            target_velo_mm_s = 1;
                                        else if(target_velo_mm_s < 0)
                                            target_velo_mm_s = -1;

                                        printf("SET_VELOCITY direction %d for %d ticks (impossible!!!)\n", target_velo_mm_s, new_target_pos);
                                        //command_data[servo_idx].target_velocity = target_velo_mm_s;
                                        //command_data[servo_idx].target_velocity_new = true;
                                        reply->set_status(sheeter2020::ServoReply::ERROR);

                                    }else{
                                        printf("SET_VELOCITY %d mm/s = %.3lf ticks/s for %d ticks on servo motor %d\n", target_velo_mm_s, velo_ticks_s, new_target_pos, servo_idx);
                                        command_data[servo_idx].target_velocity =
                                            static_cast<int32_t>(velo_ticks_s);
                                        command_data[servo_idx].target_velocity_new = true;
                                        rotate_for_cleaning_ticks = uint32_t(std::abs(new_target_pos));
                                        rotate_for_cleaning_step = 1; // requested
                                    }
                                } else {
                                    printf("SET_VELOCITY %i out of range!\n", request.target_velocity());
                                    printf("Valid velocity range: -2000 to 2000 mm/s!\n");
                                    reply->set_status(sheeter2020::ServoReply::ERROR);
                                }
                            } else if (request.has_target_position_raw()) {
                                // for calibration
                                int32_t new_target_pos = request.target_position_raw();
                                printf("SET_POSITION_RAW %d for servo motor %d\n", new_target_pos, servo_idx);
                                command_data[servo_idx].target_position_raw = new_target_pos;
                                command_data[servo_idx].target_position_raw_new = true;

                            } else {
                                printf("SET_POSITION_RAW without target_position!\n");
                                reply->set_status(sheeter2020::ServoReply::ERROR);
                            }
                        break;
                        case sheeter2020::ServoCommand::SET_DIGITAL_OUTPUTS:
                            printf("Got request to set digital outputs for servo[%d]!\n", servo_idx);
                            if(SystemConfig::typ==SystemConfig::ECOSTAR){
                                {
                                    auto& dio = request.digital_out();
                                    if (dio.has_out3()) {
                                        if (dio.out3())
                                            command_data[servo_idx].flour_duster = 1;
                                        else
                                            command_data[servo_idx].flour_duster = 0;
                                        command_data[servo_idx].flour_duster_new = true;
                                    }
                                    if (dio.has_out2()) {
                                        if (dio.out2())
                                            command_data[servo_idx].dough_reeler_close = 1;
                                        else
                                            command_data[servo_idx].dough_reeler_close = 0;
                                        command_data[servo_idx].dough_reeler_close_new = true;
                                    }
                                    if (dio.has_out1()) {
                                        if (dio.out1())
                                            command_data[servo_idx].dough_reeler_on = 1;
                                        else
                                            command_data[servo_idx].dough_reeler_on = 0;
                                        command_data[servo_idx].dough_reeler_on_new = true;
                                    }
                                    if (dio.has_out4()) {
                                        if (dio.out4())
                                            command_data[servo_idx].io_reeler_out4 = 1;
                                        else
                                            command_data[servo_idx].io_reeler_out4 = 0;
                                        command_data[servo_idx].io_reeler_out4_new = true;
                                    }

                                    if (dio.has_out5()) {
                                        if (dio.out5())
                                            command_data[servo_idx].io_reeler_out5 = 1;
                                        else
                                            command_data[servo_idx].io_reeler_out5 = 0;
                                        command_data[servo_idx].io_reeler_out5_new = true;
                                    }

                                    if (dio.has_out6()) {
                                        if (dio.out6())
                                            command_data[servo_idx].io_leftCoupling_out6 = 1;
                                        else
                                            command_data[servo_idx].io_leftCoupling_out6 = 0;
                                        command_data[servo_idx].io_leftCoupling_out6_new = true;
                                    }

                                    if (dio.has_out7()) {
                                        if (dio.out7())
                                            command_data[servo_idx].brake = 1;
                                        else
                                            command_data[servo_idx].brake = 0;
                                        command_data[servo_idx].brake_new = true;
                                    }

                                    if (dio.has_out8()) {
                                        if (dio.out8())
                                            command_data[servo_idx].io_rightCoupling_out8 = 1;
                                        else
                                            command_data[servo_idx].io_rightCoupling_out8 = 0;
                                        command_data[servo_idx].io_rightCoupling_out8_new = true;
                                    }
                                }


                            }else{
                                {
                                    auto& dio = request.digital_out();
                                    if (dio.has_out1()) {
                                        if (dio.out1())
                                            command_data[servo_idx].digital_out |= status::dout::OUT1;
                                        else
                                            command_data[servo_idx].digital_out &= ~status::dout::OUT1;
                                    }
                                    if (dio.has_out2()) {
                                        if (dio.out2())
                                            command_data[servo_idx].digital_out |= status::dout::OUT2;
                                        else
                                            command_data[servo_idx].digital_out &= ~status::dout::OUT2;
                                    }
                                    if (dio.has_out3()) {
                                        if (dio.out3())
                                            command_data[servo_idx].digital_out |= status::dout::OUT3;
                                        else
                                            command_data[servo_idx].digital_out &= ~status::dout::OUT3;
                                    }
                                }
                                command_data[servo_idx].digital_out_new = true;

                            }


                            break;
                        case sheeter2020::ServoCommand::WRITE_PARAMETERS:
                           if(SystemConfig::typ==SystemConfig::ECOSTAR)
                                break;
                            //command_data[servo_idx].write_parameters = true;
                            printf("Writing parameters to servo[%d] NAND\n", servo_idx);
                            if(servo_idx == 0) {
                                configure_for_velocity_control(ec::sc_0);
                                configure_common_sdos(ec::sc_0);
                                write_to_flash(ec::sc_0);
                            }
                            if(servo_idx == 1) {
                                configure_for_velocity_control(ec::sc_1);
                                configure_common_sdos(ec::sc_1);
                                write_to_flash(ec::sc_1);
                            }
                            if(servo_idx == 2) {
                                configure_for_velocity_control(ec::sc_2);
                                configure_common_sdos(ec::sc_2);
                                write_to_flash(ec::sc_2);
                            }
                            if(servo_idx == 3) {
                                configure_for_position_control(ec::sc_3);
                                configure_common_sdos(ec::sc_3);
                                write_to_flash(ec::sc_3);
                            }
                            break;
                        case sheeter2020::ServoCommand::REBOOT:
                            if(SystemConfig::typ==SystemConfig::ECOSTAR)
                                break;
                            //command_data[servo_idx].reboot = true;
                            printf("Rebooting servo[%d]\n", servo_idx);
                            if(servo_idx == 0) reboot(ec::sc_0);
                            if(servo_idx == 1) reboot(ec::sc_1);
                            if(servo_idx == 2) reboot(ec::sc_2);
                            if(servo_idx == 3) reboot(ec::sc_3);
                            printf("Done rebooting servo[%d]\n", servo_idx);
                            break;
                        //case sheeter2020::ServoCommand::SET_ZERO_POINT:
                        //case sheeter2020::ServoCommand::NOTHING:
                        default:
                            command_data[servo_idx].control = 0x0;
                            break;
                    }
                }
            }

            outbuf = malloc(size_t(replies.ByteSize()));
            replies.SerializeToArray(outbuf, replies.ByteSize());

            nn_send(rep, outbuf, size_t(replies.ByteSize()), 0);

            free(outbuf);
            nn_freemsg(inbuf);
        }
    }
}
