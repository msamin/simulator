#include <global_state.hpp>
#include <ethercat.h>
#include <stdlogger.h>
#include <systemconfig.h>

static constexpr uint16_t store_parameters = 0x1010;
static uint8_t save_cmd[4] = {'e', 'v', 'a', 's'};
static constexpr uint16_t reset_parameters = 0x1011;
static uint8_t load_cmd[4] = {'d', 'a', 'o', 'l'};
static constexpr uint16_t reset = 0x2400;
static uint8_t reset_cmd[6] = {'t', 'e', 's', 'e', 'r', 'a'};
static constexpr uint16_t mode = 0x6060;
static constexpr uint16_t profile_velocity = 0x6081;
static constexpr uint16_t max_profile_velocity = 0x607f;
static constexpr uint16_t profile_acceleration = 0x6083;
static constexpr uint16_t profile_deceleration = 0x6084;
static constexpr uint16_t torque_limit = 0x6072;

static constexpr uint16_t custom_rx_1 = 0x1600;
static constexpr uint16_t custom_tx_1 = 0x1A00;

static constexpr uint16_t sm2 = 0x1c12;
static constexpr uint16_t sm3 = 0x1c13;

static constexpr uint32_t ctrl = 0x60400010;
static constexpr uint32_t target_velocity_w = 0x60ff0020;
static constexpr uint32_t target_position_w = 0x607a0020;
static constexpr uint32_t digital_output = 0x60fe0020;
static constexpr uint32_t status_word = 0x60410010;
static constexpr uint32_t error = 0x603f0010;
static constexpr uint32_t actual_velocity = 0x606c0020;
static constexpr uint32_t target_velocity_r = 0x606b0020;
static constexpr uint32_t actual_position = 0x60640020;
static constexpr uint32_t target_position_r = 0x60620020;
static constexpr uint32_t actual_torque = 0x60770010;
static constexpr uint32_t digital_input = 0x60fd0020;
static constexpr uint32_t monitor_input = 0x4601002;

// Addresses of virtual inputs -> these can be mapped to physical inputs
static constexpr uint16_t POT = 0x4630;
static constexpr uint16_t NOT = 0x4631;
static constexpr uint16_t EXT1 = 0x4632;
static constexpr uint16_t EXT2 = 0x4633;
static constexpr uint16_t DEC = 0x4634;
static constexpr uint16_t PCL = 0x4635;
static constexpr uint16_t NCL = 0x4636;
static constexpr uint16_t ESTP = 0x4637;
static constexpr uint16_t MON1 = 0x4638;
static constexpr uint16_t MON2 = 0x4639;
static constexpr uint16_t MON3 = 0x463a;
static constexpr uint16_t MON4 = 0x463b;
static constexpr uint16_t MON5 = 0x463c;
static constexpr uint16_t MON6 = 0x463d;
static constexpr uint16_t MON7 = 0x463e;
static constexpr uint16_t MON8 = 0x463f;

static constexpr uint16_t PORT_SEL = 1;
static constexpr uint16_t PORT_LOG = 2;

static constexpr uint32_t position_limit = 0x3b11;
static constexpr uint16_t velocity_iir = 0x3021;
static constexpr uint16_t position_iir = 0x3011;
static constexpr uint16_t brake = 0x3b20;

constexpr uint8_t profile_position_mode = 0x1;
constexpr uint8_t profile_velocity_mode = 0x3;
constexpr uint8_t cyclic_sync_position_mode = 0x8;
constexpr uint8_t cyclic_sync_velocity_mode = 0x9;

namespace settings {
    extern bool do_invert_trigger;
    extern int trigger_pin;
}

void configure_for_velocity_control(ec_slave_config_t *slave) {
    ecrt_slave_config_sdo8(slave, mode, 0, cyclic_sync_velocity_mode);
    return;
}

void configure_for_position_control(ec_slave_config_t *slave) {
    ecrt_slave_config_sdo8(slave, mode, 0, profile_position_mode);

    // Set profile
    ecrt_slave_config_sdo16(slave, torque_limit, 0, 5000);       // Set maximum torque
    ecrt_slave_config_sdo32(slave, profile_velocity, 0, 2147483647); // Set maximum profile velocity to ~100%
    ecrt_slave_config_sdo32(slave, max_profile_velocity, 0, 2147483647u); // Set maximum profile velocity to ~100%
    //ecrt_slave_config_sdo32(slave, profile_acceleration, 0, 2147483647u); // Set maximum acceleration to 100%
    //ecrt_slave_config_sdo32(slave, profile_deceleration, 0, 2147483647u); // Set maximum decelleration to 100%

    return;
    ecrt_slave_config_sdo32(slave, position_limit, 0x1, 3); // enable software position limits (pos + neg)
    ecrt_slave_config_sdo32(slave, position_limit, 0x2, 2);  // stop on reaching limt
    ecrt_slave_config_sdo32(slave, position_limit, 0x3, -2147483648);
    ecrt_slave_config_sdo32(slave, position_limit, 0x4, 2147483648);
    ecrt_slave_config_sdo32(slave, 0x6065, 0, 4294967295); // Set allowable following error for gap size to maximum

}

void configure_common_sdos(ec_slave_config_t *slave) {
    return;

    // Set Custom PDO Mapping
    ecrt_slave_config_sdo8 (slave, custom_rx_1, 0, 0);                  // 0 active PDOs
    ecrt_slave_config_sdo32(slave, custom_rx_1, 1, ctrl);               // control word
    ecrt_slave_config_sdo32(slave, custom_rx_1, 2, target_velocity_w);  // target velocity
    ecrt_slave_config_sdo32(slave, custom_rx_1, 3, target_position_w);  // target position
    ecrt_slave_config_sdo32(slave, custom_rx_1, 4, digital_output);     // digital output
    ecrt_slave_config_sdo8 (slave, custom_rx_1, 0, 4);                  // 4 active PDOs

    ecrt_slave_config_sdo8 (slave, custom_tx_1, 0, 0);                  // 0 active PDOs
    ecrt_slave_config_sdo32(slave, custom_tx_1, 1, status_word);        // status word
    ecrt_slave_config_sdo32(slave, custom_tx_1, 2, error);              // error code
    ecrt_slave_config_sdo32(slave, custom_tx_1, 3, actual_velocity);    // actual velocity
    ecrt_slave_config_sdo32(slave, custom_tx_1, 4, target_velocity_r);  // target velocity
    ecrt_slave_config_sdo32(slave, custom_tx_1, 5, actual_position);    // actual position
    ecrt_slave_config_sdo32(slave, custom_tx_1, 6, target_position_r);  // target position
    ecrt_slave_config_sdo32(slave, custom_tx_1, 7, actual_torque);      // actual torque
    ecrt_slave_config_sdo32(slave, custom_tx_1, 8, monitor_input);      // digital input
    ecrt_slave_config_sdo8 (slave, custom_tx_1, 0, 8);                  // 8 active PDOs

    ecrt_slave_config_sdo8 (slave, sm2, 0, 0);              // Disable all RxPDO mappings
    ecrt_slave_config_sdo16(slave, sm2, 1, custom_rx_1);    // Set SyncManager 2 to custom mapping
    ecrt_slave_config_sdo8 (slave, sm2, 0, 1);              // Enable one RxPDO mapping

    ecrt_slave_config_sdo8 (slave, sm3, 0, 0);             // Disable all TxPDO mappings
    ecrt_slave_config_sdo16(slave, sm3, 1, custom_tx_1);   // Set SyncManager 3 to custom mapping
    ecrt_slave_config_sdo8 (slave, sm3, 0, 1);             // Enable one TxPDO mappings

    // Disable brakes on stop/fault
    // 0 is free run
    // -5 is deceleration stop torque + dynamic brakes
    ecrt_slave_config_sdo16(slave, brake, 1, 0);    // Free-run on shutdown
    ecrt_slave_config_sdo16(slave, brake, 2, 0);    // Free-run on DISABLE_OPERATION
    ecrt_slave_config_sdo16(slave, brake, 4, 0);    // Free-run on fault

    // Configure GPIOs
    // Disable other GPIOS
    ecrt_slave_config_sdo32(slave, POT, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, NOT, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, EXT1, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, EXT2, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, DEC, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, PCL, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, NCL, PORT_SEL, 0);
    ecrt_slave_config_sdo32(slave, ESTP, PORT_SEL, 0);

    // IN 1: MON1
    ecrt_slave_config_sdo32(slave, MON1, PORT_SEL, 1);
    ecrt_slave_config_sdo32(slave, MON1, PORT_LOG, 0);

    // IN 2: MON2
    ecrt_slave_config_sdo32(slave, MON2, PORT_SEL, 2);
    ecrt_slave_config_sdo32(slave, MON2, PORT_LOG, 0);

    // IN 3: MON3
    ecrt_slave_config_sdo32(slave, MON3, PORT_SEL, 3);
    ecrt_slave_config_sdo32(slave, MON3, PORT_LOG, 0);

    // IN 4: MON4
    ecrt_slave_config_sdo32(slave, MON4, PORT_SEL, 4);
    ecrt_slave_config_sdo32(slave, MON4, PORT_LOG, 1);

    // IN 5: MON5
    ecrt_slave_config_sdo32(slave, MON5, PORT_SEL, 5);
    ecrt_slave_config_sdo32(slave, MON5, PORT_LOG, settings::do_invert_trigger && settings::trigger_pin==5 ? 1 : 0);

    // IN 6: MON6
    ecrt_slave_config_sdo32(slave, MON6, PORT_SEL, 6);
    ecrt_slave_config_sdo32(slave, MON6, PORT_LOG, settings::do_invert_trigger && settings::trigger_pin==6 ? 1 : 0);

    // IN 7: MON7
    ecrt_slave_config_sdo32(slave, MON7, PORT_SEL, 7);
    ecrt_slave_config_sdo32(slave, MON7, PORT_LOG, settings::do_invert_trigger && settings::trigger_pin==7 ? 1 : 0);

    // IN 8: MON8
    ecrt_slave_config_sdo32(slave, MON8, PORT_SEL, 8);
    ecrt_slave_config_sdo32(slave, MON8, PORT_LOG, settings::do_invert_trigger && settings::trigger_pin==8 ? 1 : 0);

    // Error Output (default OUT1) DISABLE
    ecrt_slave_config_sdo32(slave, 0x4650, 0x1, 0x0);

    // R-OUT 1: Port selection: OUT1 (0x01)
    ecrt_slave_config_sdo32(slave, 0x465C, 0x1, 0x01);

    // R-OUT 1: Logic selection: 0 == NO
    ecrt_slave_config_sdo32(slave, 0x465C, 0x2, 0x00);

    // R-OUT 2: Port selection: OUT2 (0x02)
    ecrt_slave_config_sdo32(slave, 0x465D, 0x1, 0x02);

    // R-OUT 2: Logic selection: 0 == NO
    ecrt_slave_config_sdo32(slave, 0x465D, 0x2, 0x00);

    // R-OUT 3: Port selection: OUT3 (0x04)
    ecrt_slave_config_sdo32(slave, 0x465E, 0x1, 0x04);

    // R-OUT 3: Logic selection: 0 == NO
    ecrt_slave_config_sdo32(slave, 0x465E, 0x2, 0x00);

}

void write_to_flash(ec_slave_config_t *slave) {
    // doesn't work reliably while the ethercat master is running
    return;
    int err = ecrt_slave_config_sdo(slave, store_parameters, 1, save_cmd, 4);
    if(err) {
        printf("Could not write to flash!\nError: %d", err);
    }
}

void clearEcoStarStarupError(){

    ec::sc_0 = ecrt_master_slave_config(
                        ec::master, 0, 0, omron::coupler_vendor, omron::OMRON_ECC201);
    if (!ec::sc_0)
        exit(1);
    ecrt_slave_config_sdo16 (ec::sc_0, 0x10F3, 0x05, 0x0001); //active the error logger
    ecrt_slave_config_sdo8 (ec::sc_0, 0x2002, 0x02, 0x01); //please check the document at chapter A-5-8, page 454
}

void reboot(ec_slave_config_t *slave) {
    // doesn't work reliably while the ethercat master is running
    return;
    int err = ecrt_slave_config_sdo(slave, reset, 0x1, reset_cmd, 6);
    if(err) {
        printf("Could not Reboot!\nError: %d", err);
    }
    else {
        printf("Success!\n");
    }
}

void reset_device_parameters() {
    // Restore Default Parameters
    ecrt_slave_config_sdo(ec::sc_0, reset_parameters, 1, load_cmd, 4);

    // Restore Default Application Parameters
    ecrt_slave_config_sdo(ec::sc_0, reset_parameters, 3, load_cmd, 4);

    //if (NUMBER_MOTORS > 1) {
        ecrt_slave_config_sdo(ec::sc_1, reset_parameters, 1, load_cmd, 4);
        ecrt_slave_config_sdo(ec::sc_1, reset_parameters, 3, load_cmd, 4);

        ecrt_slave_config_sdo(ec::sc_2, reset_parameters, 1, load_cmd, 4);
        ecrt_slave_config_sdo(ec::sc_2, reset_parameters, 3, load_cmd, 4);

        ecrt_slave_config_sdo(ec::sc_3, reset_parameters, 1, load_cmd, 4);
        ecrt_slave_config_sdo(ec::sc_3, reset_parameters, 3, load_cmd, 4);
    //}
}

/*
 * Write servo settings to non-volatile memory
 * This function should only be executed on-demand, for example after
 * changing a parameter in the default config
 * Flash memory can only perform a limited number of write operations
 */
void setup_device_parameters() {
    configure_for_velocity_control(ec::sc_0);
    configure_common_sdos(ec::sc_0);
    write_to_flash(ec::sc_0);

    //if (NUMBER_MOTORS > 1) {
        configure_for_velocity_control(ec::sc_1);
        configure_common_sdos(ec::sc_1);
        write_to_flash(ec::sc_1);

        configure_for_velocity_control(ec::sc_2);
        configure_common_sdos(ec::sc_2);
        write_to_flash(ec::sc_2);

        configure_for_position_control(ec::sc_3);
        configure_common_sdos(ec::sc_3);
        write_to_flash(ec::sc_3);
    //}
}

void setup_master() {
    ec::master = ecrt_request_master(0);
    if (!ec::master) {
        exit(1);
    }

    ec::domain1 = ecrt_master_create_domain(ec::master);
    if (!ec::domain1) {
        printf("Could not create domain\n");
        exit(1);
    }
#if NUMBER_MOTORS == 4
    // Configure Omron R88D 400W (Slave 0)
    if (!(ec::sc_0 = ecrt_master_slave_config(
                    ec::master, 0, 0, omron::vendor, omron::R88D_400W))) {
        fprintf(stderr, "Failed to get slave configuration for slave 0.\n");
        exit(1);
    }

    // Configure Omron R88D 750W (Slave 1)
    if (!(ec::sc_1 = ecrt_master_slave_config(
                    ec::master, 0, 1, omron::vendor, omron::R88D_750W))) {
        fprintf(stderr, "Failed to get slave configuration for slave 1.\n");
        exit(1);
    }

    // Configure Omron R88D 400W (Slave 2)
    if (!(ec::sc_2 = ecrt_master_slave_config(
                    ec::master, 0, 2, omron::vendor, omron::R88D_400W))) {
        fprintf(stderr, "Failed to get slave configuration for slave 2.\n");
        exit(1);
    }

    // Configure Omron R88D 100W (Slave 3)
    if (!(ec::sc_3 = ecrt_master_slave_config(
                    ec::master, 0, 3, omron::vendor, omron::R88D_100W))) {
        fprintf(stderr, "Failed to get slave configuration for slave 3.\n");
        exit(1);
    }
/*#elif NUMBER_MOTORS == 1
    // Configure Omron R88D 400W (Slave 0)
    if (!(ec::sc_0 = ecrt_master_slave_config(
                    ec::master, 0, 0, omron::vendor, omron::R88D_200W))) {
        fprintf(stderr, "Failed to get slave configuration for slave 0.\n");
        exit(1);
    }*/


    // --- Create configuration for bus coupler of transport
    {
    ec::sc_ext_0 = ecrt_master_slave_config(ec::master, 0, 4, omron::vendor, omron::ECC_201);
    if (!ec::sc_ext_0)
        exit(1);

    ec_slave_config_state_t s;

    ecrt_slave_config_state(ec::sc_ext_0, &s);

    if (s.al_state < 1) {
        printf(" No extern coupler for transport mode");
        return;
    }

    //for digital input
        if (!(ec::sc_ext_1 = ecrt_master_slave_config(ec::master,
                        0, 5, omron::vendor, omron::ID_4442))) {
            fprintf(stderr, "Failed to get slave digital configuration.\n");
            return;
        }

        int off_dig_inAdd1 = ecrt_slave_config_reg_pdo_entry(ec::sc_ext_0,
                0x6001, 0x01, ec::domain1, NULL);
        if (off_dig_inAdd1 < 0){
            printf("offset 1 smaller than 0 return");
            exit(1);
        }else{
            printf("offset values 1 + %u :   \n", off_dig_inAdd1);
        }

       //    for analog input
        if (!(ec::sc_ext_1 = ecrt_master_slave_config(ec::master,
                        0, 6, omron::vendor, omron::AD_2204))) {
            fprintf(stderr, "Failed to get slave analog configuration.\n");
            return;
        }

        int off_analog_inAdd2 = ecrt_slave_config_reg_pdo_entry(ec::sc_ext_0,
                0x6020, 0x01, ec::domain1, NULL);
        if (off_analog_inAdd2 < 0){
            printf("offset 2 smaller than 0 return");
            return;
        }else{
            printf("offset values 2 + %u :   \n", off_analog_inAdd2);
        }

        off_analog_inAdd2 = ecrt_slave_config_reg_pdo_entry(ec::sc_ext_0,
                0x6020, 0x02, ec::domain1, NULL);
        if (off_analog_inAdd2 < 0){
            printf("offset 3 smaller than 0 return");
            return;
        }else{
            printf("offset values 3 + %u :   \n", off_analog_inAdd2);
        }

      }

#elif NUMBER_MOTORS == 2
        printf(" Master setup for EcoStar is finished. \n");
#else
      #error "NUMBER MOTORS not in 2,4"
#endif


}

#if NUMBER_MOTORS == 2

void initialize_devices() {
    printf("Configuring PDOs...\n");
    // Configure NX ECC201 (Slave 0)
    if (!(ec::sc_0 = ecrt_master_slave_config(
                    ec::master, busCouplerPos, omron::coupler_vendor, omron::OMRON_ECC201))) {
        fprintf(stderr, "Failed to get slave configuration for bus coupler.\n");
        exit(1);
    }

    // ------- For digital input 0-------------------
    if (!(ec::sc_digiIn_0 = ecrt_master_slave_config(
                    ec::master, digitalInput0Pos,  omron::unit_vendor, omron::OMRON_ID4442))) {
        fprintf(stderr, "Failed to get slave configuration digital in 0 .\n");
        exit(1);
    }else{
        printf("Get slave configuration digital 0 succeed.\n");
    }

   int addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                digitalInput0_PDO_entry, ec::domain1, NULL);
    if (addressOffset < 0){
        printf("digitInput 0 address offset smaller than 0 return");
         exit(1);
    }

    // ------- For digital input 1-------------------
    if (!(ec::sc_digiIn_1 = ecrt_master_slave_config(
                    ec::master, digitalInput1Pos, omron::unit_vendor, omron::OMRON_ID4342))) {
        fprintf(stderr, "Failed to get slave configuration digital in 1 .\n");
        exit(1);
    }

    addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                     digitalInput1_PDO_entry, ec::domain1, NULL);
     if (addressOffset < 0){
         fprintf("digit1add smaller than 0 return \n");
         exit(1);
     }

     // ------- For digital output 0-------------------
     if (!(ec::sc_digiOut_0 = ecrt_master_slave_config(
                     ec::master, digitalOutput0Pos, omron::unit_vendor, omron::OMRON_OC4633))) {
         fprintf(stderr, "Failed to get slave configuration digital out 0 .\n");
         exit(1);
     }

      addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                  digitalOutput0_PDO_entry, ec::domain1, NULL);
      if (addressOffset < 0){
          printf("digitOutput 0 address offset smaller than 0 return \n");
          exit(1);
      }

      // ------- For digital output 1 ------------------
      if (!(ec::sc_digiOut_1 = ecrt_master_slave_config(
                      ec::master,digitalOutput1Pos, omron::unit_vendor, omron::OMRON_OD3256))) {
          fprintf(stderr, "Failed to get slave configuration digital in 1 .\n");
          exit(1);
      }else{
          printf("Get slave configuration digital 1 succeed.\n");
      }


      unsigned int off_dig_out1Bit1, off_dig_out1Bit2, off_dig_out1Bit3;

        addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                  digitalOutput1Bit0_PDO_entry, ec::domain1, NULL);
        if (addressOffset < 0){
           printf("off_dig_out1Add1 smaller than 0 return");
           exit(1);
        }

          addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                  digitalOutput1Bit1_PDO_entry, ec::domain1, &off_dig_out1Bit1);
          if (addressOffset < 0){
              printf("off_dig_out1Add2 smaller than 0 return");
               exit(1);
          }

          addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                  digitalOutput1Bit2_PDO_entry, ec::domain1, &off_dig_out1Bit2);
          if (addressOffset < 0){
              printf("off_dig_out1Add3 smaller than 0 return");
               exit(1);
          }

          addressOffset = ecrt_slave_config_reg_pdo_entry(ec::sc_0,
                  digitalOutput1Bit3_PDO_entry, ec::domain1, &off_dig_out1Bit3);
          if (addressOffset < 0){
              printf("offset 4 smaller than 0 return");
               exit(1);
          }


    printf("Activating master...\n");
    if (ecrt_master_activate(ec::master)) {
        printf("Error activating master...\n");
        exit(1);
    }


    if (!(domain1_pd = ecrt_domain_data(ec::domain1))) {
        printf("Error getting domain process data...\n");
        exit(1);
    }
    clearEcoStarStarupError();
}

#else

void initialize_devices() {
    printf("Configuring PDOs...\n");
    if (ecrt_slave_config_pdos(ec::sc_0, EC_END, slave_0_syncs)) {
        fprintf(stderr, "Failed to configure PDOs for slave 0.\n");
        exit(1);
    }
#if NUMBER_MOTORS == 4
    if (ecrt_slave_config_pdos(ec::sc_1, EC_END, slave_1_syncs)) {
        fprintf(stderr, "Failed to configure PDOs for slave 1.\n");
        exit(1);
    }

    if (ecrt_slave_config_pdos(ec::sc_2, EC_END, slave_2_syncs)) {
        fprintf(stderr, "Failed to configure PDOs for slave 2.\n");
        exit(1);
    }

    if (ecrt_slave_config_pdos(ec::sc_3, EC_END, slave_3_syncs)) {
        fprintf(stderr, "Failed to configure PDOs for slave 3.\n");
        exit(1);
    }
#endif

    if (ecrt_domain_reg_pdo_entry_list(ec::domain1, domain1_regs)) {
        fprintf(stderr, "PDO entry registration failed!\n");
        exit(1);
    }

    printf("Activating master...\n");
    if (ecrt_master_activate(ec::master)) {
        printf("Error activating master...\n");
        exit(1);
    }


    if (!(domain1_pd = ecrt_domain_data(ec::domain1))) {
        printf("Error getting domain process data...\n");
        exit(1);
    }
}

#endif

void check_domain1_state()
{
    ec_domain_state_t ds;

    ecrt_domain_state(ec::domain1, &ds);

    if (ds.working_counter != ec::domain1_state.working_counter) {
        //printf("Domain1: WC %u.\n", ds.working_counter);
    }
    if (ds.wc_state != ec::domain1_state.wc_state) {
        //printf("Domain1: State %u.\n", ds.wc_state);
    }

    ec::domain1_state = ds;
}


void check_master_state()
{
    ec_master_state_t ms;

    ecrt_master_state(ec::master, &ms);

    if (ms.slaves_responding != ec::master_state.slaves_responding) {
        //printf("%u slave(s).\n", ms.slaves_responding);
    }
    if (ms.al_states != ec::master_state.al_states) {
        //printf("AL states: 0x%02X.\n", ms.al_states);
    }
    if (ms.link_up != ec::master_state.link_up) {
        //printf("Link is %s.\n", ms.link_up ? "up" : "down");
    }

    ec::master_state = ms;
}


void check_slave_config_states()
{
    ec_slave_config_state_t s;

    ecrt_slave_config_state(ec::sc_0, &s);

    if (s.al_state != ec::sc_state_0.al_state) {
        //printf("R88D: State 0x%02X.\n", s.al_state);
    }
    if (s.online != ec::sc_state_0.online) {
        //printf("R88D: %s.\n", s.online ? "online" : "offline");
    }
    if (s.operational != ec::sc_state_0.operational) {
        //printf("R88D: %soperational.\n", s.operational ? "" : "Not ");
    }

    ec::sc_state_0 = s;
}
