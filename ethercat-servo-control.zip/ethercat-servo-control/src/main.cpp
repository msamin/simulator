#include <ecrt.h>
#include <errno.h>
#include <mutex>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h> /* mlockall() */
#include <sys/resource.h>
#include <sys/time.h>
#include <sys/types.h>
#include <thread>
#include <time.h> /* clock_gettime() */
#include <unistd.h>

#include <ethercat.h>
#include <global_state.hpp>
#include <nanomsg_loop.hpp>
#include <omron_constants.hpp>
#include <r88d.hpp>
#include <recipe_interpreter.hpp>
#include <errors.h>
#include <cmath>
#include <average.h>
#include <sdo_writer.h>

#define SYSVARIABLE
#include <systemconfig.h>

#include <stdlogger.h>

namespace settings {
    bool do_invert_trigger = true;
    int trigger_pin = 7;
    int trigger_drive = 0;
    uint32_t PERIOD_NS = 10000000; // 10ms period

    constexpr uint16_t MAX_SAFE_STACK = 8 * 1024; /* The maximum stack size which is
                                                     guranteed safe to access without
                                                     faulting */

    constexpr uint32_t NSEC_PER_SEC = 1000000000;
    uint16_t FREQUENCY = NSEC_PER_SEC / PERIOD_NS;
}

static unsigned int counter = 0;
//for measurement the period time
static struct timespec startTime, lastStartTime = {};
static uint32_t period_ns = 0;
/*****************************************************************************/
static int ecostarGapOffset = 0;
//133 entries in the 0x10F3 error logger SDO
ec_sdo_request_t *errorLogs[134];
ec_sdo_request_t *sendClearMinor;
SDOWriter reqAccGap;
SDOWriter reqDecGap;
SDOWriter reqMaxVGap;
static uint8_t newMsgIdx = 0;
static uint32_t errorCodeEcoStar = 0;
static bool clearMinor = false;
static bool needGetLoggerIndex = false;
static bool loggerIndexSuccess = false;
void initialSDOaccess(){
    if(SystemConfig::typ==SystemConfig::ECOSTAR) {
        ec::sc_0 = ecrt_master_slave_config(
                                ec::master, 0,0, omron::coupler_vendor, omron::OMRON_ECC201);

        for(int i = 0; i < 5; i++){
            errorLogs[i] = ecrt_slave_config_create_sdo_request(ec::sc_0,0x10F3, i,1);
        }
        errorLogs[5] = ecrt_slave_config_create_sdo_request(ec::sc_0,0x10F3, 0x05,2);
        for(int i = 6; i < 134; i++){
            errorLogs[i] = ecrt_slave_config_create_sdo_request(ec::sc_0,0x10F3, i,23);
        }
        sendClearMinor =  ecrt_slave_config_create_sdo_request(ec::sc_0,0x2002, 0x02,1);
    } else {
        reqMaxVGap.init32(ec::sc_3, 0x3040, 0xF1);
        reqAccGap.init32(ec::sc_3, 0x3040, 0xF3);
        reqDecGap.init32(ec::sc_3, 0x3040, 0xF4);
    }
}

#if NUMBER_MOTORS == 2
static unsigned int testCounter = 0;

static unsigned int  breakCnt = 0;
static int  breakDirection = 0;

static unsigned  int  securityStopCnt = 0;
//static unsigned  int  securityStopLimitRight = 170;
//static unsigned  int  securityStopLimitLeft = 160;
//static unsigned  int  securityStopLimit = 230;

static unsigned  int  securityStopLimitRight = 130;
static unsigned  int  securityStopLimitLeft = 120;
static unsigned  int  securityStopLimit = 160;

static unsigned  int  gapMotorOpenCloseStepCnt = 0;
static unsigned  int  gapMotorOpenCloseStepLimit = 6;
uint8_t grayToBinary8(uint8_t num)
{
    //num = num ^ (num >> 16);
    //num = num ^ (num >> 8);
    num = num ^ (num >> 4);
    num = num ^ (num >> 2);
    num = num ^ (num >> 1);
    return num;
}

void cyclic_task()
{
    // receive process data
    ecrt_master_receive(ec::master);
    ecrt_domain_process(ec::domain1);

    // check process data state
    check_domain1_state();

        // Read process data into custom struct
        uint8_t digitalOutput0_8bit = 0x00;
        uint8_t digitalOutput1_4bit = 0x00;

        process_data[0].error = EC_READ_U8(domain1_pd + offset[0].error);
        if(process_data[0].error == 34){
            process_data[0].error = 0;
            process_data[1].error = 0;
            clearMinor = true;
        }else if(process_data[0].error == 2){
            process_data[0].error = 0;
            process_data[1].error = 0;
        }else{
            needGetLoggerIndex = true;
            process_data[0].error = errorCodeEcoStar;
            if(errorCodeEcoStar != 0)
                errorCodeEcoStar = 0;
            process_data[1].error = 0;
        }

        process_data[0].safty_guard = (EC_READ_U8(domain1_pd + offset[0].safty_guard) & 1);
        process_data[0].left_button = (EC_READ_U8(domain1_pd + offset[0].left_button) & (1 << 1)) >> 1;
        process_data[0].right_button = (EC_READ_U8(domain1_pd + offset[0].right_button) & (1 << 2)) >> 2;
        process_data[0].stop_button= (EC_READ_U8(domain1_pd + offset[0].stop_button) & (1 << 3)) >> 3;
        process_data[0].laser_trigger = (EC_READ_U8(domain1_pd + offset[0].laser_trigger) & (1 << 4)) >> 4;

        //Convert gray encoder to decimal number
        process_data[1].position = grayToBinary8(EC_READ_U8(domain1_pd + offset[0].gap_position)) - ecostarGapOffset; //add calibration offset
        if(process_data[1].position < 0 ){
            process_data[1].position = 255 + process_data[1].position;
        }else if(process_data[1].position > 255 ){
            process_data[1].position = process_data[1].position - 255;
        }

        digitalOutput0_8bit = EC_READ_U8(domain1_pd + offset[0].left_motor_on);
        digitalOutput1_4bit  = EC_READ_U8(domain1_pd + offset[0].flour_duster);

        process_data[0].digitalOutput0 = digitalOutput0_8bit;
        process_data[0].digitalOutput1 = digitalOutput1_4bit;

        process_data[0].drive_to_left_motor_on = (EC_READ_U8(domain1_pd + offset[0].left_motor_on) & 1);
        process_data[0].drive_to_right_motor_on = (EC_READ_U8(domain1_pd + offset[0].right_motor_on) & (1 << 1)) >> 1;

        if(process_data[0].drive_to_left_motor_on == 1)
            process_data[0].velocity = -1;
        else if(process_data[0].drive_to_right_motor_on == 1)
            process_data[0].velocity = 1;
        else
            process_data[0].velocity = 0;

        bool leftButtonPressed = false;
        bool rightButtonPressed = false;
        bool motorIsMoving = true;
        if(process_data[0].left_button)
            leftButtonPressed = true;
        if(process_data[0].right_button)
            rightButtonPressed = true;
        if(process_data[0].velocity == 0)
            motorIsMoving = false;

        process_data[1].roller_on = (EC_READ_U8(domain1_pd + offset[0].roller_on) & (1 << 2)) >> 2;
        process_data[1].roller_to = (EC_READ_U8(domain1_pd + offset[0].roller_to) & (1 << 3)) >> 3;
        process_data[0].left_coupling = (EC_READ_U8(domain1_pd + offset[0].left_coupling) & (1 << 4)) >> 4;
        process_data[0].right_coupling = (EC_READ_U8(domain1_pd + offset[0].right_coupling) & (1 << 5)) >> 5;
        process_data[0].brake = (EC_READ_U8(domain1_pd + offset[0].brake) & (1 << 6)) >> 6;

        process_data[0].flour_duster = (EC_READ_U8(domain1_pd + offset[0].flour_duster) & 1);
        process_data[0].dough_reeler_close = (EC_READ_U8(domain1_pd + offset[0].dough_reeler_close) & (1 << 1)) >> 1;
        process_data[0].dough_reeler_on = (EC_READ_U8(domain1_pd + offset[0].dough_reeler_on) & (1 << 2)) >> 2;

        process_data[0].io_reeler_out4 = process_data[0].dough_reeler_close;
        process_data[0].io_reeler_out5 = process_data[0].dough_reeler_on;

        /*if(process_data[1].roller_on == 0 && process_data[1].roller_to == 0 && testCounter > 0){

          testCounter += 1;
          if(testCounter == 100){
              printf("Finshed Gap stopped in  Gap in int: %u \n",
                    process_data[1].position);
              testCounter = 0;
          }
        }else{
            //printf("Cureeent ..........Gap in GrayCode: %u,  Gap in int: %u \n",
            //            process_data[1].current_gap_position_raw, process_data[1].current_gap_position);
        }*/

         {
             std::lock_guard<std::mutex> lock(lock_command_data[0]);
             //If safty gurad is opened, clear the output of Autoreeler and stop all motor movements
             if(process_data[0].safty_guard != 1){
                 digitalOutput1_4bit = 0;  //clear bit 1, for clear the auto reeler output
                 digitalOutput0_8bit = 0;  //clear all ouputs
                 securityStopCnt = 0;
                 command_data[0].target_velocity_new = false;
                 command_data[0].brake_new = false;
                 command_data[0].flour_duster_new = false;
                 command_data[0].dough_reeler_on_new = false;
                 command_data[1].target_position_raw_new = false;
             }

             process_data[0].target_velocity = command_data[0].target_velocity;
             if(process_data[0].velocity != command_data[0].target_velocity && command_data[0].target_velocity_new) {

                 if(securityStopCnt > 0)
                     securityStopCnt += 1;

                 if(securityStopCnt > securityStopLimit)
                     securityStopCnt = 0;

                 if(command_data[0].target_velocity == -1){  //go to left
                    //Check if the movement of the other has been stopped first
                    if(securityStopCnt > 1 && securityStopCnt < securityStopLimit){
                        digitalOutput0_8bit &= ~(1UL << 0);
                        digitalOutput0_8bit &= ~(1UL << 1);
                        digitalOutput0_8bit &= ~(1UL << 4);
                        digitalOutput0_8bit &= ~(1UL << 5);

                    }else{
                     //if coupling is correct, then turn on the motor
                     if(process_data[0].right_coupling == 1){
                         //digitalOutput0_8bit = 0b00100001;
                         digitalOutput0_8bit |= 1UL << 0;
                         digitalOutput0_8bit |= 1UL << 5;
                         command_data[0].target_velocity_new = false;
                     }else{
                         //if coupling not correct, first set coupling right
                         digitalOutput0_8bit &= ~(1UL << 0);  //clear bit 0
                         digitalOutput0_8bit |= 1UL << 5;
                     }

                      securityStopCnt = 0;
                      securityStopLimit = securityStopLimitLeft;
                    }

                 }else if(command_data[0].target_velocity == 1){ // go to right
                     //Check if the movement of the other has been stopped first
                     if(securityStopCnt > 1 && securityStopCnt < securityStopLimit){
                         digitalOutput0_8bit &= ~(1UL << 0);
                         digitalOutput0_8bit &= ~(1UL << 1);
                         digitalOutput0_8bit &= ~(1UL << 4);
                         digitalOutput0_8bit &= ~(1UL << 5);

                     }else{
                         //if coupling is correct, then turn on the motor
                         if(process_data[0].left_coupling == 1){
                             digitalOutput0_8bit |= 1UL << 1;
                             digitalOutput0_8bit |= 1UL << 4;
                             command_data[0].target_velocity_new = false;
                         }else{
                             //if coupling not correct, first set coupling left
                             digitalOutput0_8bit &= ~(1UL << 1);  //clear bit 1
                             digitalOutput0_8bit |= 1UL << 4;
                         }
                         securityStopCnt = 0;
                         securityStopLimit = securityStopLimitRight;
                     }

                 }else if(command_data[0].target_velocity == 0){
                     securityStopCnt += 1;
                     digitalOutput0_8bit &= ~(1UL << 0);
                     digitalOutput0_8bit &= ~(1UL << 1);
                     digitalOutput0_8bit &= ~(1UL << 4);
                     digitalOutput0_8bit &= ~(1UL << 5);
                     if(command_data[0].target_velocity_new && securityStopCnt > securityStopLimit -1){
                         command_data[0].target_velocity_new = false;
                         securityStopCnt = 0;
                     }


                 }else{
                     //If the motor is still moving to the other direction, first wait till motor stopped
                     if(securityStopCnt == 0)
                         securityStopCnt = 1;

                     digitalOutput0_8bit &= ~(1UL << 0);
                     digitalOutput0_8bit &= ~(1UL << 1);
                     digitalOutput0_8bit &= ~(1UL << 4);
                     digitalOutput0_8bit &= ~(1UL << 5);
                 }

             }

             if((leftButtonPressed || rightButtonPressed) && !motorIsMoving){
                 if(command_data[0].target_velocity == 0 && command_data[0].target_velocity_new){
                     command_data[0].target_velocity_new = false;
                 }
                 securityStopCnt = 0;
             }


             if(process_data[0].brake != command_data[0].brake && command_data[0].brake_new) {
                 if(command_data[0].brake == 1){
                     digitalOutput0_8bit |= 1UL << 6;
                 }else{

                     digitalOutput0_8bit &= ~(1UL << 6);  //clear bit 6
                 }
                 command_data[0].brake_new = false;
             }

             if(process_data[0].flour_duster != command_data[0].flour_duster && command_data[0].flour_duster_new) {
                 if(command_data[0].flour_duster == 1){
                     digitalOutput1_4bit |= 1UL;
                 }else{
                     digitalOutput1_4bit &= ~(1UL);  //clear bit 0
                 }
                 command_data[0].flour_duster_new = false;
             }

             if(process_data[0].dough_reeler_on != command_data[0].dough_reeler_on && command_data[0].dough_reeler_on_new) {
                 if(command_data[0].dough_reeler_on == 1){
                      digitalOutput1_4bit |= 1UL << 2;
                      //digitalOutput1_4bit &= ~(1UL << 1); //clear bit 1
                  }else{

                      digitalOutput1_4bit &= ~(1UL << 2);  //clear bit 2
                  }
                  command_data[0].dough_reeler_on_new = false;
             }

             if(process_data[0].dough_reeler_close != command_data[0].dough_reeler_close && command_data[0].dough_reeler_close_new) {
                 if(command_data[0].dough_reeler_close == 1){
                      digitalOutput1_4bit |= 1UL << 1;
                      //digitalOutput1_4bit |= 1UL << 2; // set open also true
                  }else{

                      digitalOutput1_4bit &= ~(1UL << 2);  //clear bit 1
                  }
                  command_data[0].dough_reeler_close_new = false;
             }

             if(process_data[0].io_reeler_out4 != command_data[0].io_reeler_out4 && command_data[0].io_reeler_out4_new) {
                 if(command_data[0].io_reeler_out4 == 1){
                     digitalOutput1_4bit |= 1UL << 1;
                 }else{

                     digitalOutput1_4bit &= ~(1UL << 1);  //clear bit 0
                 }
                 command_data[0].io_reeler_out4_new = false;
             }

             if(process_data[0].io_reeler_out5 != command_data[0].io_reeler_out5 && command_data[0].io_reeler_out5_new) {
                 if(command_data[0].io_reeler_out5 == 1){
                     digitalOutput1_4bit |= 1UL << 2;
                 }else{

                     digitalOutput1_4bit &= ~(1UL << 2);  //clear bit 1
                 }
                 command_data[0].io_reeler_out5_new = false;
             }

             if(process_data[0].left_coupling != command_data[0].io_leftCoupling_out6 && command_data[0].io_leftCoupling_out6_new) {
                 if(command_data[0].io_leftCoupling_out6 == 1){
                     digitalOutput0_8bit |= 1UL << 4;
                 }else{

                     digitalOutput0_8bit &= ~(1UL << 4);  //clear bit 1
                 }
                 command_data[0].io_leftCoupling_out6_new = false;
             }

             if(process_data[0].right_coupling != command_data[0].io_rightCoupling_out8 && command_data[0].io_rightCoupling_out8_new) {
                 if(command_data[0].io_rightCoupling_out8 == 1){
                     digitalOutput0_8bit |= 1UL << 5;
                 }else{

                     digitalOutput0_8bit &= ~(1UL << 5);  //clear bit 1
                 }
                 command_data[0].io_rightCoupling_out8_new = false;
             }

             std::lock_guard<std::mutex> lock2(lock_command_data[1]);

             uint8_t currentVal = process_data[1].position;
             uint8_t targetVal = command_data[1].target_position;
             process_data[1].target_position = targetVal;
             process_data[1].target_position_raw = targetVal;

             if(breakCnt > 0)
                    breakCnt += 1;

             // For control the gap motor open or close in the calibration page
              if(command_data[1].target_position_raw_new){
                  if(command_data[1].target_position_raw > 0){
                      gapMotorOpenCloseStepCnt += 1;
                      //Walz auf / go up
                      digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                      digitalOutput0_8bit |= 1UL << 2;     //set bit 2
                      if(gapMotorOpenCloseStepCnt > gapMotorOpenCloseStepLimit){
                          digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                          digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                          command_data[1].target_position_raw_new = false;
                          gapMotorOpenCloseStepCnt = 0;
                      }

                  }else if(command_data[1].target_position_raw < 0){
                      gapMotorOpenCloseStepCnt += 1;
                      //Walz auf / go down
                      digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                      digitalOutput0_8bit |= 1UL << 3;     //set bit 3
                      if(gapMotorOpenCloseStepCnt > gapMotorOpenCloseStepLimit){
                          digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                          digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                          command_data[1].target_position_raw_new = false;
                          gapMotorOpenCloseStepCnt = 0;
                      }

                  }else{
                      digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                      digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                      command_data[1].target_position_raw_new = false;
                      gapMotorOpenCloseStepCnt = 0;
                  }
              }

             if(process_data[1].position  != command_data[1].target_position
                                                  && command_data[1].target_position_new) {

                 //This is the offsets based on the measurement of the different ranges
                 if((targetVal >=60 && targetVal <= 255 && currentVal >= 58 && currentVal <= 255)) {
                     int diff = targetVal - currentVal;
                     if(diff >2){ //Walz soll zu / go down
                         digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                         digitalOutput0_8bit |= 1UL << 3;     //set bit 3

                     }else if(diff < -2){ //Walz soll auf / go up
                         digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                         digitalOutput0_8bit |= 1UL << 2;     //set bit 2


                     }
                 }else if(targetVal >=0 && targetVal <= 50 && currentVal >= 56 && currentVal <= 255){
                     int diff = targetVal + 255 - currentVal;
                      //Walz soll zu / go down
                     if(diff >2){ //Walz soll zu / go down
                         digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                         digitalOutput0_8bit |= 1UL << 3;     //set bit 3
                     }

                 }else if(targetVal >=60 && targetVal <= 255 && currentVal >= 0 && currentVal <= 50){
                     int diff = currentVal + 255 - targetVal;
                      //Walz soll auf / go up
                     if(diff >2){
                          digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                          digitalOutput0_8bit |= 1UL << 2;     //set bit 2

                     }

                 }else if(targetVal >=0 && targetVal <= 50 && currentVal >= 0 && currentVal <= 50){
                     int diff = targetVal - currentVal;
                     if(diff >2){ //Walz soll zu / go down
                         digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                         digitalOutput0_8bit |= 1UL << 3;     //set bit 3

                     }else if(diff < -2){ //Walz soll auf / go up

                         digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                         digitalOutput0_8bit |= 1UL << 2;     //set bit 2

                     }

                 }else{
                     printf("Something wrong here, out of range: curent: %u ,  target: %u.", currentVal, targetVal);
                 }

             }

             if(command_data[1].target_position_new){
                 if(process_data[1].roller_on && breakDirection == 0){ // Gap moving up
                     int diff = currentVal - targetVal;
                     if(diff < 0 ){ //target in range 1, current in range 0
                       diff = 255 - targetVal + currentVal;
                     }
                     int stopOffset = 1;
                     if( (targetVal >= 10 && targetVal <= 50) ||  (targetVal >= 60 && targetVal <= 115))
                                   stopOffset = 2;
                     if(diff <= stopOffset ){
                          //printf(" -----begin to stop go up current gap code: %u-------\n", process_data[1].position);
                          digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                          digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                          digitalOutput0_8bit |= 1UL << 6;   //active break
                          testCounter = 1;
                          if(breakCnt == 0){
                              breakCnt = 1;
                              breakDirection = -1;
                          }
                     }



                 }else if(process_data[1].roller_to && breakDirection == 0 ){ // Gap moving down
                     int diff = targetVal - currentVal;
                      if(diff < 0 ){ //target in range 1, current in range 0
                          diff = 255 - currentVal + targetVal;
                      }
                      int stopOffset = 1;
                      if((targetVal >= 10 && targetVal <= 50) ||  (targetVal >= 60 && targetVal <= 115) )
                                    stopOffset = 2;

                     if(diff <= stopOffset ){
                          //printf(" -----begin to stop go down current gap code: %u-------\n", process_data[1].position);
                          digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                          digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                          digitalOutput0_8bit |= 1UL << 6;   //active break
                          testCounter = 1;
                          if(breakCnt == 0){
                              breakCnt = 1;
                              breakDirection = 1;
                          }
                     }

                 }
                 else{

                     if(breakCnt > 1){
                         if(breakDirection == 1){
                             //printf("Begin to BREAK, breaker moving up........................... \n");
                             digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                             digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                             digitalOutput0_8bit |= 1UL << 6;   //active break

                         }else {
                             //printf("Begin to BREAK, breaker moving down........................... \n");
                             digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                             digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                             digitalOutput0_8bit |= 1UL << 6;   //active break

                         }

                     }

                     if(breakCnt > 8){
                         //printf("Finish BREAK ........................... \n");
                         digitalOutput0_8bit &= ~(1UL << 2);  //clear bit 2
                         digitalOutput0_8bit &= ~(1UL << 3);  //clear bit 3
                         digitalOutput0_8bit &= ~(1UL << 6);  //clear bit 3
                         command_data[1].target_position_new = 0;//false;
                         breakCnt = 0;
                         breakDirection = 0;
                     }

                 }
             }

         }


        EC_WRITE_U8(domain1_pd + offset[0].left_motor_on, digitalOutput0_8bit);
        EC_WRITE_U8(domain1_pd + offset[0].flour_duster, digitalOutput1_4bit);
        // Try to write updated process data to double-buffer, skip if locked
        if (lock_process_data[0].try_lock()) {
            memcpy(&process_data_buffer[0], &process_data[0], sizeof(process_data[0]));
            lock_process_data[0].unlock();
        }

        if (lock_process_data[1].try_lock()) {
            memcpy(&process_data_buffer[1], &process_data[1], sizeof(process_data[1]));
            lock_process_data[1].unlock();
        }
    //}

        int delayCnt = SystemConfig::ecostar_stop_delay / 5;
        if(securityStopLimitRight != delayCnt && delayCnt > 9){
            securityStopLimitRight = delayCnt;
            securityStopLimitLeft = securityStopLimitRight - 5;
        }

    if (counter) {
        counter--;
    } else { // do this at 1 Hz
        counter = settings::FREQUENCY;

        // check for master state (optional)
        check_master_state();

        // check for slave configuration state(s) (optional)
        check_slave_config_states();

    }

    // send process data
    ecrt_domain_queue(ec::domain1);
    ecrt_master_send(ec::master);

    if(clearMinor){
        EC_WRITE_U8(ecrt_sdo_request_data(sendClearMinor), 0x01);
        switch (ecrt_sdo_request_state(sendClearMinor)) {
                case EC_REQUEST_UNUSED: // request was not used yet
                  {
                    ecrt_sdo_request_write(sendClearMinor);
                    break;
                 }
               case EC_REQUEST_BUSY:
                   {
                    break;
                   }
                case EC_REQUEST_SUCCESS:
                    {
                    clearMinor = false;
                    break;
                    }
               case EC_REQUEST_ERROR:
                   ecrt_sdo_request_write(sendClearMinor);
            }
       }

    if(needGetLoggerIndex){ //get the new error logger index
        switch (ecrt_sdo_request_state(errorLogs[0x02])){
          case EC_REQUEST_UNUSED: // request was not used yet
             {
               ecrt_sdo_request_read(errorLogs[0x02]); // trigger first read
               break;
            }
          case EC_REQUEST_BUSY:
              {
               break;
              }
           case EC_REQUEST_SUCCESS:
               {
               newMsgIdx = EC_READ_U8(ecrt_sdo_request_data(errorLogs[0x02]));
               needGetLoggerIndex = false;
               loggerIndexSuccess = true;
               break;
               }
          case EC_REQUEST_ERROR:
              ecrt_sdo_request_read(errorLogs[0x02]); // retry reading
        }
    }

    if(loggerIndexSuccess && newMsgIdx > 5 && newMsgIdx < 134){ //using index to get the error code
        switch (ecrt_sdo_request_state(errorLogs[newMsgIdx])){
          case EC_REQUEST_UNUSED: // request was not used yet
             {  ecrt_sdo_request_read(errorLogs[newMsgIdx]); // trigger first read
               break;
            }
          case EC_REQUEST_BUSY:
              {
               break;
              }
           case EC_REQUEST_SUCCESS:
               {
               errorCodeEcoStar = EC_READ_U32(ecrt_sdo_request_data(errorLogs[newMsgIdx]));
               if(errorCodeEcoStar == 0x0000E800) //docu page 440
                   errorCodeEcoStar = 0;
               loggerIndexSuccess = false;
               break;
               }
          case EC_REQUEST_ERROR:
              ecrt_sdo_request_read(errorLogs[newMsgIdx]); // retry reading
        }
    }
}

#else

static unsigned int prev_control[NUMBER_MOTORS] = {0xFFFFu,0xFFFFu,0xFFFFu,0xFFFFu};
static uint16_t prev_status[NUMBER_MOTORS] = {0,0,0,0};
static uint16_t prev_error[NUMBER_MOTORS] = {0x8000u,0x8000u,0x8000u,0x8000u};

static Average<int16_t, int32_t, 5> aTransport;

void cyclic_task()
{
    //Check the periode time
    clock_gettime(CLOCK_MONOTONIC, &startTime);
    period_ns = (startTime.tv_sec - lastStartTime.tv_sec) * settings::NSEC_PER_SEC +
                                              startTime.tv_nsec - lastStartTime.tv_nsec;

    if(period_ns < 1500000){
        logMotors.fmt("Period is too short, period_ns: %10u, less than 1.5 ms, so just return\n",period_ns );
        return;
    }
    lastStartTime = startTime;

    // set acceleration/deceleration
    reqMaxVGap.check_write();
    reqAccGap.check_write();
    reqDecGap.check_write();

    // receive process data
    ecrt_master_receive(ec::master);
    ecrt_domain_process(ec::domain1);

    // check process data state
    check_domain1_state();

    //------ Check if saty cage is open -----------------
    uint32_t digitalIns = EC_READ_U32(domain1_pd + offset[digitalInOutputServoIndex].digital_in);
    bool saftyCageOpen =(digitalIns & status::mon::MON1);

    for (uint16_t servo_idx = 0; servo_idx < NUMBER_MOTORS; servo_idx++) {
        // Read process data into custom struct
        process_data[servo_idx].status = EC_READ_U16(domain1_pd + offset[servo_idx].status);
        process_data[servo_idx].error = EC_READ_U16(domain1_pd + offset[servo_idx].error);
        process_data[servo_idx].target_position = EC_READ_S32(domain1_pd + offset[servo_idx].target_position);
        process_data[servo_idx].target_position_raw = EC_READ_S32(domain1_pd + offset[servo_idx].target_position_raw);
        process_data[servo_idx].position = EC_READ_S32(domain1_pd + offset[servo_idx].position);
        process_data[servo_idx].torque = EC_READ_S16(domain1_pd + offset[servo_idx].torque);
        process_data[servo_idx].target_velocity = EC_READ_S32(domain1_pd + offset[servo_idx].target_velocity);
        process_data[servo_idx].target_velocity_raw = EC_READ_S32(domain1_pd + offset[servo_idx].target_velocity_raw);
        process_data[servo_idx].velocity = EC_READ_S32(domain1_pd + offset[servo_idx].actual_velocity);
        process_data[servo_idx].digital_in = EC_READ_U32(domain1_pd + offset[servo_idx].digital_in);
        process_data[servo_idx].digital_out = EC_READ_U32(domain1_pd + offset[servo_idx].digital_out);

        din_latch[servo_idx] |= process_data[servo_idx].digital_in;
        dout_latch[servo_idx] |= process_data[servo_idx].digital_out;

        // The Leading 0xff00 determines that this is the vendor specific error area
        // The lower word contains the actual error number
        // The two digit hex number is the general error class. In the datasheet, two additional numbers determine the sub-error"
        // Some classes only have one error, some have many very fine-grained suberrors
        // process_data[servo_idx].error &= 0xff;

        // log motor status
        uint16_t tmpstatus = process_data[servo_idx].status;
        if(servo_idx!=3) tmpstatus &= ~status_bit::PV_TARGET_REACHED; // reached-bit toggles too often, so masked
        if(tmpstatus != prev_status[servo_idx]) {
            prev_status[servo_idx] = tmpstatus;
            std::string st_message="";
            if(tmpstatus & status_bit::FAULT) st_message += "FAULT.";
            if(tmpstatus & status_bit::WARNING) st_message += "WARN.";
            if(tmpstatus & status_bit::HM_HOMING_ERROR) st_message += "ERROR.";
            if(tmpstatus & status_bit::PV_ZERO_SPEED) st_message += "ZERO.";
            if(tmpstatus & status_bit::PP_TARGET_REACHED) st_message += "REACHED.";
            if(tmpstatus & status_bit::QUICKSTOP) st_message += "QSTOP.";
            if(tmpstatus & status_bit::SWITCHED_ON) st_message += "SW-ON.";
            if(tmpstatus & status_bit::READY_SWITCH_ON) st_message += "SW-EN.";
            if(tmpstatus & status_bit::SWITCH_ON_DISABLED) st_message += "SW-DIS.";
            if(tmpstatus & status_bit::VOLTAGE_ENABLED) st_message += "VLT-EN.";
            if(tmpstatus & status_bit::OPERATION_ENABLED) st_message += "OP-EN.";
            if(tmpstatus & status_bit::INTERNAL_LIMIT_ACT) st_message += "LIM-ACT.";
            logMotors.fmt("servo[%d] STATUS = 0x%04hX ...%s pos=%u",servo_idx,prev_status[servo_idx], st_message.c_str(),uint32_t(process_data[servo_idx].position));
        }
        // log motor error
        if(process_data[servo_idx].error != prev_error[servo_idx]) {
            prev_error[servo_idx] = process_data[servo_idx].error;
            auto error_message = errors::get_description(prev_error[servo_idx]);
            logMotors.fmt("servo[%d] ERROR = 0x%04hX ... %s",servo_idx,prev_error[servo_idx],error_message.c_str());
        }

        auto _status = status::remove_vendor_extension(process_data[servo_idx].status);

        auto st_filtered = process_data[servo_idx].status & (
                    status_bit::FAULT |
                    status_bit::WARNING |
                    status_bit::QUICKSTOP |
                    status_bit::SWITCHED_ON |
                    status_bit::READY_SWITCH_ON |
                    status_bit::VOLTAGE_ENABLED |
                    status_bit::SWITCH_ON_DISABLED |
                    status_bit::OPERATION_ENABLED |
                    0);
        bool servo_enabled = false;
        if(st_filtered == (
                    status_bit::QUICKSTOP|
                    status_bit::SWITCHED_ON|
                    status_bit::READY_SWITCH_ON|
                    status_bit::VOLTAGE_ENABLED|
                    status_bit::OPERATION_ENABLED|
                    0)) servo_enabled = true;
        if(saftyCageOpen) servo_enabled = false;

        // automatically move from SWITCH_ON_DISABLED -> READY_SWITCH_ON
        if(command_data[servo_idx].control == cmd::ENABLE_SYSTEM) {
            std::lock_guard<std::mutex> lock(lock_command_data[servo_idx]);
            if(command_data[servo_idx].control == cmd::ENABLE_SYSTEM) {
                command_data[servo_idx].control = cmd::TURN_ON;
            }
        }
        bool send_enable_system = false;
        if (_status == status::SWITCH_ON_DISABLED) {
            //std::lock_guard<std::mutex> lock(lock_command_data[servo_idx]);
            //command_data[servo_idx].control = cmd::ENABLE_SYSTEM;
            send_enable_system = true;
        }

        if(send_enable_system || (command_data[servo_idx].control&(cmd_bit::ENABLE_OPERATION))==0) servo_enabled = false;

        // if a motor goes into the software position limit,
        // it will no longer be OPERATION enabled, but we still need to give position commands
        // in order to drive out of the position limit
        {
            std::lock_guard<std::mutex> lock(lock_command_data[servo_idx]);

            if(servo_enabled) {

                if(/*process_data[servo_idx].target_position != command_data[servo_idx].target_position &&*/ command_data[servo_idx].target_position_new) {
                    logMotors.fmt("write %u into target_position[%hu]",uint32_t(command_data[servo_idx].target_position),servo_idx);
                    EC_WRITE_S32(domain1_pd + offset[servo_idx].target_position, command_data[servo_idx].target_position);
                    command_data[servo_idx].target_position_new--;
                    command_data[servo_idx].control |= cmd_bit::NEW_SETPOINT;
                }else if(command_data[servo_idx].target_position_raw_new) { // For control the gap motor open or close in the calibration page
                    int32_t newPos =  command_data[servo_idx].target_position_raw + process_data[servo_idx].position;
                    logMotors.fmt("write %u into target_position_raw[%hu]",uint32_t(newPos),servo_idx);
                    EC_WRITE_S32(domain1_pd + offset[servo_idx].target_position, newPos);
                    command_data[servo_idx].target_position_raw_new = false;
                    command_data[servo_idx].control |= cmd_bit::NEW_SETPOINT;
                }
                else {
                    command_data[servo_idx].control &= ~cmd_bit::NEW_SETPOINT;
                }

                if(process_data[servo_idx].target_velocity != command_data[servo_idx].target_velocity && command_data[servo_idx].target_velocity_new) {
                    logMotors.fmt("write %d into target_velocity[%hu]",command_data[servo_idx].target_velocity,servo_idx);
                    EC_WRITE_S32(domain1_pd + offset[servo_idx].target_velocity, command_data[servo_idx].target_velocity);
                    command_data[servo_idx].target_velocity_new = false;
                }

                if(process_data[servo_idx].digital_out != command_data[servo_idx].digital_out && command_data[servo_idx].digital_out_new) {
                    logMotors.fmt("Writing digital out for servo[%d]: 0x%X\n", servo_idx, command_data[servo_idx].digital_out);
                    EC_WRITE_U32(domain1_pd + offset[servo_idx].digital_out, command_data[servo_idx].digital_out);
                    command_data[servo_idx].digital_out_new = false;
                }

            }else if(saftyCageOpen) {
                //If safty cage is open, clear the command status
                //clear all the comannd state, and clear all the digital output
                //need wait the user input to continue the movement

                 if(servo_idx == digitalInOutputServoIndex){
                   command_data[servo_idx].digital_out_new = false;
                   if(process_data[servo_idx].digital_out != 0){
                       EC_WRITE_U32(domain1_pd + offset[servo_idx].digital_out, 0);
                   }
                 }
                 if(servo_idx == gapMotorServoIndex){
                     command_data[servo_idx].target_position_raw_new = false;
                     command_data[servo_idx].target_position_new = false;
                     command_data[servo_idx].control &= ~cmd_bit::NEW_SETPOINT; // clear new position bit
                 }else{
                     //Set the motor velocity as 0
                     command_data[servo_idx].target_velocity_new = false;
                     if(process_data[servo_idx].target_velocity != 0){
                         EC_WRITE_S32(domain1_pd + offset[servo_idx].target_velocity, 0);
                     }
                 }

            }//------------------if else (!saftyCageOpen)  done  --------------------------

            uint32_t ctl = command_data[servo_idx].control;
            if(send_enable_system) ctl = cmd::ENABLE_SYSTEM;
            if(prev_control[servo_idx] != ctl) {
                std::string st_ctrl = ".";
                if(ctl & cmd_bit::HALT) st_ctrl += "HLT.";
                if(ctl & cmd_bit::RESET) st_ctrl += "RST.";
                if(ctl & cmd_bit::ABSOLUTE) st_ctrl += "ABS.";
                if(ctl & cmd_bit::IMMEDIATE) st_ctrl += "IMM.";
                if(ctl & cmd_bit::NEW_SETPOINT) st_ctrl += "SETP.";
                if(ctl & cmd_bit::ENABLE_OPERATION) st_ctrl += "ENB.";
                if(ctl & cmd_bit::QUICKSTOP) st_ctrl += "QSTP.";
                if(ctl & cmd_bit::ENABLE_VOLTAGE) st_ctrl += "VOLT.";
                if(ctl & cmd_bit::SWITCH_ON) st_ctrl += "ON.";
                logMotors.fmt("Writing control for servo[%d]: 0x%X ...%s\n", servo_idx, ctl, st_ctrl.c_str());
                prev_control[servo_idx] = ctl;
            }
            EC_WRITE_U16(domain1_pd + offset[servo_idx].control, ctl);
        }

        // Try to write updated process data to double-buffer, skip if locked
        if (lock_process_data[servo_idx].try_lock()) {
            memcpy(&process_data_buffer[servo_idx], &process_data[servo_idx], sizeof(process_data[servo_idx]));
            lock_process_data[servo_idx].unlock();
        }
    }

    if(SystemConfig::transport_mode!=SystemConfig::TransportMode::NONE){
        process_data_ext.digital_out_ext  =  EC_READ_U8(domain1_pd + 34);
        int16_t ainput = EC_READ_S16(domain1_pd + 36);
        if(ainput != 32767) {
            if(ainput<0) ainput = 0;
            aTransport.add(ainput);
            process_data_ext.analog_in_ext  =  aTransport.value();
        }
        //printf(" --------------  %u ,  %d .......................\n", process_data_ext.digital_out_ext, process_data_ext.analog_in_ext);
        if (lock_process_data_ext.try_lock()) {
            memcpy(&process_data_buffer_ext, &process_data_ext, sizeof(process_data_ext));
            lock_process_data_ext.unlock();
        }
    }

    if (counter) {
        counter--;
    } else { // do this at 1 Hz
        counter = settings::FREQUENCY;

        // check for master state (optional)
        check_master_state();

        // check for slave configuration state(s) (optional)
        check_slave_config_states();

//        // we don't need it anymore, errors logged into logMotors
//        for (uint16_t servo_idx = 0; servo_idx < NUMBER_MOTORS; servo_idx++) {
//            if(process_data[servo_idx].error) {
//                auto error_message = errors::get_description(process_data[servo_idx].error);
//                printf("servo[%d] error 0x%hX: %s\n", servo_idx, process_data[servo_idx].error, error_message.c_str());
//            }
//        }
    }

    // send process data
    ecrt_domain_queue(ec::domain1);
    ecrt_master_send(ec::master);
}
#endif

void stack_prefault(void)
{
    unsigned char dummy[settings::MAX_SAFE_STACK];
    memset(dummy, 0, settings::MAX_SAFE_STACK);
}

int main(int argc, char **argv)
{
    // set SYSTEM CONFIGURATION
    SystemConfig::init_system_config();

    // set PERIOD_NS from environment variable
    char *env_period = std::getenv("RONDO_PERIOD_MS");
    if(!env_period) env_period = std::getenv("PERIOD_MS");
    if(env_period) {
        char *end = nullptr;
        double val = std::strtod(env_period,&end);
        if(end!=nullptr && *end==0 && val>=0.1 && val<=20.0) {
            settings::PERIOD_NS = uint32_t(std::round(val * 1000000.0));
            if(settings::PERIOD_NS<100000u || settings::PERIOD_NS>20000000u) settings::PERIOD_NS = 5000000u;
            settings::FREQUENCY = uint16_t(settings::NSEC_PER_SEC / settings::PERIOD_NS);
            printf("settings::PERIOD_NS changed to %u ns\n", settings::PERIOD_NS);
        }
    }

    // set TRIGGER_PIN from environment variable
    char *trg_pin = std::getenv("RONDO_TRIGGER_PIN");
    if(!trg_pin) trg_pin = std::getenv("TRIGGER_PIN");
    if(trg_pin) {
        bool inv = false;
        if(*trg_pin=='!') {inv=true; trg_pin++;}
        char *end = nullptr;
        int pin = std::strtol(trg_pin, &end, 10);
        if(end && end[0]=='@' && end[1]>='1' && end[1]<='4' && end[2]==0) {
            settings::trigger_drive = end[1] - '1';
            end += 2;
        }
        if(end && *end==0 && pin>=5 && pin<=8) {
            settings::trigger_pin = pin;
            settings::do_invert_trigger = inv;
            printf("settings::trigger_pin changed to %c%d@%d\n", settings::do_invert_trigger?'!':' ', settings::trigger_pin, settings::trigger_drive);
        }
    }

    // open autoreel on startup
    if(SystemConfig::typ!=SystemConfig::ECOSTAR) {
        command_data[1].digital_out = 0x00010000;
        command_data[1].digital_out_new = true;
    }else{//read the calibration offset for EcoStar from system enviroment variable
        settings::PERIOD_NS = 5000000;  //5ms for ecostar
        settings::FREQUENCY = settings::NSEC_PER_SEC / settings::PERIOD_NS;

        char *env_offset = std::getenv("RONDO_ECOSTAR_GAP_OFFSET");
        if(env_offset) {
            char *end = nullptr;
            int val = std::strtod(env_offset,&end);
            if(end!=nullptr && *end==0 && val>=-50 && val<=50) {
                  ecostarGapOffset = val;
            }
        }
    }

    // TODO: Move this when we have calibration -> it WILL cause problems with uncalibrated machines!

    setup_master();
    initialSDOaccess(); // This must be before the initialize_devices
    if(SystemConfig::typ!=SystemConfig::ECOSTAR){
        setup_device_parameters();        
    }
    initialize_devices();

    // trace all offsets
    #define DOFF(t) fprintf(stderr, "0x%08X: offset[%u].%s", offset[i]. t, i, #t)
    for(size_t i=0; i<sizeof(offset)/sizeof(offset[0]); i++) {
#if NUMBER_MOTORS == 2
        DOFF(brake);
        DOFF(error);
        DOFF(roller_on);
        DOFF(roller_to);
        DOFF(left_button);
        DOFF(safty_guard);
        DOFF(stop_button);
        DOFF(flour_duster);
        DOFF(gap_position);
        DOFF(right_button);
        DOFF(laser_trigger);
        DOFF(left_coupling);
        DOFF(left_motor_on);
        DOFF(right_coupling);
        DOFF(right_motor_on);
        DOFF(dough_reeler_on);
        DOFF(dough_reeler_close);
#else
        DOFF(control);
        DOFF(target_velocity);
        DOFF(target_position);
        DOFF(digital_out);
        DOFF(status);
        DOFF(error);
        DOFF(actual_velocity);
        DOFF(target_velocity_raw);
        DOFF(position);
        DOFF(target_position_raw);
        DOFF(torque);
        DOFF(digital_in);
#endif
    }

#if NUMBER_MOTORS != 2
    fprintf(stderr, "0x%08X: offset[digital_ext]", 34);
    fprintf(stderr, "0x%08X: offset[analog_ext]", 36);
#endif

    for (auto& l : din_latch) {
        l = 0;
    }
    for (auto& l : dout_latch) {
        l = 0;
    }

    /* Set priority */

    pid_t pid = getpid();
    if (setpriority(PRIO_PROCESS, pid, -19)) {
        fprintf(stderr, "Warning: Failed to set priority: %s\n",
                strerror(errno));
    }

    /* Lock memory */

    if (mlockall(MCL_CURRENT | MCL_FUTURE) == -1) {
        fprintf(stderr, "Warning: Failed to lock memory: %s\n",
                strerror(errno));
    }

    stack_prefault();

    printf("Starting RT task with dt=%u ns.\n", settings::PERIOD_NS);

    struct timespec wakeup_time;

    clock_gettime(CLOCK_MONOTONIC, &wakeup_time);
    wakeup_time.tv_sec += 1; /* start in future */
    wakeup_time.tv_nsec = 0;

    std::thread t1(nanomsg_publish_loop);
    std::thread t2(nanomsg_command_loop);
    std::thread t3(interpreter_loop);

    int ret = 0;

    while (1) {
        ret = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME,
                &wakeup_time, NULL);
        if (ret) {
            fprintf(stderr, "clock_nanosleep(): %s\n", strerror(ret));
            break;
        }

        cyclic_task();

        wakeup_time.tv_nsec += settings::PERIOD_NS;
        while (wakeup_time.tv_nsec >= settings::NSEC_PER_SEC) {
            wakeup_time.tv_nsec -= settings::NSEC_PER_SEC;
            wakeup_time.tv_sec++;
        }
    }

    return ret;
}
