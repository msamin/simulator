#include <machine_interface.hpp>

#include <nanomsg/nn.h>
#ifdef WITH_SIMULATOR
#include <nanomsg/inproc.h>
#else
#include <nanomsg/tcp.h>
#endif
#include <nanomsg/pubsub.h>
#include <nanomsg/reqrep.h>

#include <cmath>

#include <stdlogger.h>
#include <systemconfig.h>

#define NUMBER_MOTORS_TMP (SystemConfig::typ==SystemConfig::ECOSTAR?2:4)

using namespace sheeter2020;

uint32_t machine_interface_t::current_rightbelt_position() const {
    return uint32_t(m_current_rightbelt_position);
}

uint32_t machine_interface_t::current_rightbelt_rawposition() const {
    return uint32_t(m_current_rightbelt_rawposition);
}

uint32_t machine_interface_t::current_leftbelt_position() const {
    return uint32_t(m_current_leftbelt_position);
}

uint32_t machine_interface_t::current_leftbelt_rawposition() const {
    return uint32_t(m_current_leftbelt_rawposition);
}

uint32_t machine_interface_t::current_drum_position() const {
    return uint32_t(m_current_drum_position);
}

uint32_t machine_interface_t::current_drum_rawposition() const {
    return uint32_t(m_current_drum_rawposition);
}

int machine_interface_t::current_gapsize() const {
    for (int i = 0; i < m_current_status.statuses_size(); i++) {
        const ServoStatus &s = m_current_status.statuses(i);
        if (s.servo_id() == GAP_IDX and s.has_position()) {
            return s.position();
        }
    }
    return -1;
}
int machine_interface_t::current_target_gapsize() const {
    for (int i = 0; i < m_current_status.statuses_size(); i++) {
        const ServoStatus &s = m_current_status.statuses(i);
        if (s.servo_id() == GAP_IDX and s.has_target_pos()) {
            return s.target_pos();
        }
    }
    return -1;
}

machine_interface_t::machine_interface_t() {
    m_last_gapsize_reached = false;
#ifdef WITH_SIMULATOR
    servo_pause_ms = 1;
#else
    servo_pause_ms = 1000;
#endif
    char *servo_pause_txt = std::getenv("RONDO_PAUSE_MS");
    if(!servo_pause_txt) servo_pause_txt = std::getenv("SERVO_PAUSE_MS");
    if(servo_pause_txt) {
        char *end = nullptr;
        int pause_ms = std::strtol(servo_pause_txt, &end, 10);
        if(end && *end==0 && pause_ms>=1000 && pause_ms<=3000) {
            servo_pause_ms = pause_ms;
            printf("servo pause changed to %d ms\n", servo_pause_ms);
        }
    }

    m_ts_earliest_next_turn_on = clock::now() - std::chrono::seconds(20);
    m_log_servo_delay = true;
    m_current_belts_direction = 0;
    m_current_status.Clear();
    m_current_rightbelt_position = 0;
    m_current_rightbelt_rawposition = 0;
    m_current_leftbelt_position = 0;
    m_current_leftbelt_rawposition = 0;
    m_current_drum_position = 0;
    m_current_drum_rawposition = 0;
    m_servo_status_s = nn_socket(AF_SP, NN_SUB);
    if (m_servo_status_s < 0) {
        int error = nn_errno();
        printf("Error creating servo status subscriber: %s", nn_strerror(error));
    }
#ifdef WITH_SIMULATOR
    m_servo_status_e = nn_connect(m_servo_status_s, "inproc://ctrlstatus8080");
#else
    m_servo_status_e = nn_connect(m_servo_status_s, "tcp://127.0.0.1:8080");
#endif
    if (m_servo_status_e < 0) {
        int error = nn_errno();
        printf("Error connecting servo status: %s", nn_strerror(error));
    }
    if (nn_setsockopt(m_servo_status_s, NN_SUB, NN_SUB_SUBSCRIBE, "", 0) < 0) {
        int error = nn_errno();
        printf("Error subscribing servo status: %s", nn_strerror(error));
    }
    m_servo_cmd_s = nn_socket(AF_SP, NN_REQ);
    if (m_servo_cmd_s < 0) {
        int error = nn_errno();
        printf("Error creating servo cmd requester: %s", nn_strerror(error));
    }
#ifdef WITH_SIMULATOR
    m_servo_cmd_e = nn_connect(m_servo_cmd_s, "inproc://ctrlcmd8081");
#else
    m_servo_cmd_e = nn_connect(m_servo_cmd_s, "tcp://127.0.0.1:8081");
#endif
    if (m_servo_cmd_e < 0) {
        int error = nn_errno();
        printf("Error connecting servo cmd: %s", nn_strerror(error));
    }
}

machine_interface_t::~machine_interface_t() {
    int ret = nn_shutdown(m_servo_cmd_s, m_servo_cmd_e);
    if (ret < 0) {
        int error = nn_errno();
        printf("Error shutting down servo cmd endpoint: %s", nn_strerror(error));
    }
    ret = nn_close(m_servo_cmd_s);
    if (ret < 0) {
        int error = nn_errno();
        printf("Error closing servo cmd socket: %s", nn_strerror(error));
    }
    ret = nn_shutdown(m_servo_status_s, m_servo_status_e);
    if (ret < 0) {
        int error = nn_errno();
        printf("Error shutting down servo status endpoint: %s", nn_strerror(error));
    }
    ret = nn_close(m_servo_status_s);
    if (ret < 0) {
        int error = nn_errno();
        printf("Error closing servo status socket: %s", nn_strerror(error));
    }
}

ServoStatusBatch machine_interface_t::wait_for_new_status() {
    Status newStatus;
    newStatus.Clear();
    char *buf = nullptr;
    int nbytes = nn_recv(m_servo_status_s, &buf, NN_MSG, 0);
    if (nbytes < 0) {
        int error = nn_errno();
        printf("Error receiving status: %s", nn_strerror(error));
        if(buf) nn_freemsg(buf);
        buf = nullptr;
        return newStatus; // m_current_status;
    }

    if (not newStatus.ParseFromArray(buf, nbytes)) {
        printf("Unable to parse status!");
        nn_freemsg(buf);
        buf = nullptr;
        throw std::runtime_error(std::string(buf, nbytes));
    }

    if(buf) nn_freemsg(buf);
    buf = nullptr;

    m_ts_last_servo_status = m_ts_current_servo_status;
    m_ts_current_servo_status = clock::now();
    m_current_status.CopyFrom(newStatus);

    for (int i = 0; i < newStatus.statuses_size(); i++) {
        const ServoStatus &s = newStatus.statuses(i);
        if (s.servo_id() == RIGHT_BELT_IDX) {
            if(s.has_position())
                m_current_rightbelt_position = s.position();
            if(s.has_position_raw())
                m_current_rightbelt_rawposition = s.position_raw();
        }
        else if (s.servo_id() == LEFT_BELT_IDX) {
            if(s.has_position())
                m_current_leftbelt_position = s.position();
            if(s.has_position_raw())
                m_current_leftbelt_rawposition = s.position_raw();
        }
        else if (s.servo_id() == ROLLER_IDX) {
            if(s.has_position())
                m_current_drum_position = s.position();
            if(s.has_position_raw())
                m_current_drum_rawposition = s.position_raw();
        }
    }

    return newStatus;
}

void machine_interface_t::send_servo_request(const Command &cmd) {
    if (cmd.ByteSize() == 0)
        return;
    logServo.fmt("----------------------------------------------- servo-request:\n%s",cmd.DebugString().c_str());
    logger.save("servo-request","%s",cmd.DebugString().c_str());
    char *buf = new char[cmd.ByteSize()];
    if (cmd.SerializeToArray(buf, cmd.ByteSize()))
    {
        int nbytes = nn_send(m_servo_cmd_s, buf, cmd.ByteSize(), 0);
        if (nbytes < 0)
        {
            int err = nn_errno();
            if(buf) delete[] buf;
            buf = nullptr;
            throw std::runtime_error(nn_strerror(err));
        }
    }
    if(buf) delete[] buf;
    buf = nullptr;

    int nbytes = nn_recv(m_servo_cmd_s, &buf, NN_MSG, 0);
    if (nbytes < 0)
    {
        int err = nn_errno();
        if(buf) {nn_freemsg(buf); buf = nullptr;}
        throw std::runtime_error(nn_strerror(err));
    }
    logServo.fmt("servo-response: %d bytes",nbytes);
    if(buf) nn_freemsg(buf);
}

bool machine_interface_t::is_safety_cage_open(const ServoStatusBatch& newStatus) {
    // if there is none in the message, better be safe
    // and assume it is open
    bool open = true;
    for (int i = 0; i < newStatus.statuses_size(); i++) {
        const ServoStatus &s = newStatus.statuses(i);
        if (s.servo_id() == GPIO_IDX)
        {
            if (s.has_digital_in())
            {
                const DigitalInputs &in = s.digital_in();
                if (in.has_mon1()) {
                    open = in.mon1();
                } else {
                    printf("Missing safety cage flag!\n");
                }
            }
        }
    }
    return open;
}

bool machine_interface_t::is_stop_button_pressed(const ServoStatusBatch &newStatus)
{
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++)
    {
        const ServoStatus &s = newStatus.statuses(i);

        if (s.servo_id() == GPIO_IDX)
        {
            if (s.has_digital_in())
            {
                const DigitalInputs &in = s.digital_in();
                if (in.has_mon4())
                {
                    pressed = in.mon4();
                }
            }
        }
    }
    return pressed;
}

bool machine_interface_t::is_stop_button_pressed() const {
    return is_stop_button_pressed(m_current_status);
}

bool machine_interface_t::is_left_button_pressed(const ServoStatusBatch &newStatus)
{
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++)
    {
        const ServoStatus &s = newStatus.statuses(i);

        if (s.servo_id() == GPIO_IDX)
        {
            if (s.has_digital_in())
            {
                const DigitalInputs &in = s.digital_in();
                if (in.has_mon2())
                {
                    pressed = in.mon2();
                }
            }
        }
    }
    return pressed;
}

bool machine_interface_t::is_left_button_pressed() const {
    return is_left_button_pressed(m_current_status);
}

bool machine_interface_t::is_right_button_pressed(const ServoStatusBatch &newStatus)
{
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++)
    {
        const ServoStatus &s = newStatus.statuses(i);

        if (s.servo_id() == GPIO_IDX)
        {
            if (s.has_digital_in())
            {
                const DigitalInputs &in = s.digital_in();
                if (in.has_mon3())
                {
                    pressed = in.mon3();
                }
            }
        }
    }
    return pressed;
}

bool machine_interface_t::is_right_button_pressed() const {
    return is_right_button_pressed(m_current_status);
}

bool machine_interface_t::is_gapposition_reached() {
    bool reached = false;
    bool fromRange = false;
    int32_t pos = 0;
    for (int i = 0; i < m_current_status.statuses_size(); i++) {
        const ServoStatus &s = m_current_status.statuses(i);
        if (s.servo_id() == GAP_IDX) {
            if(s.has_position()) pos = s.position();
            if(SystemConfig::typ==SystemConfig::ECOSTAR) //tmp solution for EcoStar
            {
                if(std::fabs(255 - s.target_pos()) + s.position() < 6){
                    reached = true;
                    fromRange = true;;
                }
                if(std::fabs(255 - s.position()) + s.target_pos() < 6){
                    reached = true;
                    fromRange = true;
                }
                if (s.target_pos() <= (s.position()+6) ){
                    reached = true;
                    fromRange = true;
                }
                if (s.target_pos() >= (s.position()-6)){
                    reached = true;
                    fromRange = true;
                }

            }else{
                if (s.has_target_position_reached() && s.target_position_reached()) {
                    reached = true;
                }
                else if (s.has_target_pos() and s.has_position()) {
                    if (s.target_pos() <= (s.position()+2) )
                        if (s.target_pos() >= (s.position()-2)){
                            reached = true;
                            fromRange = true;
                        }

                }

            }

        }
    }
    if(m_last_gapsize_reached != reached) {
        m_last_gapsize_reached = reached;
        fprintf(StdLogger::INFO, "The gap position is%s reached%s ... position %d\n", reached ? "" : " not", reached ? (fromRange?" (from range)":" (from value)") : "", pos);
    }
    return reached;
}

void machine_interface_t::reset_all_servo_errors() {
    /* If any servo is in the error state, reset the error */
    if (clock::now() < m_ts_earliest_next_reset)
        return;
    Command command;
    bool doSend = false;
    for (int i = 0; i < m_current_status.statuses_size(); i++) {
        const auto& r = m_current_status.statuses(i);
        ServoStatus_ServoError err = r.has_error() ? r.error() : r.NO_ERROR;
        ServoStatus_State state = r.has_state() ? r.state() : ServoStatus::State::ServoStatus_State_UNKNOWN_STATE;
        if (err != r.NO_ERROR) { // || state==ServoStatus::State::ServoStatus_State_FAULT) {
            // do an error reset on this motor
            ServoCommand *cmd = command.add_commands();
            cmd->set_servo_id(i);
            cmd->set_command(ServoCommand::RESET);
            doSend = true;
            printf("servo motor %d of 0..3 reset on error %d%s", i, err, state==ServoStatus::State::ServoStatus_State_FAULT?" (FAULT state)":"");
        }
    }
    if(doSend) {
        m_ts_earliest_next_reset = clock::now() + std::chrono::milliseconds(servo_pause_ms);
        printf("****** send request reset servo errors(DIR=%d):\n%s",m_current_belts_direction,command.DebugString().c_str());
        send_servo_request(command);
    }
}

bool machine_interface_t::turn_all_servos_on() {
    if(SystemConfig::typ==SystemConfig::ECOSTAR) //tmp solution for EcoStar
        return true;

    Command command;
    bool doSend = false;
    int wrn[4] = {0,0,0,0};
    for (int i = 0; i < 4; i++) {
        const auto& r = m_current_status.statuses(i);
        ServoStatus_ServoError err = r.has_error() ? r.error() : r.NO_ERROR;
        ServoStatus_State state = r.has_state() ? r.state() : ServoStatus::State::ServoStatus_State_UNKNOWN_STATE;
        uint32_t lstat = r.has_lowlevel_status() ? r.lowlevel_status() : 0;
        uint32_t lerr = r.has_lowlevel_error() ? r.lowlevel_error() : ((lstat>>16)&0xFFFFu);
        lstat &= 0xFFFFu;
        if (state == ServoStatus::State::ServoStatus_State_STANDBY) {
            // turn on this motor
            ServoCommand *cmd = command.add_commands();
            cmd->set_servo_id(i);
            cmd->set_command(ServoCommand::TURN_ON);
            doSend = true;
            wrn[i] = 1;
        } else if (state != ServoStatus::State::ServoStatus_State_RUNNING) {
            const char *st = "UNKNOWN";
            switch(state) {
            case ServoStatus::State::ServoStatus_State_EMERGENCY_STOP_ACTIVE: st = "EMERGENCY_STOP"; break;
            case ServoStatus::State::ServoStatus_State_FAULT: st = "FAULT"; break;
            case ServoStatus::State::ServoStatus_State_STARTUP: st = "STARTUP"; break;
            default: break;
            }
            if(state!=ServoStatus::State::ServoStatus_State_STARTUP || lerr!=0 || lstat!=0) printf("warning: servo motor %d of 0..3 has status %s and error %d (lowlevel err=0x%04X status=0x%04X) while starting", i, st, err, lerr, lstat);
        }
    }
    if(doSend) {
        char motors[10];
        int off = 0;
        for (int i = 0; i < 4; i++) {
            if(wrn[i]==1) {
                motors[off++] = '0' + i;
                motors[off++] = ' ';
            }
        }
        motors[off] = 0;
        time_point t = clock::now();
        if (t < m_ts_earliest_next_turn_on) {
            if(m_log_servo_delay) {
                auto dif = m_ts_earliest_next_turn_on - t;
                long ms = std::chrono::duration_cast<std::chrono::milliseconds>(dif).count();
                printf("warning: starting servo motor(s) %s delayed (%ld ms remaining) !!!", motors, ms);
                m_log_servo_delay = false;
            }
            return false;
        }
        m_ts_earliest_next_turn_on = clock::now() + std::chrono::milliseconds(servo_pause_ms);
        m_log_servo_delay = true;
        printf("ok: starting servo motor(s) %s", motors);
        printf("****** send request turn on all motors(DIR=%d):\n%s",m_current_belts_direction,command.DebugString().c_str());
        send_servo_request(command);
    }
    return true;
}

void machine_interface_t::turn_off_servo(const int index) {
    Command commands;
    {
        printf("ok: stopping servo motor %d of 0..3", index);
        ServoCommand* cmd = commands.add_commands();
        cmd->set_command(ServoCommand::TURN_OFF);
        cmd->set_servo_id(index);
    }
    printf("****** send request turn off all motors(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::stop_all_servos() {
    Command commands;
    for (int i = 0; i < NUMBER_MOTORS_TMP; i++)
    {
        //set the gap motor to stop instead of set target velocity, as the gap motor runs in position mode
        /*if(i == GAP_IDX && (SystemConfig::typ!=SystemConfig::ECOSTAR) ){
            ServoCommand *cmd = commands.add_commands();
            cmd->set_command(ServoCommand::STOP);
            cmd->set_servo_id(i);
        }else{*/
        ServoCommand *cmd = commands.add_commands();
        SystemConfig::runmode_factor_dynamic = 1.0;
        cmd->set_command(ServoCommand::SET_VELOCITY);
        cmd->set_servo_id(i);
        cmd->set_target_velocity(0);
        //}

    }
    {
        // stop flour duster & haspel
        ServoCommand *cmd = commands.add_commands();
        cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
        cmd->set_servo_id(GPIO_IDX);
        DigitalOutputs* outs = cmd->mutable_digital_out();
        outs->set_out1(false);
        outs->set_out2(false);
        outs->set_out3(false);
    }
    printf("****** send request stop motors(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::start_gapsize(const double gapsize_mm) {
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_POSITION);
    cmd->set_servo_id(GAP_IDX);
    cmd->set_target_position(static_cast<int32_t>(gapsize_mm * 10.0));
    //printf("################### machine-positions: set target_position[%d] = %.3lf * 10.0 = %d",
    //       GAP_IDX, gapsize_mm, int32_t(gapsize_mm * 10.0));
    printf("****** send request start gap position(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::set_infeed_percentage(int32_t newInfeed){
    m_infeed_percentage = newInfeed;
}

void machine_interface_t::set_speeds(Command& commands, const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor) {
    double dynFactors[3];
    if(velocity>0) m_current_belts_direction = 1;
    else if(velocity<0) m_current_belts_direction = -1;
    else m_current_belts_direction = 0;
    dynFactors[0] = velocity > 0 ? (feedingSpeedFactor + 0.1*m_infeed_percentage) : extractionSpeedFactor;
    dynFactors[1] = 100.0;
    dynFactors[2] = velocity > 0 ? extractionSpeedFactor : (feedingSpeedFactor + 0.1*m_infeed_percentage);


    int loopCnt = 3;
    if(SystemConfig::typ==SystemConfig::ECOSTAR)
        loopCnt = 1;
    SystemConfig::runmode_factor_dynamic = 1.0;
    double outfeed_speed = 0;
    double drum_speed = 0;
    for (int i=0; i<loopCnt; ++i) {
        ServoCommand *cmd = commands.add_commands();
        cmd->set_command(ServoCommand::SET_VELOCITY);
        cmd->set_servo_id(i);
        double v = velocity;
        if(dynFactors[i]>=0.1) {
            v = v * dynFactors[i] / 100.0;
        }
        printf("machine-speeds: set target_velocity[%d] = %.3lf * %.1lf%c = %d - - - - - - - - - - - DIR=%d", i, double(velocity), dynFactors[i], '%', int32_t(std::round(v)), m_current_belts_direction);
        if(SystemConfig::typ==SystemConfig::ECOSTAR){//tmp solution for EcoStar
            cmd->set_target_velocity(int32_t(m_current_belts_direction));
        }else{
            if((i==0 && v<0) || (i==2 && v>0)) outfeed_speed = std::abs(v);
            else if(i==1) drum_speed = std::abs(v);
            cmd->set_target_velocity(int32_t(std::round(v)));
        }
    }

    if(outfeed_speed>0 && drum_speed>0) {
        double f = drum_speed / outfeed_speed;
        SystemConfig::runmode_factor_dynamic = f;
    }
}

void machine_interface_t::start_to_center(const int32_t velocity) {
    Command commands;
    for (int i=0; i<NUMBER_MOTORS_TMP-1; ++i) { // TODO Kai please check the rage for EcoStar
        ServoCommand *cmd = commands.add_commands();
        SystemConfig::runmode_factor_dynamic = 1.0;
        cmd->set_command(ServoCommand::SET_VELOCITY);
        cmd->set_servo_id(i);
        double speed_factor = 58.0; //static_cast<double>(compas_speed_factors.feeding_belt) / 100.0;
        double v = std::abs(velocity * speed_factor);
        if(SystemConfig::typ==SystemConfig::ECOSTAR){
            // nicht implementiert
            int vel = 0;
            cmd->set_target_velocity(int32_t(vel));
        }else{
            if(i==1) v = 0.0;
            else if(i==2) v = -v;
            cmd->set_target_velocity(int32_t(std::round(v)));
        }
    }
    printf("****** send request start belts(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::start_belts4cutomat(const int32_t velocity) {
    // start all motors with the same velocity
    if(velocity>0) m_current_belts_direction = 1;
    else if(velocity<0) m_current_belts_direction = -1;
    else m_current_belts_direction = 0;
    Command commands;
    for (int i=0; i<NUMBER_MOTORS_TMP-1; ++i) { // TODO Kai please check the rage for EcoStar
        ServoCommand *cmd = commands.add_commands();
        SystemConfig::runmode_factor_dynamic = 1.0;
        cmd->set_command(ServoCommand::SET_VELOCITY);
        cmd->set_servo_id(i);
        double v = velocity;
        //printf("machine-speeds: set target_velocity[%d] = %.3lf * %.3lf = %.3lf => %d", i, double(velocity), speed_factor, int(velocity * speed_factor),int32_t(std::round(v)));
        if(SystemConfig::typ==SystemConfig::ECOSTAR){
            int vel = 0;
            if(velocity > 0)
                vel = 1;
            else if(velocity < 0)
                vel = -1;
            cmd->set_target_velocity(int32_t(vel));
        }else{
            cmd->set_target_velocity(int32_t(std::round(v)));
        }
    }
    printf("****** send request start belts(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::start_belts(const int32_t velocity, const bool flourduster, const double feedingSpeedFactor, const double extractionSpeedFactor) {
    Command commands;
    set_speeds(commands, velocity, feedingSpeedFactor, extractionSpeedFactor);
    if (flourduster) {
        ServoCommand *cmd = commands.add_commands();
        cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
        cmd->set_servo_id(GPIO_IDX);
        DigitalOutputs* outs = cmd->mutable_digital_out();
        outs->set_out1(false);
        outs->set_out2(false);
        outs->set_out3(true);
    }
    printf("****** start belts:\n%s",commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::change_belts_speed(const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor) {
    Command commands;
    set_speeds(commands, velocity, feedingSpeedFactor, extractionSpeedFactor);
    printf("****** start belts (changed):\n%s",commands.DebugString().c_str());
    send_servo_request(commands);
}

/*void machine_interface_t::start_transport_belt(const int32_t velocity, const double feedingSpeedFactor, const double extractionSpeedFactor) {
    Command commands;
    if(velocity>0) m_current_belts_direction = 1;
    else if(velocity<0) m_current_belts_direction = -1;
    else m_current_belts_direction = 0;
    // start only left belt moving to the left
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_VELOCITY);
    cmd->set_servo_id(LEFT_BELT_IDX);
    double v = velocity;
    if(extractionSpeedFactor>1.01) {
        v *= extractionSpeedFactor;
    }
    cmd->set_target_velocity(int32_t(std::round(std::fabs(v) * -1.0)));

    printf("****** start transport belt:\n%s",commands.DebugString().c_str());
    send_servo_request(commands);
}*/

void machine_interface_t::clear_ecostar_autohaspel_output(){
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();

    outs->set_out4(false);
    outs->set_out5(false);

    printf("****** Ecostar: send request clear auto reeler(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);

}

void machine_interface_t::close_autohaspel() {
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();
    /*if(SystemConfig::typ==SystemConfig::ECOSTAR) //tmp solution for EcoStar
    {
        outs->set_out4(true);
        outs->set_out5(true);
        outs->set_out3(false);

    }else{*/
    outs->set_out1(true);
    outs->set_out2(true);
    outs->set_out3(false);
    //}

    printf("****** send request close reeler(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::open_autohaspel() {
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();
    if(SystemConfig::typ==SystemConfig::ECOSTAR)
    {
        outs->set_out4(true);
        outs->set_out5(false);

    }else{
        outs->set_out1(true);
        outs->set_out2(false);
        outs->set_out3(false);
    }


    printf("****** send request open reeler(DIR=%d):\n%s",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::stop_autohaspel() {
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();
    if(SystemConfig::typ==SystemConfig::ECOSTAR) //tmp solution for EcoStar
    {
        outs->set_out1(false);
        outs->set_out3(false);

    }else{
        outs->set_out1(false);
        outs->set_out2(false);
        outs->set_out3(false);
    }


    printf("****** send request stop reeler:\n%s",commands.DebugString().c_str());
    send_servo_request(commands);
}

void machine_interface_t::change_duster(bool val) {
    Command commands;
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();

    outs->set_out3(val);

    printf("****** send change duster to %s (DIR=%d):\n%s",val?"ON":"OFF",m_current_belts_direction,commands.DebugString().c_str());
    send_servo_request(commands);
}

/*void machine_interface_t::start_autohaspel_belt(const int32_t velocity, const bool flourduster, const double feedingSpeedFactor, const double extractionSpeedFactor) {
    Command commands;
    if(velocity>0) m_current_belts_direction = 1;
    else if(velocity<0) m_current_belts_direction = -1;
    else m_current_belts_direction = 0;
    double dynFactors[3];
    dynFactors[0] = feedingSpeedFactor;
    dynFactors[1] = 0.0;
    dynFactors[2] = extractionSpeedFactor;
    for (int i=0; i<3; ++i) {
        ServoCommand *cmd = commands.add_commands();
        cmd->set_command(ServoCommand::SET_VELOCITY);
        cmd->set_servo_id(uint32_t(i));
        double speed_factor = 0.0;
        switch (i) {
            case LEFT_BELT_IDX:
                speed_factor = static_cast<double>(compas_speed_factors.feeding_belt) / 100.0;
                break;
            case ROLLER_IDX:
                speed_factor = static_cast<double>(compas_speed_factors.roller) / 100.0;
                break;
            case RIGHT_BELT_IDX:
                speed_factor = static_cast<double>(compas_speed_factors.extraction_belt) / 100.0;
                break;
        }
        double v = velocity * speed_factor;
        if(dynFactors[i]>=0.1) {
            v *= dynFactors[i];
        }
        //printf("machine-reeler: set target_velocity[%d] = %d * %.3lf * %.3lf = %.3lf => %d",
        //       i, velocity, speed_factor, dynFactors[i]>=0.1 ? dynFactors[i] : 1.0, int(velocity * speed_factor),int32_t(std::round(v)));
        cmd->set_target_velocity(int32_t(std::round(v)));
    }
    ServoCommand *cmd = commands.add_commands();
    cmd->set_command(ServoCommand::SET_DIGITAL_OUTPUTS);
    cmd->set_servo_id(GPIO_IDX);
    DigitalOutputs* outs = cmd->mutable_digital_out();
    outs->set_out1(false);
    outs->set_out2(false);
    outs->set_out3(flourduster);
    printf("****** start belts (autohaspel):\n%s",commands.DebugString().c_str());
    send_servo_request(commands);
}*/
