#include <recipe_interpreter.hpp>
#include <machine_interface.hpp>
#include <tracedvariable.h>

// Protobuf + Nanomsg
#include <nanomsg/nn.h>
#ifdef WITH_SIMULATOR
#include <nanomsg/inproc.h>
#else
#include <nanomsg/tcp.h>
#endif
#include <nanomsg/pubsub.h>
#include <nanomsg/reqrep.h>

#include <sheeter2020/servo.pb.h>
#include <sheeter2020/movements.pb.h>
#include <sheeter2020/movements.pb.cc>
#include <sheeter2020/logdata.pb.h>
#include <sheeter2020/logdata.pb.cc>

#include <mutex>
#include <unistd.h>
#include <utility>
#include <exception>
#include <chrono>
#include <thread>
#include <cmath>
#include <cstdlib>

#include <average.h>
#include <systemconfig.h>
#include <stdlogger.h>
#include <binlogger.h>
//#include <global_state.hpp>
#define WAIT_BEFORE_NEXT_STEP 10

#define LOG_HW_TRIGGER_ON 2u
#define LOG_HW_TRIGGER_OFF 3u
#define LOG_SW_TRIGGER_ON 4u
#define LOG_SW_TRIGGER_OFF 5u

#define AR_STEP_BEFORE_TRANSPORT_STOP AR_STEP_TRIGGER_START
#define AR_STEP_AFTER_TRANSPORT_STOP AR_STEP_FINISH

using namespace sheeter2020;

bool waitForGapReached = true; //for EcoStar
uint64_t laserCnt = 0;  //for EcoStar
uint64_t headCnt = 0;  //for EcoStar
uint64_t tailCnt = 0;  //for EcoStar
//double speedEcoStarMMPerMs = 5.5; //for EcoStar
double speedEcoStarMMPerMsSpeedFactorLeft = 0.4;//1.2; //for EcoStar
double speedEcoStarMMPerMsSpeedFactorRight = 0.4;//1.0; //for EcoStar
double speedEcoStarMMPerMsSpeedFactorBoth = 0.38; //for EcoStar
double speedEcoStarMMPerMsSpeedFactorFarLeft = 0.26; //for EcoStar
double speedEcoStarMMPerMsSpeedFactorFarRight = 0.26; //for EcoStar
//double speedEcoStarMMPerCnt = 8.0; //for EcoStar
double runTimeAfterLaserTriggerWithOffset = 2.0; //1.0 sec for EcoStar
double runTimeForSpeedSlow = 1.0; //1.0 sec for EcoStar
uint32_t servo_sync_counter = 0;
int rotate_for_cleaning_step = 0; // 0=unused 1=request 2=busy
uint32_t rotate_for_cleaning_startpos = 0;
uint32_t rotate_for_cleaning_ticks = 0;
bool needPauseForAIPopupConfirmation = false;
int sendCnt = 0;
int pizzaProgramStartDirection = 0;
int gapReadyCnt = 0;
bool dusterAfterPause = false;

struct RecipeInterpreter
{
    using clock = std::chrono::steady_clock;
    using time_point = std::chrono::time_point<clock>;

    RecipeInterpreter()
    {
        transport_bit = false;
        transport_val = 0;

        longtime_test_with_reeler = false;
        is_in_longtime_test = false;
        stressReelerTime = clock::now();
        flourduster_delay_start = clock::now();
        flourduster_delayed = false;
        stressReelerStep = 0;

        doughReelerIsClosing = false;
        doughReelerIsOpening = false;
        doughReelerIsActived = false;

        move_to_center = false;
        sw_stop_request = pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
        sw_left_right = false;

        //table_oneside_length_mm = 1600.0;
        finish_length_factor = 1.01;
        positionTicksPerMillimeter = 362549097.0 / 1020.0;

        lastHWLaserTrigger = false;
        last_torque = 0;
        lastHWLaserTrigger = 1;
        preSheetLastLaserStatus = false;
        preSheetStartPositionConveyor = 0;
        preSheetStartPositionDrum = 0;
        preSheetStartTime = clock::now();

        infeedSpeedPreviousStep = 0;
        extractionSpeedPreviousStep = 0;
        //dynamic_speed_correction = false;
        /*char *stmp = std::getenv("RONDO_DYNAMIC_SPEED");
        if(stmp) {
            int tmp = std::atoi(stmp);
            if(tmp>0) {
                dynamic_speed_correction = true;
                fprintf(StdLogger::DBG,"dynamic speed correction set to ON");
            }
        }*/

        movementInfo.set_current_gapsize(0.0);
        movementInfo.set_in_progress(false);
        movementInfo.set_planned_count(0);
        movementInfo.set_finishing(false);
        movementInfo.set_transfer_us_waiting(false);
        movementInfo.set_current_length(0.0);
        movementInfo.set_waiting_length(0.0);
        movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_NONE);
        movementInfo.set_pause_reason(sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE);
        movementInfo.set_error_number(0);

        log_pipe_s = nn_socket(AF_SP, NN_PUB);
        if (log_pipe_s < 0)
        {
            int error = nn_errno();
            printf("Error creating pipe: %s", nn_strerror(error));
        }
#ifdef WITH_SIMULATOR
        log_pipe_e = -1;
        /*log_pipe_e = nn_bind(log_pipe_s,"inproc://logger8084");
        if(log_pipe_e < 0)
        {
            int error = nn_errno();
            printf("Error creating publisher tcp://0.0.0.0:8084: %s", nn_strerror(error));
        }*/
#else
        log_pipe_e = nn_bind(log_pipe_s,"tcp://0.0.0.0:8084");
        if(log_pipe_e < 0)
        {
            int error = nn_errno();
            printf("Error creating publisher tcp://0.0.0.0:8084: %s", nn_strerror(error));
        }
#endif

        move_status_s = nn_socket(AF_SP, NN_PUB);
        if (move_status_s < 0)
        {
            int error = nn_errno();
            printf("Error creating publisher: %s", nn_strerror(error));
        }
#ifdef WITH_SIMULATOR
        move_status_e = nn_bind(move_status_s, "inproc://movestatus8082");
#else
        move_status_e = nn_bind(move_status_s, "tcp://0.0.0.0:8082");
#endif
        if (move_status_e < 0)
        {
            int error = nn_errno();
            printf("Error binding: %s", nn_strerror(error));
        }

        move_command_s = nn_socket(AF_SP, NN_REP);
        if (move_command_s < 0)
        {
            int error = nn_errno();
            printf("Error creating replier: %s", nn_strerror(error));
        }
#ifdef WITH_SIMULATOR
        move_command_e = nn_bind(move_command_s, "inproc://movecmd8083");
#else
        move_command_e = nn_bind(move_command_s, "tcp://0.0.0.0:8083");
#endif
        if (move_command_e < 0)
        {
            int error = nn_errno();
            printf("Error binding: %s", nn_strerror(error));
        }

        waitForStartButtonPressed = false;
    }

    ~RecipeInterpreter() {
        nn_shutdown(log_pipe_s, log_pipe_e);
        nn_close(log_pipe_s);
    }

    bool isGapReached() const {
        return gapSizeStatusReached;
    }

    bool isPaused() const {
        return stepPaused;
    }

    bool isBusy() const {
        if(movements.has_current()) return true;
        if(movements.planned_size()>0) return true;
        return false;
    }

    uint32_t currentDoughLength() const {
        int v = int(movementInfo.current_length());
        if(v<0) v = 0;
        return uint32_t(v);
    }

    bool gapsize_reached() {
        bool reached = machine.is_gapposition_reached();

        assert (movements.has_current());
        assert (movements.current().has_gapsize());
        int step_gapsize = static_cast<int>(movements.current().gapsize() * 10.0);

        int offset1, offset2;
        if(SystemConfig::typ==SystemConfig::ECOSTAR){ //tmp solution for EcoStar
            offset1 = 7; // current gapsize tollerance
            offset2 = 7; // target gapsize tollerance
        } else {
            offset1 = 2; // current gapsize tollerance
            offset2 = 2; // target gapsize tollerance
        }
        if (machine.current_gapsize() < (step_gapsize - offset1)){

            return false;
        }
        if (machine.current_gapsize() > (step_gapsize + offset1)){

            return false;
        }
        if (std::abs(machine.current_target_gapsize()  - step_gapsize) > offset2){

            return false;
        }

        // turning off the gap servo ensures no flickering in torque and position
        // until the next external torque is applied (e.g. from dough)
        if (reached){
            machine.turn_off_servo(GAP_IDX);

        }
        return reached;
    }

    double dynamic_feeding_factor() const {
        double r = 58.0;
        if(movements.has_current() && movements.current().has_feedingbelt_speed_factor()) {
            r = movements.current().feedingbelt_speed_factor();
            if(r<1.0) r = 58.0;
        }
        return r;
    }

    double dynamic_extraction_factor() const {
        double r = 88.0;
        if(movements.has_current() && movements.current().has_extractionbelt_speed_factor()) {
            r = movements.current().extractionbelt_speed_factor();
            if(r<1.0) r = 88.0;
        }
        return r;
    }

    void start_gapsize() {
        program.triggerCtrl.reset(machine.current_drum_rawposition(), "start_gapsize");
        assert(movements.has_current());
        assert(movements.current().has_gapsize());

        if(SystemConfig::typ==SystemConfig::ECOSTAR){
            int cur_gapsize = static_cast<int>(movements.current().gapsize()*10);
            //double nextGapReal = movements.planned(0).gapsize();
            /*if(cur_gapsize > 250)
                waitForGapReached = false;
            else
                waitForGapReached = true;*/

            waitForGapReached = true;
        }

        gapSizeStatusReached = false;
        logMoves.fmt("### move gap to position %.2lf mm",movements.current().gapsize());
        machine.start_gapsize(movements.current().gapsize());
    }

    void start_to_center() {
        program.set_us_speed(0.0);
        program.triggerCtrl.reset(machine.current_drum_rawposition(), "start_belts");
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        int32_t velocity  = int32_t(std::round(movements.current().velocity()));
        logMoves.fmt("### start to center with speed %d", velocity);
        machine.start_to_center(velocity);
    }

    bool delay_flourduster(bool on) {
        if(on) {
            if(SystemConfig::flourduster_delay<=0) {
                flourduster_delayed = false;
                return true;
            }
            flourduster_delay_start = clock::now();
            flourduster_delayed = true;
        } else {
            flourduster_delayed = false;
        }
        return false;
    }

    void start_belts() {
        program.triggerCtrl.reset(machine.current_drum_rawposition(), "start_belts");
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        int32_t velocity  = int32_t(std::round(movements.current().velocity()));
        bool flourduster = false;
        if (movements.current().has_flourduster())
            flourduster = movements.current().flourduster();
        double infeed=dynamic_feeding_factor(), outfeed=dynamic_extraction_factor();
        double us_speed=0.0;
        if(program.is_us_valid(us_speed)) {
            if(velocity<0) velocity = -1*int(std::round(us_speed));
            else velocity = int(std::round(us_speed));
            infeed = outfeed = 100.0;
            logMoves.fmt("### start belts with speed %.2lf, infeed=%.1lf, outfeed=%.1lf TT_US", us_speed, infeed, outfeed);
        } else {
            logMoves.fmt("### start belts with speed %d, infeed=%.1lf, outfeed=%.1lf", velocity, infeed, outfeed);
        }
        flourduster = delay_flourduster(flourduster);
        machine.start_belts(velocity, flourduster, infeed, outfeed);
    }

    void change_belts_speed(double newspeed) {
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        double sign = 1.0;
        if(movements.current().velocity()<0.0) sign = -1.0;
        double v;
        if(newspeed<=0.0) {
            v = movements.current().velocity();
        } else if(sign>0.0) {
            v = std::round(newspeed);
            if(v > movements.current().velocity()) v = movements.current().velocity();
        } else {
            v = -std::round(newspeed);
            if(v < movements.current().velocity()) v = movements.current().velocity();
        }

        int32_t velocity  = int32_t(v);
        logMoves.fmt("### change belts speed to %d (requested %.02lf)", velocity, newspeed);
        machine.change_belts_speed(velocity, dynamic_feeding_factor(), dynamic_extraction_factor());
    }

    void start_transport_belt() {
        // check if start allowed
        double ext_speed = 0.0;
        if(autoreelMidstep==AR_STEP_AFTER_TRANSPORT_STOP) {
            if(!transport_bit) return;
            if(SystemConfig::transport_mode==SystemConfig::TransportMode::FBT) {
                ext_speed = SystemConfig::transp_a * transport_val + SystemConfig::transp_c;
                if(ext_speed<0.1 || ext_speed<(SystemConfig::transp_c+0.1) || SystemConfig::ticks2mm_belt<1.0) return;
                ext_speed = ext_speed * 10.0; // * SystemConfig::ticks2mm_belt;
                if(ext_speed>1500.0) ext_speed = 1500.0;
            }
        }

        program.triggerCtrl.reset(machine.current_drum_rawposition(), "start_transport_belt");
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        assert((SystemConfig::transport_at_right_side && movements.current().velocity() > 0) || (!SystemConfig::transport_at_right_side && movements.current().velocity() < 0));
        auto velocity  = movements.current().velocity();
        if(autoreelMidstep==AR_STEP_AFTER_TRANSPORT_STOP) {
            if(SystemConfig::transport_mode==SystemConfig::TransportMode::FBT) {
                // speed from external value
                if(velocity<0.0) velocity = -ext_speed;
                else velocity = ext_speed;
            } else {
                if(movements.has_current() && movements.current().has_velocity_slow()) {
                    double slowSpeed = movements.current().velocity_slow();
                    if(slowSpeed>0.0) {
                        if(velocity<0.0) velocity = -slowSpeed;
                        else velocity = slowSpeed;
                    }
                }
            }
        }
        logMoves.fmt("### start belts(T) with speed %d %s stop position", int32_t(std::round(velocity)), autoreelMidstep==AR_STEP_AFTER_TRANSPORT_STOP ? "behind" : "before");
        machine.start_belts4cutomat(int32_t(std::round(velocity)));
    }

    void start_cutomat_belt() {
        program.triggerCtrl.reset(machine.current_drum_rawposition(), "start_cutomat_belt");
        bool to_right_side = SystemConfig::cutomat_at_right_side;
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        assert(std::abs(movements.current().velocity())>0.0001);
        double velocity  = std::abs(movements.current().velocity());
        double slowSpeed = velocity;
        if(movements.current().has_velocity_slow()) {
            slowSpeed = std::abs(movements.current().velocity_slow());
            if(slowSpeed<=0.0) slowSpeed = velocity;
        }
        if(!to_right_side) {
            velocity = -velocity;
            slowSpeed = -slowSpeed;
        }
        if(autoreelMidstep==AR_STEP_SLOW_MOVE) {
            velocity = slowSpeed;
        }
        logMoves.fmt("### start belts(C) with speed %d", int32_t(std::round(velocity)));
        machine.start_belts4cutomat(int32_t(std::round(velocity))); //,false,dynamic_feeding_factor(), dynamic_extraction_factor());
    }

    void close_haspel() {
        doughReelerIsClosing = true;
        doughReelerIsActivedTime = clock::now();
        machine.close_autohaspel();
        doughReelerIsActived = true;

    }

    void open_haspel(bool with_stop=false) {
        doughReelerIsOpening = true;
        doughReelerIsActivedTime = clock::now();
        if(with_stop) machine.stop_autohaspel();
        machine.open_autohaspel();
        doughReelerIsActived = true;

    }

    void start_endhaspel_belt(bool manual) {
        program.triggerCtrl.reset(machine.current_drum_rawposition(), manual ? "start_endhaspel_belt_manual" : "start_endhaspel_belt_auto");
        assert(movements.has_current());
        assert(movements.current().has_velocity());
        bool to_right_side = manual ? SystemConfig::manualreel_at_right_side : SystemConfig::autoreel_at_right_side;
        //assert((to_right_side && movements.current().velocity() > 0) || (!to_right_side && movements.current().velocity() < 0));
        double velocity  = std::abs(movements.current().velocity());
        assert(velocity>0.0);
        double slowSpeed = velocity;
        if(movements.current().has_velocity_slow()) {
            slowSpeed = std::abs(movements.current().velocity_slow());
            if(slowSpeed<=0.0) slowSpeed = velocity;
        }
        double speed50 = velocity;
        if(movements.current().has_velocity_50()) {
            speed50 = std::abs(movements.current().velocity_50());
            if(speed50<=0.0) speed50 = velocity;
        }
        if(!to_right_side) {
            velocity = -velocity;
            slowSpeed = -slowSpeed;
            speed50 = -speed50;
        }
        if(autoreelMidstep==AR_STEP_SLOW_MOVE || autoreelMidstep==AR_STEP_WHILE_SLOW_MOVE) {
            velocity = slowSpeed;
        } else if(autoreelMidstep==AR_STEP_FINISH) {
            velocity = speed50;
        }
        logMoves.fmt("### start belts(%s) with speed %d=%.1lf (side=%s)",manual?"MR":"AR", int32_t(std::round(velocity)),velocity,to_right_side?"RIGHT":"LEFT");

        //--------------- active the flour duster for the last step-------------------
        bool flourduster = false;
        if (movements.current().has_flourduster())
            flourduster = movements.current().flourduster();
        flourduster = delay_flourduster(flourduster);
        machine.start_belts(int32_t(std::round(velocity)),flourduster,dynamic_feeding_factor(), dynamic_extraction_factor());
    }

    void log_trigger_status(unsigned int art, int dir, int64_t currpos)
    {
        sheeter2020::LogData logdata;
        int64_t ts = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        logdata.set_machine_id(art);
        logdata.set_timestamp(ts);
        logdata.set_direction(dir);
        int64_t s;
        s = currpos&0xFFFFFFFFu;
        logdata.set_pos_start(s);
        //logdata.set_gap_curr(curr_gap);
        //logdata.set_speed_main(int32_t(std::fabs(movements.current().velocity()) * 100.0 / 1500.0));
        //logdata.set_speed_feeder(int32_t(machine_interface_t::compas_speed_factors.feeding_belt));
        //logdata.set_speed_extractor(int32_t(machine_interface_t::compas_speed_factors.extraction_belt));
        int logsize = logdata.ByteSize();
        char *logbuf = logsize>0 ? new char[logsize] : nullptr;
        if(logbuf && logdata.SerializeToArray(logbuf, logsize)) {
            if(log_pipe_e>=0) nn_send(log_pipe_s,logbuf,size_t(logsize),0);
        }
        if(logbuf) delete[] logbuf;
    }

    bool check_dough_length(bool laser_trigger, int torque)
    {
        if(stepPaused) return false;

        //len_mm = 0.0;
        double curr_gap = 0.0;
        double presheetT2MM = SystemConfig::ticks2mm_belt; // program.presheetTicks2mm();
        double rmodeF = SystemConfig::runmode_factor * SystemConfig::runmode_factor_dynamic; // program.rmodeFactor();
        if(presheetT2MM<=0.001 || rmodeF<=0.0001) return false;
        double factorT2MM = presheetT2MM / rmodeF;

        int dir = machine.current_belts_direction();

        if(preSheetLastLaserStatus != laser_trigger) {
            preSheetLastLaserStatus = laser_trigger;
            //fprintf(StdLogger::DBG,"############### check_dough_length(1): preSheetLastLaserStatus = %s", preSheetLastLaserStatus?"true":"false");
            if(laser_trigger) {
                laserCnt += 1;
                fprintf(StdLogger::TRACE, "SW laser trigger changed to ON at pos %u (validation start: %u, torque=%d)", machine.current_drum_rawposition(), program.triggerCtrl.triggerStartPos(), torque);
                logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d SW laser trigger changed to ON (validation startpos=%u, torque=%d)",
                             machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                             program.triggerCtrl.triggerStartPos(), torque);
                preSheetStartPositionConveyor = dir>0 ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                preSheetStartPositionDrum = machine.current_drum_rawposition();
                log_trigger_status(LOG_SW_TRIGGER_ON, dir, SystemConfig::drum_mode ? preSheetStartPositionDrum : preSheetStartPositionConveyor);
                preSheetStartTime = clock::now();
                program.setDoughSide(0);
                return false;
            } else {
                int64_t nowPosition = dir>0 ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                int64_t nowPosDrum = machine.current_drum_rawposition();
                uint32_t nowPosLeft = machine.current_leftbelt_rawposition();
                uint32_t nowPosRight = machine.current_rightbelt_rawposition();
                //int64_t nowPosReal = nowPosition;
                int64_t nowPosDrumReal = nowPosDrum;
                const char *dirtxt = "";
                int64_t len;
                int64_t lenFromTime;
                int64_t lenDrum;
                time_point nowTime = clock::now();
                std::chrono::duration<double> diff_time = nowTime - preSheetStartTime;
                double diff_ms = std::chrono::duration_cast<std::chrono::milliseconds>(diff_time).count();
                double tsf = program.timespeedFactor();
                double extrf = movements.current().has_extractionbelt_speed_factor() ? std::abs(movements.current().extractionbelt_speed_factor()) : 88;
                double feedf = movements.current().has_feedingbelt_speed_factor() ? std::abs(movements.current().feedingbelt_speed_factor()) : 58;
                infeedSpeedPreviousStep = feedf;
                extractionSpeedPreviousStep = extrf;
                double spd = std::fabs(movements.current().velocity()) * extrf / 100.0;
                if(tsf<=0.0) tsf = 1.0;
                lenFromTime = int64_t(diff_ms * spd / tsf);
                double correction = SystemConfig::trigger_correction_ms; //program.triggerCtrl.correction();
                if(diff_ms<=correction) {
                    preSheetLastLaserStatus = !laser_trigger;
                    //fprintf(StdLogger::DBG,"############### check_dough_length(2): preSheetLastLaserStatus = %s", preSheetLastLaserStatus?"true":"false");
                    return false;
                }
                if(dir>0) {
                    dirtxt = ">>>>>>>>>>>>>>>>>>>";
                    len = program.distance(uint32_t(preSheetStartPositionConveyor), uint32_t(nowPosition), 1);
                    lenDrum = program.distance(uint32_t(preSheetStartPositionDrum), uint32_t(nowPosDrum), 1);
                } else {
                    dirtxt = "<<<<<<<<<<<<<<<<<<<";
                    len = program.distance(uint32_t(preSheetStartPositionConveyor), uint32_t(nowPosition), -1);
                    lenDrum = program.distance(uint32_t(preSheetStartPositionDrum), uint32_t(nowPosDrum), -1);
                }

                //len = int64_t((1.0 - correction*correction / ((diff_ms-correction)+correction*correction)) * len);
                //lenDrum = int64_t((1.0 - correction*correction / ((diff_ms-correction)+correction*correction)) * lenDrum);
                len = int64_t((1.0 - correction / diff_ms) * len);
                lenDrum = int64_t((1.0 - correction / diff_ms) * lenDrum);

                curr_gap = movements.has_current() && movements.current().has_gapsize() ? movements.current().gapsize() : 0.0;
                double presheetWidth = program.widthCtrl.width();
                double prevGap = program.previousGapsize();

                if(SystemConfig::drum_mode) {
                    if(lenDrum<=0) {
                        preSheetLastLaserStatus = !laser_trigger;
                        //fprintf(StdLogger::DBG,"############### check_dough_length(3): preSheetLastLaserStatus = %s", preSheetLastLaserStatus?"true":"false");
                        return false;
                    }
                    log_trigger_status(LOG_SW_TRIGGER_OFF, dir, nowPosDrumReal);

                    sheeter2020::LogData logdata;
                    int64_t ts = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
                    logdata.set_machine_id(1);
                    logdata.set_timestamp(ts);
                    logdata.set_direction(dir);
                    int64_t s,e;
                    s = preSheetStartPositionDrum&0xFFFFFFFFu;
                    e = nowPosDrumReal&0xFFFFFFFFu;
                    if(dir>0 && e < s) e += 0x100000000ll;
                    else if(dir<0 && s < e) s += 0x100000000ll;
                    logdata.set_pos_start(s);
                    logdata.set_pos_end(e);
                    logdata.set_ticks(len);
                    logdata.set_gap_curr(curr_gap);
                    logdata.set_gap_old(prevGap);
                    logdata.set_length_cm_curr(0.1 * len / factorT2MM + SystemConfig::length_correction_constant*0.1);
                    logdata.set_length_cm_should(presheetWidth/10.0);
                    logdata.set_ticks2mm(presheetT2MM);
                    logdata.set_runmode_factor(rmodeF);
                    logdata.set_correction(correction);
                    logdata.set_time_ms(int32_t(diff_ms));
                    logdata.set_time_factor(lenFromTime);
                    logdata.set_speed_main(int32_t(std::fabs(movements.current().velocity()) * 100.0 / SystemConfig::speed100));
                    logdata.set_speed_feeder(movements.current().has_feedingbelt_speed_factor() ? int(movements.current().feedingbelt_speed_factor()) : 58);
                    logdata.set_speed_extractor(movements.current().has_extractionbelt_speed_factor() ? int(movements.current().extractionbelt_speed_factor()) : 88);
                    int logsize = logdata.ByteSize();
                    char *logbuf = logsize>0 ? new char[logsize] : nullptr;
                    if(logbuf && logdata.SerializeToArray(logbuf, logsize)) {
                        if(log_pipe_e>=0) nn_send(log_pipe_s,logbuf,size_t(logsize),0);
                    }
                    if(logbuf) delete[] logbuf;

                    fprintf(StdLogger::TRACE, "SW laser trigger changed to OFF at pos %u (validation start: %u, torque=%d)", machine.current_drum_rawposition(), program.triggerCtrl.triggerStartPos(), torque);
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d SW laser trigger changed to OFF (D, validation startpos=%u, torque=%d)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 program.triggerCtrl.triggerStartPos(), torque);
                    //                              dr st en len  t2mm  lenmm  gap   old  gapfr need  tm_ms lent  spd  fd ex
                    fprintf(StdLogger::ALERT,"/CSV/ %c %u %u %lld %.2lf %.2lf %.2lf %.2lf %.6lf %.2lf %.1lf %lld %.0lf %d %d drum %s"
                            , dirtxt[0], uint32_t(preSheetStartPositionDrum), uint32_t(nowPosDrum), lenDrum, presheetT2MM, 1.0*lenDrum / factorT2MM, curr_gap, prevGap, prevGap<=0.0?0.0:(curr_gap/prevGap), presheetWidth, diff_ms, lenFromTime
                            , std::fabs(movements.current().velocity()) * 100.0 / SystemConfig::speed100,
                            movements.current().has_feedingbelt_speed_factor() ? int(movements.current().feedingbelt_speed_factor()) : 58.0,
                            movements.current().has_extractionbelt_speed_factor() ? int(movements.current().extractionbelt_speed_factor()) : 88.0
                                                                                    , SystemConfig::dynamic_mode?"dynamic":"no-dynamic");
                    program.widthCtrl.setCurrentRawLength(lenDrum, uint32_t(nowPosDrumReal), nowPosLeft, nowPosRight);
                    movementInfo.set_current_length(1.0*lenDrum / factorT2MM + SystemConfig::length_correction_constant);
                } else if(program.isTimeMode()) {
                    log_trigger_status(LOG_SW_TRIGGER_OFF, dir, nowPosition);
                    fprintf(StdLogger::TRACE, "SW laser trigger changed to OFF at pos %u (validation start: %u, torque=%d)", machine.current_drum_rawposition(), program.triggerCtrl.triggerStartPos(), torque);
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d SW laser trigger changed to OFF (T, validation startpos=%u, torque=%d)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 program.triggerCtrl.triggerStartPos(), torque);
                    fprintf(StdLogger::ALERT,"/LENGTH/ %s %.1lf ms => %lld gap: %.2lf old: %.2lf => %.6lf wait: %.2lf", dirtxt, diff_ms, lenFromTime, curr_gap, prevGap, prevGap<=0.0?0.0:(curr_gap/prevGap), presheetWidth);
                    program.widthCtrl.setCurrentRawLength(lenDrum, uint32_t(nowPosDrumReal), nowPosLeft, nowPosRight);
                    //double positionTicksPerMillimeter = 362549097.0 / 1020.0 / tickToMMFactor;
                    //len_mm = 1.0 * len / presheetT2MM;
                    movementInfo.set_current_length(1.0*lenDrum / factorT2MM + SystemConfig::length_correction_constant);
                } else {

                    if(SystemConfig::typ==SystemConfig::ECOSTAR){ //calculate the doguh lenth for ecostar
                        //len = int64_t(laserCnt * speedEcoStarMMPerMs); // unless the len below will be zero
                        len = int64_t(laserCnt * SystemConfig::ecostar_speed_left * 0.75); // unless the len below will be zero
                    }
                    if(len<=0 || (len+SystemConfig::length_correction_constant*factorT2MM)<=0) {
                        preSheetLastLaserStatus = !laser_trigger;
                        //fprintf(StdLogger::DBG,"############### check_dough_length(4): preSheetLastLaserStatus = %s", preSheetLastLaserStatus?"true":"false");
                        return false;
                    }

                    log_trigger_status(LOG_SW_TRIGGER_OFF, dir, nowPosition);

                    sheeter2020::LogData logdata;
                    int64_t ts = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
                    logdata.set_machine_id(1);
                    logdata.set_timestamp(ts);
                    logdata.set_direction(dir);
                    int64_t s,e;
                    s = preSheetStartPositionConveyor&0xFFFFFFFFu;
                    e = nowPosition&0xFFFFFFFFu;
                    if(dir>0 && e < s) e += 0x100000000ll;
                    else if(dir<0 && s < e) s += 0x100000000ll;
                    logdata.set_pos_start(s);
                    logdata.set_pos_end(e);
                    logdata.set_ticks(len);
                    logdata.set_gap_curr(curr_gap);
                    logdata.set_gap_old(prevGap);
                    logdata.set_length_cm_curr(0.1 * len / factorT2MM + SystemConfig::length_correction_constant*0.1);
                    logdata.set_length_cm_should(presheetWidth/10.0);
                    logdata.set_ticks2mm(presheetT2MM);
                    logdata.set_runmode_factor(rmodeF);
                    logdata.set_correction(correction);
                    logdata.set_time_ms(int32_t(diff_ms));
                    logdata.set_time_factor(lenFromTime);
                    logdata.set_speed_main(int32_t(std::fabs(movements.current().velocity()) * 100.0 / SystemConfig::speed100));
                    logdata.set_speed_feeder(movements.current().has_feedingbelt_speed_factor() ? int32_t(movements.current().feedingbelt_speed_factor()):0);
                    logdata.set_speed_extractor(movements.current().has_extractionbelt_speed_factor() ? int32_t(movements.current().extractionbelt_speed_factor()) : 0);
                    int logsize = logdata.ByteSize();
                    char *logbuf = logsize>0 ? new char[logsize] : nullptr;
                    if(logbuf && logdata.SerializeToArray(logbuf, logsize)) {
                        if(log_pipe_e>=0) nn_send(log_pipe_s,logbuf,size_t(logsize),0);
                    }
                    if(logbuf) delete[] logbuf;

                    fprintf(StdLogger::TRACE, "SW laser trigger changed to OFF at pos %u (validation start: %u, torque=%d)", machine.current_drum_rawposition(), program.triggerCtrl.triggerStartPos(), torque);
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d SW laser trigger changed to OFF (N, validation startpos=%u, torque=%d)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 program.triggerCtrl.triggerStartPos(), torque);
                    //                              dr st en len  t2mm  lenmm  gap   old  gapfr need  tm_ms lent  spd  fd ex
                    fprintf(StdLogger::ALERT,"/CSV/ %c %u %u %lld %.2lf %.2lf %.2lf %.2lf %.6lf %.2lf %.1lf %lld %.0lf %d %d no-drum %s %d"
                            , dirtxt[0], uint32_t(preSheetStartPositionConveyor), uint32_t(nowPosition), len, presheetT2MM, 1.0*len / factorT2MM, curr_gap, prevGap, prevGap<=0.0?0.0:(curr_gap/prevGap), presheetWidth, diff_ms, lenFromTime
                            , std::fabs(movements.current().velocity()) * 100.0 / SystemConfig::speed100,
                            movements.current().has_feedingbelt_speed_factor() ? int(movements.current().feedingbelt_speed_factor()) : 0,
                            movements.current().has_extractionbelt_speed_factor() ? int(movements.current().extractionbelt_speed_factor()) : 0
                                                                                    , SystemConfig::dynamic_mode?"dynamic":"no-dynamic", torque
                            );

                    if(SystemConfig::typ==SystemConfig::ECOSTAR){ //tmp solution for EcoStar
                        program.widthCtrl.setCurrentRawLength(len, uint32_t(len), nowPosLeft, nowPosRight);
                        movementInfo.set_current_length(len);
                    }else{
                        //fprintf(StdLogger::ALERT,"/LENGTH/ %s %u .. %u => %lld => %lld/%.2lf = %.2lf gap: %.2lf old: %.2lf => %.6lf wait: %.2lf time: %.1lf => %lld mm", dirtxt, uint32_t(preSheetStartPositionConveyor), uint32_t(nowPosition), len, len, presheetT2MM, 1.0*len / presheetT2MM, curr_gap, prevGap, prevGap<=0.0?0.0:(curr_gap/prevGap), presheetWidth, diff_ms, lenFromTime);
                        if(program.widthCtrl.isExtraMove()){//if this is the extra move to correct the side,
                                                            // just take the len value from the last step to avoid error
                           len = program.widthCtrl.currentRawLength();
                        }
                        program.widthCtrl.setCurrentRawLength(len, uint32_t(nowPosDrumReal), nowPosLeft, nowPosRight);
                        movementInfo.set_current_length(1.0*len / factorT2MM + SystemConfig::length_correction_constant);
                    }

                }

                /*printf("%s dough pos s/e = %lld/%lld (drum %lld/%lld, l=%.2lf cm), length = %.2lf cm (waiting for length %.2lf cm), gapsize = %.2lf\n",
                       dirtxt, preSheetStartPositionConveyor, nowPosReal,
                       preSheetStartPositionDrum, nowPosDrumReal, 0.1*lenDrum/presheetT2MM,
                       0.1*len/presheetT2MM, presheetWidth/10.0, curr_gap);*/

                if(dir!=0) program.setDoughSide(dir);

                if(movements.has_current() && movements.current().has_type() &&
                        movements.current().has_flourduster() && movements.current().flourduster()) {
                    // turn off flourduster after dough passed laser trigger
                    sheeter2020::Movement_MovementType tp = movements.current().type();
                    if(tp==sheeter2020::Movement_MovementType::Movement_MovementType_COMPASS_REDUCTION_TRIGGER ||
                            tp==sheeter2020::Movement_MovementType::Movement_MovementType_COMPASS_FINAL_CUTOMAT ||
                            tp==sheeter2020::Movement_MovementType::Movement_MovementType_COMPASS_FINAL_TRANSPORT ||
                            tp==sheeter2020::Movement_MovementType::Movement_MovementType_COMPASS_FINAL_AUTOREEL ||
                            tp==sheeter2020::Movement_MovementType::Movement_MovementType_COMPASS_FINAL_MANUALREEL) {
                        machine.change_duster(false);
                    }
                }

                return true;
            }
        }else{
            if(laser_trigger){
                laserCnt += 1;
            }
        }
        return false; // END OF CHECK
    }

    void insert_planned_movement(double gapsize, const char *extra_text, bool isEmptyRun)
    {
        fprintf(StdLogger::DBG,"inserting extra movement with gapsize %.2lf for %s /DBG/", gapsize, extra_text);
        logMoves.fmt("inserting extra movement with gapsize %.2lf for %s", gapsize, extra_text);

        if(isEmptyRun){
            movementInfo.set_extra_empty_run_gapsize(gapsize);
            sendCnt = 5;
            logMoves.fmt("Send the empty run gapsize: %.2lf to GUI for display", gapsize);
        }

        sheeter2020::PlannedMovements saved;

        if(movements.planned_size()>0) {
            // save planned
            saved.mutable_planned()->CopyFrom(movements.planned());

            // clear planned
            movements.clear_planned();

            // add first extra movement
            movements.add_planned();

            // add saved movements
            movements.mutable_planned()->MergeFrom(saved.planned());
        } else {
            movements.add_planned();
        }

        sheeter2020::Movement *first = movements.mutable_planned(0);
        first->set_type(sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER);
        first->set_gapsize(gapsize);
        first->set_velocity(program.speedCtrl.current());
        first->set_feedingbelt_speed_factor(infeedSpeedPreviousStep);
        first->set_extractionbelt_speed_factor(extractionSpeedPreviousStep);
    }

    void clear_current_presheet()
    {
        bool needStop = program.widthCtrl.shouldStop();
        program.widthCtrl.clear();
        if(!movements.has_current()) return;

        if(needStop) {
            if(movements.planned_size()>0) movements.clear_planned();
        }
    }

    void handle_manual_reeler(tBINLOG &bindata, const bool laser_trigger_p, const bool inertia, const Movement &cur, const time_point& now)
    {
        if ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia())) {
            // Waiting for gap to move
        } else if (gapSizeStatusReached == false) {
            // Gap is done, now reset trigger and pause
            gapSizeStatusReached = true;
            last_gapsize_reached = now;
            lastLaserStatus = false;
            //waitForStartButtonPressed = true;
            //pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_PRE_REEL;
            //stepPaused = true;
            //last_pause_begin = now;
            autoreelMidstep = AR_STEP_UNUSED;
            bindata.midstep = autoreelMidstep;
            start_endhaspel_belt(true);
            logMoves.fmt("### gapsize reached, starting substeps of manual reeler (STEP_UNUSED)");
        } else {
            double head_distance = 0.0, tail_distance = 0.0;
            double tail_stop_offset = 500.0;

            // check and set dough start/end from trigger
            int64_t laserTriggerDelay = 150; // ms
            if(laser_trigger_p != lastLaserStatus) {
                if(laser_trigger_p) {
                    // laser trigger rising edge
                    lastLaserStatus = true;
                    lasertrigger_rising_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    autoreelMidstep = AR_STEP_TRIGGER_START;
                    bindata.midstep = autoreelMidstep;
                    //autohaspel_last_check = 0;
                    autohaspel_dough_start_position = SystemConfig::manualreel_at_right_side ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                    headCnt = 1;
                    tailCnt = 0;
                    logMoves.fmt("### trigger ON ****** pos=%011lld: dough begin detected for manual haspel (STEP_TRIGGER_START)", autohaspel_dough_start_position);
                } else {
                    // laser trigger falling edge
                    lasertrigger_falling_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    lastLaserStatus = false;
                    int64_t rb_pos;
                    double pos_diff;
                    if(SystemConfig::manualreel_at_right_side) {
                        rb_pos = machine.current_rightbelt_rawposition();
                        if(rb_pos < autohaspel_dough_start_position) {
                            rb_pos += 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = rb_pos - autohaspel_dough_start_position;
                    } else {
                        rb_pos = machine.current_leftbelt_rawposition();
                        if(rb_pos > autohaspel_dough_start_position) {
                            rb_pos -= 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = autohaspel_dough_start_position - rb_pos;
                    }
                    tailCnt = 1;
                    logMoves.fmt("### trigger OFF **** pos=%011lld: dough end detected, %.3lf mm passed since dough begin (for manual haspel, STEP_unchanged)",
                                 autohaspel_dough_end_position, pos_diff / positionTicksPerMillimeter);
                }
            }

            // check distance of dough end to the center
            if(autoreelMidstep != AR_STEP_UNUSED && lastLaserStatus==false) {
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::manualreel_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_end_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_end_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_end_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_end_position - rb_pos;
                }

                //for EcoStar only
                if( SystemConfig::typ==SystemConfig::ECOSTAR ){
                    if(tailCnt > 0 && autoreelMidstep != AR_STEP_SLOW_MOVE &&  autoreelMidstep !=AR_STEP_WHILE_SLOW_MOVE){
                        tailCnt += 1;
                    }
                    tail_distance = SystemConfig::ecostar_speed_left * 4.8 * tailCnt ;
                }else{ //for Compas and RondoStar
                    tail_distance = pos_diff/positionTicksPerMillimeter;
                }
            }

            // check distance of dough begin to the center
            if(autoreelMidstep != AR_STEP_UNUSED) {
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::manualreel_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_start_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_start_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_start_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_start_position - rb_pos;
                }

                //for EcoStar only
                if(SystemConfig::typ==SystemConfig::ECOSTAR){
                    if(headCnt > 0 && autoreelMidstep != AR_STEP_SLOW_MOVE &&  autoreelMidstep !=AR_STEP_WHILE_SLOW_MOVE){
                        headCnt += 1;
                    }
                    head_distance = SystemConfig::ecostar_speed_left * 1.2 * headCnt ;
                }else{ //For Compas and RondoStar
                    head_distance = pos_diff/positionTicksPerMillimeter;
                }
            }

            if(autoreelMidstep == AR_STEP_TRIGGER_START && head_distance>0.0 && head_distance >= finish_length_factor*(SystemConfig::reel_length+50.0)) {
                // front of dough just behind manual reeler, so pause now
                autoreelMidstep = AR_STEP_SLOW_MOVE;
                bindata.midstep = autoreelMidstep;
                machine.stop_all_servos();
                logMoves.fmt("====================== pause in front of reeler, before slow speed, head dist = %.1lf (STEP_SLOW)",head_distance);
                pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_REEL;
                stepPaused = true;
                last_pause_begin = now;
            } else if(autoreelMidstep == AR_STEP_SLOW_MOVE) {
                // mark start of slow speed
                pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
                autoreelMidstep = AR_STEP_WHILE_SLOW_MOVE;
                bindata.midstep = autoreelMidstep;
                if(SystemConfig::typ==SystemConfig::ECOSTAR){ //For EcoStar, start the belt after pause
                    change_belts_speed(0.0);
                }
                logMoves.fmt("====================== mark slow speed start (STEP_AFTER_SLOW)");
                autohaspel_starttime_slow = now;
            } else if(autoreelMidstep == AR_STEP_FINISH || autoreelMidstep == AR_STEP_WHILE_SLOW_MOVE || autoreelMidstep == AR_STEP_AFTER_SLOW_MOVE || autoreelMidstep == AR_STEP_FINISH_DELAY) {
                double tail_distance_end = SystemConfig::reel_length+SystemConfig::manualreel_length_extra;
                if(SystemConfig::typ!=SystemConfig::ECOSTAR){ //For Compas & RondoStar
                    tail_distance_end = tail_distance_end - tail_stop_offset;
                }

                if(tail_distance>0.0 && tail_distance >= finish_length_factor*tail_distance_end) {

                    if(autoreelMidstep == AR_STEP_FINISH_DELAY ){
                        long delayTime = long(std::chrono::duration_cast<std::chrono::milliseconds>(now-haspel_end_delay_time).count());
                        long delaySetting = 0;

                        if(SystemConfig::typ ==SystemConfig::ECOSTAR && cur.has_duration()){
                            delaySetting = cur.duration()*1000;
                        }else if(SystemConfig::typ!=SystemConfig::ECOSTAR && cur.has_reel_delay_time()){
                            delaySetting = cur.reel_delay_time()*1000;
                        }

                        if(pause_time_ecostar_s > 0){
                            delayTime = delayTime - pause_time_ecostar_s * 1000; // if pause happens during the last delay time
                        }
                        if(delayTime > delaySetting){ //delay 2 s
                            // end of dough just behind the manual reeler
                            autoreelMidstep = AR_STEP_UNUSED;
                            bindata.midstep = autoreelMidstep;
                            logMoves.fmt("====================== current step finished, %.1lf mm passed since dough end (for auto haspel, STEP_UNUSED)", tail_distance);
                            clear_current_movements("after manual reel finished");
                            machine.stop_all_servos();
                            headCnt = 0; //For EcoStar
                            tailCnt = 0; //For EcoStar
                            autoreelMidstep = AR_STEP_UNUSED;
                            bindata.midstep = autoreelMidstep;
                        }

                    }else{
                        autoreelMidstep = AR_STEP_FINISH_DELAY;
                        bindata.midstep = autoreelMidstep;
                        haspel_end_delay_time = now;
                        pause_time_ecostar_s = 0;
                        logMoves.fmt("====================== current step finish delay, EcoStar manually reeler delay time before final finish");
                    }


                    /*}else { //For Compass and RondoStar
                        // end of dough just behind the manual reeler
                        autoreelMidstep = AR_STEP_UNUSED;
                        bindata.midstep = autoreelMidstep;
                        logMoves.fmt("====================== current step finished, %.1lf mm passed since dough end (for manual haspel, STEP_UNUSED)", tail_distance);
                        clear_current_movements("after manual reel finished");
                        machine.stop_all_servos();
                        autoreelMidstep = AR_STEP_UNUSED;
                        bindata.midstep = autoreelMidstep;
                    }*/


                } else if((autoreelMidstep == AR_STEP_AFTER_SLOW_MOVE || autoreelMidstep == AR_STEP_WHILE_SLOW_MOVE) && tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::reel_length-tail_stop_offset)) {
                    // end of dough just before the manual reeler, change normal speed to 50%
                    autoreelMidstep = AR_STEP_FINISH;
                    bindata.midstep = autoreelMidstep;
                    double speed50 = cur.has_velocity_50() ? cur.velocity_50() : 0.0;
                    if(speed50>0.01) {
                        logMoves.fmt("====================== change speed to 50%c (%.1lf), head dist = %.1lf, duration = %ld ms (STEP_FINISH)", '%', speed50, head_distance, long(std::chrono::duration_cast<std::chrono::milliseconds>(now-autohaspel_starttime_slow).count()));
                        change_belts_speed(speed50);
                    }
                } else if(autoreelMidstep == AR_STEP_WHILE_SLOW_MOVE && (now-autohaspel_starttime_slow)>std::chrono::milliseconds(int(cur.has_duration()?cur.duration()*1000:0.0))) {
                    // timeout of slow speed, change to normal speed
                    autoreelMidstep = AR_STEP_AFTER_SLOW_MOVE;
                    bindata.midstep = autoreelMidstep;
                    logMoves.fmt("====================== change speed to normal, head dist = %.1lf, duration = %ld ms (STEP_FINISH)", head_distance, long(std::chrono::duration_cast<std::chrono::milliseconds>(now-autohaspel_starttime_slow).count()));
                    change_belts_speed(0.0);
                }
            }
        }
    }

    void handle_auto_reeler(tBINLOG &bindata, const bool laser_trigger_p, const bool inertia, const Movement &cur, const time_point& now)
    {
        if ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia())) {
            // Waiting for gap to move
        } else if (gapSizeStatusReached == false) {
            // Gap is done, now reset trigger and continue
            gapSizeStatusReached = true;
            last_gapsize_reached = now;
            lastLaserStatus = false;
            autoreelMidstep = AR_STEP_UNUSED;
            bindata.midstep = autoreelMidstep;
            logMoves.fmt("### gapsize reached, starting substeps of auto reeler (STEP_UNUSED)");
            if(SystemConfig::typ==SystemConfig::ECOSTAR){
                machine.close_autohaspel();
                logMoves.fmt("### force the hapsel to close for Ecostar )");
            }

        } else if (doughReelerIsClosing) {
            if ((now - timestamp_step_begin) > std::chrono::seconds(2)) {
                doughReelerIsOpening = false;
                doughReelerIsClosing = false;
                start_endhaspel_belt(false);
                printf("****** start endhaspel belt (2)");
            }
        } else {
            double head_distance = 0.0, tail_distance = 0.0;
            double tail_stop_offset = 700.0;

            // check and set dough start/end from trigger
            int64_t laserTriggerDelay = 150; // ms
            if(laser_trigger_p != lastLaserStatus) {
                if(laser_trigger_p) {
                    // laser trigger rising edge
                    lastLaserStatus = true;
                    lasertrigger_rising_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    autoreelMidstep = AR_STEP_TRIGGER_START;
                    bindata.midstep = autoreelMidstep;
                    //autohaspel_last_check = 0;
                    autohaspel_dough_start_position = SystemConfig::autoreel_at_right_side ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                    headCnt = 1; //for EcoStar
                    tailCnt = 0; //for EcoStar
                    logMoves.fmt("====================== trigger ON ****** pos=%011lld: dough begin detected for auto haspel (STEP_TRIGGER_START)", autohaspel_dough_start_position);
                } else {
                    // laser trigger falling edge
                    lasertrigger_falling_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    lastLaserStatus = false;
                    int64_t rb_pos;
                    double pos_diff;
                    if(SystemConfig::autoreel_at_right_side) {
                        rb_pos = machine.current_rightbelt_rawposition();
                        if(rb_pos < autohaspel_dough_start_position) {
                            rb_pos += 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = rb_pos - autohaspel_dough_start_position;
                    } else {
                        rb_pos = machine.current_leftbelt_rawposition();
                        if(rb_pos > autohaspel_dough_start_position) {
                            rb_pos -= 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = autohaspel_dough_start_position - rb_pos;
                    }
                    tailCnt = 1; //For EcoStar
                    logMoves.fmt("====================== trigger OFF **** pos=%011lld: dough end detected, %.3lf mm passed since dough begin (for auto haspel, STEP_unchanged)",
                                 autohaspel_dough_end_position, pos_diff / positionTicksPerMillimeter);
                    //autoreelMidstep = AR_STEP_FINISH;
                }
            }

            // check distance of dough end to the center
            if(autoreelMidstep != AR_STEP_UNUSED && lastLaserStatus==false) {
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::autoreel_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_end_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_end_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_end_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_end_position - rb_pos;
                }

                //for EcoStar only
                if(SystemConfig::typ==SystemConfig::ECOSTAR){
                    if(tailCnt > 0){
                        tailCnt += 1;
                        tail_distance = SystemConfig::ecostar_speed_left *2.5 * tailCnt ;
                    }
                }else{ //For Compas & RondoStar
                    tail_distance = pos_diff/positionTicksPerMillimeter;
                }
            }

            // check distance of dough begin to the center
            if(autoreelMidstep != AR_STEP_UNUSED) {
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::autoreel_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_start_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_start_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_start_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_start_position - rb_pos;
                }

                //for EcoStar only
                if(SystemConfig::typ==SystemConfig::ECOSTAR){
                    if(headCnt > 0){
                        headCnt += 1;
                        head_distance = SystemConfig::ecostar_speed_left * headCnt ;
                    }
                }else{ //For Compas & RondoStar
                    head_distance = pos_diff/positionTicksPerMillimeter;
                }
            }

            //For EcoStar, go to AR_STEP_SLOW_MOVE step directly
            if((SystemConfig::typ==SystemConfig::ECOSTAR && autoreelMidstep == AR_STEP_TRIGGER_START) ||
                    (autoreelMidstep == AR_STEP_TRIGGER_START && head_distance>0.0 && head_distance >= finish_length_factor*(SystemConfig::autoreel_length-200.0))) {
                // front of dough just before auto reeler, so slow down
                autoreelMidstep = AR_STEP_SLOW_MOVE;
                bindata.midstep = autoreelMidstep;
                double slowSpeed = 0.0;
                if(cur.has_velocity_slow()) {
                    slowSpeed = cur.velocity_slow();
                    //                    if(slowFactor<0.01) slowFactor = 0.5;
                    //                    else if(slowFactor<0.1) slowFactor = 0.1;
                    //                    else if(slowFactor>0.9) slowFactor = 0.9;
                }
                if(slowSpeed>0.0) change_belts_speed(slowSpeed);
                autohaspel_starttime_slow = now;
                logMoves.fmt("====================== continue move in front of reeler, head dist = %.1lf (STEP_SLOW)",head_distance);
            } else if(autoreelMidstep == AR_STEP_FINISH || autoreelMidstep == AR_STEP_SLOW_MOVE || autoreelMidstep == AR_STEP_AFTER_SLOW_MOVE || autoreelMidstep == AR_STEP_FINISH_DELAY) {
                double tail_distance_end = SystemConfig::autoreel_length+SystemConfig::autoreel_length_extra;
                if(SystemConfig::typ!=SystemConfig::ECOSTAR){ //For Compas & RondoStar
                    tail_distance_end = tail_distance_end - tail_stop_offset;
                }
                if(tail_distance>0.0 && tail_distance >= finish_length_factor*tail_distance_end) {

                    if(autoreelMidstep == AR_STEP_FINISH_DELAY ){
                        long delayTime = long(std::chrono::duration_cast<std::chrono::milliseconds>(now-haspel_end_delay_time).count());
                        long delaySetting = 0;

                        if(SystemConfig::typ ==SystemConfig::ECOSTAR && cur.has_duration()){
                            delaySetting = cur.duration()*1000;
                        }else if(SystemConfig::typ!=SystemConfig::ECOSTAR && cur.has_reel_delay_time()){
                            delaySetting = cur.reel_delay_time()*1000;
                        }
                        if(pause_time_ecostar_s > 0){
                            delayTime = delayTime - pause_time_ecostar_s * 1000; // if pause happens during the last delay time
                        }
                        if(delayTime > delaySetting){ //delay time done
                            // end of dough just behind the auto reeler
                            autoreelMidstep = AR_STEP_UNUSED;
                            bindata.midstep = autoreelMidstep;
                            logMoves.fmt("====================== current step finished, %.1lf mm passed since dough end (for auto haspel, STEP_UNUSED)", tail_distance);
                            clear_current_movements("after auto reel finished");
                            machine.stop_all_servos();
                            open_haspel();
                            headCnt = 0; //For EcoStar
                            tailCnt = 0; //For EcoStar
                            autoreelMidstep = AR_STEP_UNUSED;
                            bindata.midstep = autoreelMidstep;
                        }

                    }else{
                        autoreelMidstep = AR_STEP_FINISH_DELAY;
                        bindata.midstep = autoreelMidstep;
                        haspel_end_delay_time = now;
                        pause_time_ecostar_s = 0;
                        logMoves.fmt("====================== current step finish delay, reeler delay before final finish");
                    }

                } else if(autoreelMidstep == AR_STEP_SLOW_MOVE && (now-autohaspel_starttime_slow)>std::chrono::milliseconds(int(cur.has_duration()?cur.duration()*1000:0.0))) {
                    // end of slow speed, change to normal speed or 50% or finish all
                    if(tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::autoreel_length+SystemConfig::autoreel_length_extra)) {
                        // end of dough just behind the auto reeler
                        autoreelMidstep = AR_STEP_UNUSED;
                        bindata.midstep = autoreelMidstep;
                        logMoves.fmt("====================== current step finished, %.1lf mm passed since dough end (for auto haspel, STEP_UNUSED)", tail_distance);
                        clear_current_movements("after auto reel finished");
                        machine.stop_all_servos();
                        open_haspel();
                        autoreelMidstep = AR_STEP_UNUSED;
                        bindata.midstep = autoreelMidstep;
                    //} else if(tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::autoreel_length-300.0)) {
                    } else if(tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::autoreel_length-tail_stop_offset)) {
                        // end of dough just before the automatic reeler, so slow down to 50%
                        autoreelMidstep = AR_STEP_FINISH;
                        bindata.midstep = autoreelMidstep;
                        double speed50 = cur.has_velocity_50() ? cur.velocity_50() : 0.0;
                        if(speed50>0.01) {
                            logMoves.fmt("====================== slow down to 50%c (%.1lf) in front of reeler, head dist = %.1lf (STEP_FINISH)",'%', speed50, head_distance);
                            change_belts_speed(speed50);
                        }
                    } else {
                        autoreelMidstep = AR_STEP_AFTER_SLOW_MOVE;
                        bindata.midstep = autoreelMidstep;
                        logMoves.fmt("====================== change to normal speed, head dist = %.1lf (STEP_AFTER_SLOW)", head_distance);
                        change_belts_speed(0.0);
                    }
                //} else if(autoreelMidstep == AR_STEP_AFTER_SLOW_MOVE && tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::autoreel_length-300.0)) {
                } else if(autoreelMidstep == AR_STEP_AFTER_SLOW_MOVE && tail_distance>0.0 && tail_distance >= finish_length_factor*(SystemConfig::autoreel_length-tail_stop_offset)) {
                    // end of dough just before the automatic reeler, so slow down to 50%
                    autoreelMidstep = AR_STEP_FINISH;
                    bindata.midstep = autoreelMidstep;
                    double speed50 = cur.has_velocity_50() ? cur.velocity_50() : 0.0;
                    if(speed50>0.01) {
                        logMoves.fmt("====================== slow down to 50%c (%.1lf) in front of reeler, head dist = %.1lf (STEP_FINISH)",'%', speed50, head_distance);
                        change_belts_speed(speed50);
                    }
                }
            }
        }
    }

    void handle_cutomat(tBINLOG &bindata, const bool laser_trigger_p, const bool inertia, const Movement &cur, const time_point& now)
    {
        if ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia())) {
            // Waiting for gap to move
        } else if (gapSizeStatusReached == false) {
            // Gap is done, now reset trigger and continue
            gapSizeStatusReached = true;
            last_gapsize_reached = now;
            lastLaserStatus = false;
            //waitForStartButtonPressed = true;
            autoreelMidstep = AR_STEP_UNUSED;
            bindata.midstep = autoreelMidstep;
            pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_CUTOMAT;
            stepPaused = true;
            last_pause_begin = now;
        } else {
            int64_t laserTriggerDelay = 150; // ms
            if(laser_trigger_p != lastLaserStatus) {
                if(laser_trigger_p) {
                    // laser trigger rising edge
                    lastLaserStatus = true;
                    lasertrigger_rising_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    //autoreelMidstep = AR_STEP_TRIGGER_START;
                    autoreelMidstep = AR_STEP_SLOW_MOVE;
                    bindata.midstep = autoreelMidstep;
                    //autohaspel_last_check = 0;
                    autohaspel_dough_start_position = SystemConfig::cutomat_at_right_side ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                    double slowSpeed = cur.has_velocity_slow() ? cur.velocity_slow() : 0.0;
                    printf("****** pos=%011lld: dough begin detected for cutomat, down speed to %.1lf", autohaspel_dough_start_position,slowSpeed);
                    //change_belts_speed(slowFactor);
                    start_cutomat_belt();
                } else {
                    // laser trigger falling edge
                    lasertrigger_falling_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    lastLaserStatus = false;
                    int64_t rb_pos;
                    double pos_diff;
                    if(SystemConfig::cutomat_at_right_side) {
                        rb_pos = machine.current_rightbelt_rawposition();
                        if(rb_pos < autohaspel_dough_start_position) {
                            rb_pos += 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = rb_pos - autohaspel_dough_start_position;
                    } else {
                        rb_pos = machine.current_leftbelt_rawposition();
                        if(rb_pos > autohaspel_dough_start_position) {
                            rb_pos -= 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = autohaspel_dough_start_position - rb_pos;
                    }
                    printf("****** pos=%011lld: dough end detected, %.3lf mm passed since dough begin (for cutomat)",
                           autohaspel_dough_end_position, pos_diff / positionTicksPerMillimeter);
                    autoreelMidstep = AR_STEP_FINISH;
                    bindata.midstep = autoreelMidstep;
                }
            }
            if(!lastLaserStatus && autoreelMidstep==AR_STEP_FINISH) {
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::cutomat_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_end_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_end_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_end_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_end_position - rb_pos;
                }

                double distance_need_mm = finish_length_factor*SystemConfig::cutomat_extra;
                double distance_extra_mm = 0.0;
                if(cur.has_velocity()) {
                    double v_prc = 0.0;
                    double outfeed_val = cur.has_extractionbelt_speed_factor() ? cur.extractionbelt_speed_factor() : 0.0;
                    if(outfeed_val<=0.0) outfeed_val = 100.0;
                    v_prc = std::abs(cur.velocity()*outfeed_val)/(SystemConfig::speed100*0.88); //1500.0;
                    if(v_prc>101.0) v_prc = 101.0;
                    if(v_prc<0.1) v_prc = 0.1;
                    distance_extra_mm = (100.0-v_prc) * SystemConfig::stop_pos_correction_transfer / 50.0;
                    if(v_prc>=0.09 && SystemConfig::stop_pos_correction_transfer>=0) distance_need_mm += distance_extra_mm;
                }

                //if(pos_diff/positionTicksPerMillimeter >= finish_length_factor*(SystemConfig::autoreel_length+SystemConfig::cutomat_extra)) {
                if(pos_diff/positionTicksPerMillimeter >= distance_need_mm) {
                    // cutomat ready
                    printf("****** pos=%011lld: %.3lf mm passed since dough end (for cutomat, needed %.3lf+%.3lf mm)",
                           rb_pos, pos_diff / positionTicksPerMillimeter, distance_need_mm, distance_extra_mm);
                    clear_current_movements("after cutomat finished");
                    machine.stop_all_servos();
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                }
            }
        }
    }

    void handle_transport(tBINLOG &bindata, const bool laser_trigger_p, bool inertia, const Movement &cur, const time_point& now)
    {
        if ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia())) {
            // Waiting for gap to move
        } else if (gapSizeStatusReached == false) {
            // Gap is done, now reset trigger and continue
            gapSizeStatusReached = true;
            last_gapsize_reached = now;
            lastLaserStatus = false;
            autoreelMidstep = AR_STEP_UNUSED;
            bindata.midstep = autoreelMidstep;
            start_transport_belt();
        } else {
            int64_t laserTriggerDelay = 150; // ms
            if(laser_trigger_p != lastLaserStatus) {
                if(laser_trigger_p) {
                    // laser trigger rising edge
                    lastLaserStatus = true;
                    lasertrigger_rising_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    autoreelMidstep = AR_STEP_BEFORE_TRANSPORT_STOP;
                    bindata.midstep = autoreelMidstep;
                    hasEndPosition = false;
                    //autohaspel_last_check = 0;
                    autohaspel_dough_start_position = SystemConfig::transport_at_right_side ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough begin detected (transport, startpos:%lu)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 autohaspel_dough_start_position);
                } else {
                    lasertrigger_falling_edge = now - std::chrono::milliseconds(laserTriggerDelay);
                    lastLaserStatus = false;
                    int64_t rb_pos;
                    double pos_diff;
                    autohaspel_dough_end_position = SystemConfig::transport_at_right_side ? machine.current_rightbelt_rawposition() : machine.current_leftbelt_rawposition();
                    autohaspel_dough_end_position_raw = autohaspel_dough_end_position;
                    if(SystemConfig::transport_at_right_side) {
                        rb_pos = machine.current_rightbelt_rawposition();
                        if(rb_pos < autohaspel_dough_start_position) {
                            rb_pos += 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = rb_pos - autohaspel_dough_start_position;
                    } else {
                        rb_pos = machine.current_leftbelt_rawposition();
                        if(rb_pos > autohaspel_dough_start_position) {
                            rb_pos -= 0x100000000u;
                        }
                        autohaspel_dough_end_position = rb_pos;
                        pos_diff = autohaspel_dough_start_position - rb_pos;
                    }
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough end detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter);
                    if(autoreelMidstep==AR_STEP_BEFORE_TRANSPORT_STOP || autoreelMidstep==AR_STEP_AFTER_TRANSPORT_STOP) {
                        hasEndPosition = true;
                    }
                }
            }
            if(autoreelMidstep == AR_STEP_BEFORE_TRANSPORT_STOP) {
                // check if begin of dough is passing stop position before end of table
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::transport_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_start_position) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_start_position;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_start_position) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_start_position - rb_pos;
                }

                double distance_need_mm = SystemConfig::transp_length_before;
                double distance_extra_mm = 0.0;
                if(cur.has_velocity()) {
                    double v_prc = 0.0;
                    double outfeed_val = cur.has_extractionbelt_speed_factor() ? cur.extractionbelt_speed_factor() : 0.0;
                    if(outfeed_val<=0.0) outfeed_val = 100.0;
                    v_prc = std::abs(cur.velocity()*outfeed_val)/(SystemConfig::speed100*0.88); //1500.0;
                    if(v_prc>101.0) v_prc = 101.0;
                    if(v_prc<0.1) v_prc = 0.1;
                    distance_extra_mm = (100.0-v_prc) * SystemConfig::stop_pos_correction_transfer / 50.0;
                    if(v_prc>=0.09 && SystemConfig::stop_pos_correction_transfer>=0) distance_need_mm += distance_extra_mm;
                }

                if(pos_diff / positionTicksPerMillimeter >= distance_need_mm) {
                    if(SystemConfig::transport_mode==SystemConfig::TransportMode::TT_US) {
                        // transport ready
                        program.set_us_speed(cur.has_velocity_slow()?cur.velocity_slow():0.0);
                        logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough stop detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm, tobe:%.1lf+%.1lf mm, US ready)",
                                     machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                     autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter, SystemConfig::transp_length_before, distance_extra_mm);
                        clear_current_movements("after transport finished TT_US");
                        machine.stop_all_servos();
                        autoreelMidstep = AR_STEP_UNUSED;
                        bindata.midstep = autoreelMidstep;
                        hasEndPosition = false;
                    } else {
                        if(autoreelMidstep == AR_STEP_BEFORE_TRANSPORT_STOP) {
                            autoreelMidstep = AR_STEP_AFTER_TRANSPORT_STOP;
                            bindata.midstep = autoreelMidstep;
                        }

                        // check external digital ON/OFF

                        bool ext_ok = true;
                        double ext_speed = 0.0;
                        if(transport_bit && SystemConfig::transport_mode==SystemConfig::TransportMode::FBT) {
                            ext_speed = SystemConfig::transp_a * transport_val + SystemConfig::transp_c;
                            if(ext_speed<0.1 || ext_speed<(SystemConfig::transp_c+0.1) || SystemConfig::ticks2mm_belt<1.0) ext_ok = false;
                            else ext_speed = ext_speed * 10.0; // / SystemConfig::ticks2mm_belt;
                        }
                        if(!transport_bit || !ext_ok) {
                            //waitForStartButtonPressed = true;
                            //                            pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_TRANSPORT;
                            //                            stepPaused = true;
                            //                            last_pause_begin = now;
                            sw_stop_request = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_TRANSPORT;
                            //                            machine.stop_all_servos();
                            logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough pause detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm, tobe:%.1lf+%.1lf mm, ext-speed:%.1lf mm/s, pausing)",
                                         machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                         autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter, SystemConfig::transp_length_before, distance_extra_mm, ext_speed);
                        } else if(SystemConfig::transport_mode==SystemConfig::TransportMode::FBT) {
                            logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough pause detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm, tobe:%.1lf+%.1lf mm, ext-speed:%.1lf, run ext-speed)",
                                         machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                         autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter, SystemConfig::transp_length_before, distance_extra_mm, ext_speed);
                            start_transport_belt();
                        } else {
                            logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough pause detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm, tobe:%.1lf+%.1lf mm, continue)",
                                         machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                         autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter, SystemConfig::transp_length_before, distance_extra_mm);
                            start_transport_belt();
                        }
                    }
                }
            } else if(autoreelMidstep == AR_STEP_AFTER_TRANSPORT_STOP && hasEndPosition) {
                // begin of dough has passed stop position and end of dough has passed laser trigger
                int64_t rb_pos;
                double pos_diff;
                if(SystemConfig::transport_at_right_side) {
                    rb_pos = machine.current_rightbelt_rawposition();
                    if(rb_pos < autohaspel_dough_end_position_raw) {
                        rb_pos += 0x100000000u;
                    }
                    pos_diff = rb_pos - autohaspel_dough_end_position_raw;
                } else {
                    rb_pos = machine.current_leftbelt_rawposition();
                    if(rb_pos > autohaspel_dough_end_position_raw) {
                        rb_pos -= 0x100000000u;
                    }
                    pos_diff = autohaspel_dough_end_position_raw - rb_pos;
                }

                double distance_need_mm = SystemConfig::transp_length_before + SystemConfig::transp_length_extra;
                double distance_extra_mm = 0.0;
                if(cur.has_velocity()) {
                    double v_prc = 0.0;
                    double outfeed_val = cur.has_extractionbelt_speed_factor() ? cur.extractionbelt_speed_factor() : 0.0;
                    if(outfeed_val<=0.0) outfeed_val = 100.0;
                    v_prc = std::abs(cur.velocity()*outfeed_val)/(SystemConfig::speed100*0.88); //1500.0;
                    if(v_prc>101.0) v_prc = 101.0;
                    if(v_prc<0.1) v_prc = 0.1;
                    distance_extra_mm = (100.0-v_prc) * SystemConfig::stop_pos_correction_transfer / 50.0;
                    if(v_prc>=0.09 && SystemConfig::stop_pos_correction_transfer>=0) distance_need_mm += distance_extra_mm;
                }

                if(pos_diff / positionTicksPerMillimeter >= distance_need_mm) {
                    // transport ready
                    logMoves.fmt("L:%010u D:%010u R:%010u DIR:%+d dough stop detected (transport, endpos:%lu, diff:%.1lf=%.1lf mm, tobe:%.1lf+%.1lf+%.1lf mm, finished)",
                                 machine.current_leftbelt_rawposition(), machine.current_drum_rawposition(), machine.current_rightbelt_rawposition(), machine.current_belts_direction(),
                                 autohaspel_dough_end_position, pos_diff, pos_diff / positionTicksPerMillimeter, SystemConfig::transp_length_before, SystemConfig::transp_length_extra, distance_extra_mm);
                    clear_current_movements("after transport finished");
                    machine.stop_all_servos();
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                    hasEndPosition = false;
                    //                } else {
                    //                    // transport still moving
                    //                    printf("****** pos=%011lld: %.3lf mm passed since dough end (for transport, need %.3lf)",
                    //                           rb_pos, pos_diff / positionTicksPerMillimeter, finish_length_factor * (SystemConfig::transp_length_before+200.0));
                }
            }
        }
    }

    void handle_flourduster()
    {
        if(!flourduster_delayed) return;
        time_point now = clock::now();
        long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(now-flourduster_delay_start).count();
        long long min_ms = SystemConfig::flourduster_delay;
        if(movements.has_current() && movements.current().has_velocity() && SystemConfig::speed100>0.0 && (SystemConfig::typ!=SystemConfig::ECOSTAR)) {
            double f,v;
            v = movements.current().velocity();
            if(v<0.0) v = -v;
            if(movements.current().has_feedingbelt_speed_factor()) {
                f = movements.current().feedingbelt_speed_factor();
                v = v * f / 100.0;
            }
            if(v>0.0) {
                f = SystemConfig::speed100 / v;
                if(f<0) f = 0;
                min_ms = int64_t(std::round(f*min_ms));
            }
        }
        if(ms >= min_ms) {
            flourduster_delayed = false;
            machine.change_duster(true);
        }
    }

    void handle_servo_status(const ServoStatusBatch &newStatus, tBINLOG &bindata)
    {
        if(newStatus.ByteSize()<=0) return;
        bool safety_cage_open_p = machine_interface_t::is_safety_cage_open(newStatus);
        bool left_button_p = machine_interface_t::is_left_button_pressed(newStatus);
        bool right_button_p = machine_interface_t::is_right_button_pressed(newStatus);

        static TRACED_VAR(laser_trigger_p,bool,false);

        auto now = clock::now();

        machine.reset_all_servo_errors();

        handle_flourduster();

        if (!safety_cage_open_p)
            machine.turn_all_servos_on();

        // check some inertia
        bool inertia = false;
        for(int i=0; i<newStatus.statuses_size(); i++) {
            if(!newStatus.statuses(i).has_servo_id()) continue;
            uint32_t drvid = newStatus.statuses(i).servo_id();
            if(drvid<=2u) {
                int to_be = newStatus.statuses(i).has_target_velocity() ? newStatus.statuses(i).target_velocity() : 0;
                int curr = newStatus.statuses(i).has_velocity() ? newStatus.statuses(i).velocity() : 0;
                if(to_be==0 && std::abs(curr)>0) inertia = true;
            }
            if(drvid!=1) continue;

            if(newStatus.statuses(i).has_ext_coupler()) {
                auto ext = newStatus.statuses(i).ext_coupler();
                if(ext.has_digital_in_ext()) {
                    transport_bit = ext.digital_in_ext()!=0;
                }
                if(ext.has_analog_in_ext()) {
                    transport_val = ext.analog_in_ext();
                }
            }

            if(!newStatus.statuses(i).has_velocity() || !newStatus.statuses(i).has_target_velocity() || !newStatus.statuses(i).has_position_raw()) {
                //if(!newStatus.statuses(i).has_velocity()) fprintf(StdLogger::DBG,"!!!! no current velocity");
                //else if(!newStatus.statuses(i).has_target_velocity()) fprintf(StdLogger::DBG,"!!!! no target velocity");
                //else if(!newStatus.statuses(i).has_position_raw()) fprintf(StdLogger::DBG,"!!!! no current position");
                continue;
            }
            program.triggerCtrl.checkMove(program.speedCtrl.direction(newStatus.statuses(i).velocity()),
                                          program.speedCtrl.direction(newStatus.statuses(i).target_velocity()),
                                          newStatus.statuses(i).position_raw()
                                          );
        }

        if(doughReelerIsActived && SystemConfig::typ!=SystemConfig::ECOSTAR){
            long reelerDelayTime = long(std::chrono::duration_cast<std::chrono::milliseconds>(now-doughReelerIsActivedTime).count());
            if(reelerDelayTime > 3500){
                machine.stop_autohaspel();
                doughReelerIsActived = false;
                logMoves.fmt("--3.5 s of hapsel timeout, the power of the hapsel will be turn off.");
            }
        }

        if (movements.has_current()) {

            // check laser trigger and find torque
            int torque = 0;
            int t_left=0, t_right=0;
            int idxServo0 = -1;
            for (int i = 0; i < newStatus.statuses_size(); i++) {
                const ServoStatus &s = newStatus.statuses(i);
                if(s.servo_id()==0) {idxServo0 = i; t_left = s.has_torque() ? s.torque() : 0;}
                else if(s.servo_id()==1) torque = s.has_torque() ? s.torque() : 0;
                else if(s.servo_id()==2) {t_right = s.has_torque() ? s.torque() : 0;}
                if (s.servo_id() == GPIO_IDX && s.has_digital_in()) {
                    const DigitalInputs &in = s.digital_in();
                    if (in.has_mon5()) {
                        bool trigState = in.mon5();
                        if(!lastHWLaserTrigger && trigState) {
                            lastHWLaserTrigger = true;
                            log_trigger_status(LOG_HW_TRIGGER_ON, 0, machine.current_drum_rawposition());
                            fprintf(StdLogger::TRACE, "HW laser trigger changed to ON at pos D:%u L:%u R:%u", machine.current_drum_rawposition(), machine.current_leftbelt_rawposition(), machine.current_rightbelt_rawposition());
                        } else if(lastHWLaserTrigger && !trigState) {
                            lastHWLaserTrigger = false;
                            log_trigger_status(LOG_HW_TRIGGER_OFF, 0, machine.current_drum_rawposition());
                            fprintf(StdLogger::TRACE, "HW laser trigger changed to OFF at pos D:%u L:%u R:%u", machine.current_drum_rawposition(), machine.current_leftbelt_rawposition(), machine.current_rightbelt_rawposition());
                        }
                        //bool triggerValid;
                        static TRACED_VAR(triggerValid,bool,false);
                        if(SystemConfig::typ==SystemConfig::ECOSTAR){
                            triggerValid = true;//program.triggerCtrl.isValid(machine.current_drum_rawposition(), program.speedCtrl.direction(s.velocity()));
                            laser_trigger_p = triggerValid ? trigState : false;
                        }else{
                            triggerValid = program.triggerCtrl.isValid(machine.current_drum_rawposition(), program.speedCtrl.direction(s.velocity()));
                            laser_trigger_p = triggerValid ? trigState : preSheetLastLaserStatus;
                        }
                    }
                } else if(s.servo_id() == 2) {
                    // second laser trigger
                    const DigitalInputs &in = s.digital_in();
                    if (in.has_mon3() && in.has_mon2() && movements.current().has_velocity()) {
                        int dir = program.speedCtrl.direction(movements.current().velocity());
                        if(dir==0 && program.triggerCtrl.trigger2Active()) dir = program.triggerCtrl.trigger2Dir();
                        bool trigState = dir<0 ? in.mon3() : in.mon2();
                        int needIdx = -1;
                        if(SystemConfig::drum_mode) {
                            for (int j = 0; j < newStatus.statuses_size(); j++) {
                                if(newStatus.statuses(j).has_servo_id() && newStatus.statuses(j).has_position_raw()) {
                                    if(newStatus.statuses(j).servo_id()==1) {
                                        needIdx = j;
                                        break;
                                    }
                                }
                            }
                        } else {
                            if(dir>=0) needIdx = i;
                            else if(idxServo0>=0) needIdx = idxServo0;
                            else {
                                for (int j = 0; j < newStatus.statuses_size(); j++) {
                                    if(newStatus.statuses(j).has_servo_id() && newStatus.statuses(j).has_position_raw()) {
                                        if(newStatus.statuses(j).servo_id()==0) {
                                            needIdx = j;
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                        if(needIdx>=0) {
                            if(program.triggerCtrl.setTrigger2State(trigState, uint32_t(newStatus.statuses(needIdx).position_raw()), dir, needIdx)) {
                                // dough passed second trigger
                                uint32_t t2len = program.distance(program.triggerCtrl.trigger2Pos(true), program.triggerCtrl.trigger2Pos(false), dir);
                                double l2mm=0.0, t2mm = SystemConfig::ticks2mm_belt / SystemConfig::runmode_factor;
                                if(t2mm>0.0) {
                                    l2mm = 1.0 * t2len / t2mm;
                                    movementInfo.set_current_length2(l2mm);
                                    fprintf(StdLogger::DBG, "... from trigger2: length = %u ticks => %.1lf cm", t2len, l2mm/10.0);
                                }
                            }
                        }
                    }
                }
            }

            stats.add(t_left, t_right);

            if(std::abs(torque-last_torque)>0) {
                last_torque = torque;
                //fprintf(StdLogger::DBG,"torque changed to %d",torque);
            }

            // calculate current width/length
            bindata.trigger_filtered = laser_trigger_p;
            check_dough_length(laser_trigger_p, torque);
            bindata.trigger_sw = preSheetLastLaserStatus?1:0;

            // when safety cage is open, motors will be in standby
            // which is why this has to happen first

            bool stop_requested = machine.is_stop_button_pressed()
                    || needPauseForAIPopupConfirmation
                    || sw_stop_request != sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;

            if (safety_cage_open_p or stop_requested /*or wctrl_reached*/) {
                if (not stepPaused) {
                    if(safety_cage_open_p) logMoves.fmt("step pause due to cage_open\n");
                    if(stop_requested) {
                        if(sw_stop_request == sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE) {
                            pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_USER;
                            logMoves.fmt("step pause due to stop_button\n");
                            if(SystemConfig::typ==SystemConfig::ECOSTAR){
                                machine.clear_ecostar_autohaspel_output();
                                logMoves.fmt("clear the ecostar autohapsel output due to pause of press stop_button\n");
                            }
                        } else {
                            pauseReason = sw_stop_request;
                            sw_stop_request = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
                            logMoves.fmt("step pause due to SW stop\n");
                        }
                    }
                    stepPaused = true;
                    last_pause_begin = now;

                    // DAREK: disable flourduster for actual move if pausing
                    flourduster_delayed = false;
                    if (movements.current().has_flourduster() && movements.current().flourduster()) {
                        dusterAfterPause = true;
                        flourduster_delayed = false;
                        movements.mutable_current()->set_flourduster(false);
                    }else{
                        dusterAfterPause = false;
                    }
                    machine.stop_all_servos();
                    return;
                }
            }
        }

        bool some_servo_running = false;
        int drum_speed_r = 0;
        ServoStatus::State gapmotorstate = ServoStatus::State::ServoStatus_State_UNKNOWN_STATE;
        // Don't do anything while some servos are still in error or standby state
        for (int i = 0; i < newStatus.statuses_size(); i++) {
            const auto& r = newStatus.statuses(i);
            unsigned int srvid = r.has_servo_id() ? r.servo_id() : 9;
            ServoStatus::State tmp_state = r.has_state() ? r.state() : ServoStatus::State::ServoStatus_State_UNKNOWN_STATE;
            if((srvid==3 && SystemConfig::typ!=SystemConfig::ECOSTAR) ||
                    (srvid==1 && SystemConfig::typ==SystemConfig::ECOSTAR)) gapmotorstate = tmp_state;
            if (tmp_state == ServoStatus::State::ServoStatus_State_STANDBY){
                if(SystemConfig::typ!=SystemConfig::ECOSTAR && srvid!=3) {
                    return;
                }
            }
            if (r.has_error() && r.error() != r.NO_ERROR) {
                return;
            }
            if(r.has_servo_id() && r.has_velocity()) {
                uint32_t sid = r.servo_id();
                int v = r.velocity();
                if(v!=0 && sid!=3) {
                    some_servo_running = true;
                    if(sid==1) drum_speed_r = v;
                }
            }
        }

        bool isPizzaProgram = program.stepArt()==::sheeter2020::MovementRequest::PIZZA;
        if(!isPizzaProgram)
            pizzaProgramStartDirection = 0;

        if (movements.has_current())
        {
            const Movement &cur = movements.current();
            assert(cur.has_type());

            // HANDLE RESTART AFTER PAUSE

            if (stepPaused) {
                if (safety_cage_open_p){
                    restarGapStep = GAP_STEP_UNUSED; // reset the restart gap status
                    return;
                }

                bool hw_left_right = machine.is_left_button_pressed() || machine.is_right_button_pressed();

                bool restart_transport = false;
                if(pauseReason == sheeter2020::MovementInfoStatus_PauseReason_PAUSE_TRANSPORT) {
                    hw_left_right = false;
                    sw_left_right = false;
                    if(transport_bit) {
                        bool ext_ok = true;
                        double ext_speed = 0.0;
                        if(SystemConfig::transport_mode==SystemConfig::TransportMode::FBT) {
                            ext_speed = SystemConfig::transp_a * transport_val + SystemConfig::transp_c;
                            if(ext_speed<0.1 || ext_speed<(SystemConfig::transp_c+0.1) || SystemConfig::ticks2mm_belt<1.0) ext_ok = false;
                        }
                        if(ext_ok) restart_transport = true;
                    }
                }

                if (hw_left_right or sw_left_right or restart_transport or (restarGapStep != GAP_STEP_UNUSED) ) {
                    if(!gapsize_reached()){
                        if(restarGapStep != GAP_STEP_RESTART){
                            start_gapsize();
                            restarGapStep = GAP_STEP_RESTART;
                            logMoves.fmt("Restart after pause, gap not reached, set gap first\n");
                            return;
                        }else{
                            return;  //wait until gap reached
                        }

                    }else{
                        restarGapStep = GAP_STEP_UNUSED;
                    }

                    needPauseForAIPopupConfirmation = false;

                    pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
                    stepPaused = false;
                    sw_left_right = false;
                    program.widthCtrl.setReached(false);
                    logMoves.fmt("restart after pause\n");
                    if(movements.current().has_flourduster() && dusterAfterPause){
                        machine.change_duster(true);
                        movements.mutable_current()->set_flourduster(true); //restart duster
                        dusterAfterPause = false;
                        flourduster_delayed = false;
                        logMoves.fmt("Enable flour duster\n");

                    }
                    pause_time_s += std::chrono::duration_cast<std::chrono::seconds>(now - last_pause_begin).count();
                    pause_time_ecostar_s = pause_time_s; // for ecostar reeler step
                    if (movements.has_current()) switch (cur.type()) {
                    case Movement::COMPASS_REDUCTION_CONTINUOUS:
                        if(isPizzaProgram){

                            if(setPizzaGapStep == PGAP_STEP_FINISH){ // the paus happened before the reached of the last step
                                gapReadyCnt = 3;
                                return;
                            }

                            if ((machine.is_left_button_pressed() && pizzaProgramStartDirection == 1) ||
                                    (machine.is_right_button_pressed() && pizzaProgramStartDirection == -1)) {
                                // continue in this step
                                start_belts();
                                logMoves.fmt("Pizza program restarted, continue button is clicked \n");
                            } else if ((machine.is_left_button_pressed() && pizzaProgramStartDirection == -1) ||
                                       (machine.is_right_button_pressed() && pizzaProgramStartDirection == 1)) {
                                // continue in this step
                                if(movements.planned_size()> 0){
                                    clear_current_movements("pizza program, go to the next planned step");
                                    setPizzaGapStep = PGAP_STEP_NEW;
                                    machine.turn_all_servos_on();
                                    gapReadyCnt = 3;
                                }else if(movements.planned_size() == 0){
                                    setPizzaGapStep = PGAP_STEP_UNUSED;
                                    gapReadyCnt = 0;
                                    start_belts();
                                }

                                logMoves.fmt("pizza program, go to the next planned step \n");
                            }

                        }else{
                            if (cur.velocity() > 0.0) {
                                // movement to the right
                                if (machine.is_left_button_pressed()) {
                                    // continue in this step
                                    start_belts();
                                } else {
                                    clear_current_movements("cont/time to right");
                                }
                            } else {
                                // movement to the left
                                if (machine.is_right_button_pressed()) {
                                    // continue in this step
                                    start_belts();
                                } else {
                                    clear_current_movements("cont/time to left");
                                }
                            }

                        }
                        break;
                    case Movement::COMPASS_REDUCTION_TIMER:
                        // the exact button we press decides on whether to continue or stop
                        if (cur.velocity() > 0.0) {
                            // movement to the right
                            if (machine.is_left_button_pressed()) {
                                // continue in this step
                                start_belts();
                            } else {
                                clear_current_movements("cont/time to right");
                            }
                        } else {
                            // movement to the left
                            if (machine.is_right_button_pressed()) {
                                // continue in this step
                                start_belts();
                            } else {
                                clear_current_movements("cont/time to left");
                            }
                        }
                        break;
                    case Movement::COMPASS_REDUCTION_TRIGGER:
                        if (doughWentThroughAlready) {
                            // the dough already passed the laser trigger
                            // afterwards, someone pressed the stop button for pause
                            // now that the user pressed continue, we can continue with the following step
                            clear_current_movements("dough went through");
                        } else {
                            // the dough didn't yet go through, continue as before
                            logMoves.fmt("****** start belts, submode=%d",int(autoreelMidstep));
                            start_belts();
                        }
                        break;
                    case Movement::COMPASS_FINAL_TRANSPORT:
                        // re-start the transport belt if possible
                        start_transport_belt();
                        break;
                    case Movement::COMPASS_FINAL_MANUALREEL:
                        // re-start the manual reel belt
                        if(autoreelMidstep==AR_STEP_WHILE_SLOW_MOVE) {
                            autohaspel_starttime_slow += (now - last_pause_begin);
                        }
                        logMoves.fmt("****** start endhaspel belt (manual), submode=%d",int(autoreelMidstep));
                        start_endhaspel_belt(true);
                        break;
                    case Movement::COMPASS_FINAL_CUTOMAT:
                        // re-start the cutomat belt
                        logMoves.fmt("****** start belts (cutomat), submode=%d",int(autoreelMidstep));
                        start_cutomat_belt();
                        break;
                    case Movement::COMPASS_FINAL_AUTOREEL:
                        // re-start the autoreel belt
                        if(autoreelMidstep==AR_STEP_SLOW_MOVE) {
                            autohaspel_starttime_slow += (now - last_pause_begin);
                        }
                        logMoves.fmt("****** start endhaspel belt (auto), submode=%d",int(autoreelMidstep));
                        if(SystemConfig::typ==SystemConfig::ECOSTAR){
                            close_haspel(); //make sure to hapsel is closed after restart
                            logMoves.fmt("****** For Ecostar, close the hapsel after restart ********************");
                        }
                        start_endhaspel_belt(false);
                        break;
                    }
                } else{
                    return;
                }
                // OK - restarted
            }

            if(isPizzaProgram && setPizzaGapStep == PGAP_STEP_FINISH){
                gapReadyCnt--;
                if(gapReadyCnt < 0){
                    start_gapsize();
                    setPizzaGapStep = PGAP_STEP_UNUSED;
                }
            }

            if (movements.has_current()) switch (cur.type())
            {
            case Movement::COMPASS_FINAL_UNUSED:
            case Movement::STOP:
                // unhandled
                break;
            case Movement::COMPASS_REDUCTION_CONTINUOUS:
                // we are currently in the progress of running with constant velocity
                // this never automatically ends
                // it only ends when someone presses the STOP button
                // if the motor stopped moving for an external reason (emergency off)
                // we also want to stop
                // or if there is an error
                if (gapSizeStatusReached == false and not gapsize_reached()) {
                    // still waiting for the gap to finish moving
                } else if ((now - timestamp_step_begin) > std::chrono::seconds(60*5 + pause_time_s)) {
                    // 5-minutes timeout if nothing happens
                    machine.stop_all_servos();
                    clear_current_movements("5 minutes passed");
                    movements.clear_planned();
                } else if (gapSizeStatusReached == false) {
                    // gave gaps enough time to move; now start belts
                    gapSizeStatusReached = true;
                    last_gapsize_reached = now;
                    start_belts();
                }
                break;
            case Movement::COMPASS_REDUCTION_TRIGGER:
                if ((waitForGapReached) && ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia()))) {
                    // still waiting for the gap to finish moving
                    if(waitForGapReached && SystemConfig::typ==SystemConfig::ECOSTAR){
                        machine.stop_all_servos();
                    }
                } else if (gapSizeStatusReached == false) {
                    // gave gaps enough time to move; now start belts
                    gapSizeStatusReached = true;
                    last_gapsize_reached = now;
                    // during gap movement, laser trigger may flicker
                    // have to reset before actually using the value
                    if(lastLaserStatus) printf("****** dough not detected (1)");
                    lastLaserStatus = false;
                    start_belts();
                } else {
                    assert( movements.current().has_velocity() );
                    // velocity in mm/s
                    const int32_t cur_velo = movements.current().velocity();
                    const double cur_velo_rel = std::fabs(static_cast<double>(cur_velo)) / 1500.0;

                    /*int time_to_gapsize_reached_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                        last_gapsize_reached - timestamp_step_begin).count();*/
                    if(laser_trigger_p && !lastLaserStatus){
                        // dough detector rising edge
                        //int time_until_first_trigger_ms = static_cast<int>(time_to_gapsize_reached_ms + (200.0 / cur_velo_rel)) + 1000 * pause_time_s;
                        // wait a little more time after belts started moving before actually using it
                        //if ( (now - timestamp_step_begin) > std::chrono::milliseconds(time_until_first_trigger_ms) ) {
                        printf("****** dough detected (2)");
                        lastLaserStatus = true;
                        doughWentThroughAlready = false;
                        lasertrigger_rising_edge = now;
                        //}
                    } else if(lastLaserStatus && !laser_trigger_p){
                        // dough detector falling edge
                        //int minimal_trigger_duration_ms = static_cast<int>(100.0 / cur_velo_rel);
                        //auto time_since_rising = now - lasertrigger_rising_edge;
                        // only accept a falling edge after minimum duration
                        //if (time_since_rising > std::chrono::milliseconds(minimal_trigger_duration_ms)) {
                        printf("****** dough not detected (3)");
                        lastLaserStatus = false;
                        lasertrigger_falling_edge = now;
                        doughWentThroughAlready = true;
                        pause_time_s = 0;
                        pause_time_ecostar_s = 0;
                        //}
                    } else if (doughWentThroughAlready) {
                        // as the acceleration is fixed-duration, higher velocities mean faster acceleration which means more
                        // position change for stop. we compensate that with this:
                        /*int acceleration_compensation_ms = static_cast<int>(2000.0 * cur_velo_rel);
                        int after_roll_duration_ms = static_cast<int>(100.0 / cur_velo_rel) + (1000 * pause_time_s) - acceleration_compensation_ms;
                        after_roll_duration_ms = std::max(after_roll_duration_ms, 0);
                        Ignored for now, zero delay for max speed */

                        double ps_t2mm = SystemConfig::ticks2mm_belt / SystemConfig::runmode_factor;
                        double need_length = program.widthCtrl.width(); // mm
                        double need_gap_size = program.widthCtrl.gapsize(); // mm
                        bool via_gapsize = need_gap_size>=0.2;
                        double now_length = ps_t2mm> 0.001 ? (1.0 * program.widthCtrl.currentRawLength() / ps_t2mm + SystemConfig::length_correction_constant) : 0.0; // mm
                        bool len_reached = via_gapsize ? program.currentGapsize()<=need_gap_size : (need_length>20.0 && now_length>=(need_length-20.0));
                        // dirToBe = ???
                        bool side_ok = program.speedCtrl.direction(movements.current().velocity()) == -program.speedCtrl.startDirection();
                        if(SystemConfig::rotate_side>0) {
                            side_ok = program.speedCtrl.direction(movements.current().velocity()) > 0;
                        } else if(SystemConfig::rotate_side<0) {
                            side_ok = program.speedCtrl.direction(movements.current().velocity()) < 0;
                        }
                        bool wasExtraMove = program.widthCtrl.isExtraMove();
                        bool stop_on_length_reached = wasExtraMove || (len_reached && side_ok);
                        bool need_stop = program.widthCtrl.shouldStop();

                        //uint32_t pos_now = machine.current_drum_rawposition();
                        //uint32_t pos_dough_end = program.widthCtrl.start_rawposition(0);
                        uint32_t pos_now = movements.current().velocity()<0 ? machine.current_leftbelt_rawposition() : machine.current_rightbelt_rawposition();
                        uint32_t pos_dough_end = program.widthCtrl.start_rawposition(movements.current().velocity()<0?-1:1);
                        uint32_t distance_raw = program.distance(pos_dough_end, pos_now, program.speedCtrl.direction(cur.velocity()));
                        bool touring = program.stepArt()==::sheeter2020::MovementRequest::TOUR3 ||
                                program.stepArt()==::sheeter2020::MovementRequest::TOUR4 ||
                                program.stepArt()==::sheeter2020::MovementRequest::FAT ||
                                program.stepArt()==::sheeter2020::MovementRequest::PREROLL ||
                                program.stepArt()==::sheeter2020::MovementRequest::ENDROLL;
                        double distance_mm = ps_t2mm> 0.001 ? (1.0 * distance_raw / ps_t2mm) : 0.0;
                        double dummy_speed = 0.0;
                        bool after_tt_us = SystemConfig::transport_mode==SystemConfig::TT_US && program.is_us_valid(dummy_speed);
                        bool short_move_change = stop_on_length_reached ? false : ((movements.planned_size()>0 || !touring) && !after_tt_us ? true : false);
                        double distance_need_mm = stop_on_length_reached ?
                                    SystemConfig::stop_pos_long
                                  :
                                    ((movements.planned_size()>0 || !touring) && !after_tt_us ? SystemConfig::stop_pos_short : SystemConfig::stop_pos_fold);
                        const char* stop_art_txt = stop_on_length_reached ?
                                    "rotate"
                                  :
                                    (movements.planned_size()>0 || !touring ? "revert" : "fold");
                        double v_prc = 0.0;
                        double distance_extra_mm = 0.0;
                        double outfeed_val = cur.has_extractionbelt_speed_factor() ? cur.extractionbelt_speed_factor() : 0.0;
                        if(outfeed_val<=0.0) outfeed_val = 88.0;
                        if(cur.has_velocity() && !short_move_change) {
                            v_prc = std::abs(cur.velocity()*outfeed_val)/(SystemConfig::speed100*0.88); //1500.0;
                            if(v_prc>101.0) v_prc = 101.0;
                            if(v_prc<0.1) v_prc = 0.1;
                            distance_extra_mm = (100.0-v_prc) * SystemConfig::stop_pos_correction / 50.0;
                            if(v_prc>=0.09 && SystemConfig::stop_pos_correction>=0) distance_need_mm += distance_extra_mm;
                        }

                        if(SystemConfig::typ==SystemConfig::ECOSTAR){
                            long stepTime = long(std::chrono::duration_cast<std::chrono::milliseconds>(now-lasertrigger_falling_edge).count());
                            double leftFactor = speedEcoStarMMPerMsSpeedFactorLeft;
                            double rightFactor = speedEcoStarMMPerMsSpeedFactorRight;
                            if(stop_on_length_reached){
                                leftFactor = speedEcoStarMMPerMsSpeedFactorFarLeft;
                                rightFactor = speedEcoStarMMPerMsSpeedFactorFarRight;
                            }else{
                                if(movements.planned_size()>0 || !touring){
                                    if(distance_need_mm < 450){
                                        leftFactor = speedEcoStarMMPerMsSpeedFactorLeft * 6;
                                        rightFactor = speedEcoStarMMPerMsSpeedFactorRight * 6;
                                    }else if(distance_need_mm < 820){
                                        leftFactor = speedEcoStarMMPerMsSpeedFactorLeft;
                                        rightFactor = speedEcoStarMMPerMsSpeedFactorRight;
                                    }else{
                                        leftFactor = speedEcoStarMMPerMsSpeedFactorBoth;
                                        rightFactor = speedEcoStarMMPerMsSpeedFactorBoth;
                                    }

                                }else{
                                    if(distance_need_mm < 450){
                                        leftFactor = speedEcoStarMMPerMsSpeedFactorFarLeft * 6;
                                        rightFactor = speedEcoStarMMPerMsSpeedFactorFarRight * 6;
                                    }else{
                                        leftFactor = speedEcoStarMMPerMsSpeedFactorFarLeft;
                                        rightFactor = speedEcoStarMMPerMsSpeedFactorFarRight;
                                    }

                                }
                            }
                            if(cur_velo > 0){
                                distance_mm = SystemConfig::ecostar_speed_left * 0.75 * leftFactor * stepTime; //Dough left side
                            }else{
                                distance_mm = SystemConfig::ecostar_speed_right * 0.75 * rightFactor * stepTime;  //Dough right side
                            }
                        }

                        int after_roll_duration_ms =  static_cast<int>(100.0 / cur_velo_rel) + (1000 * pause_time_s) - 100.0;
                        if(stop_on_length_reached) after_roll_duration_ms = 3LL * after_roll_duration_ms / 2LL;
                        after_roll_duration_ms = std::max(after_roll_duration_ms, 0);

                        if(distance_mm >= distance_need_mm) {
                            if(stop_on_length_reached) {
                                if(need_stop) {
                                    // finally finished this move and step
                                    clear_current_movements("final stop after dough passed, stop the whole step /DBG/");
                                    machine.stop_all_servos();
                                    // stop
                                    fprintf(StdLogger::DBG, "====================== stop current step after %.1lf of %.1lf mm (clear planned) /DBG/", distance_mm, distance_need_mm);
                                    program.widthCtrl.clear();
                                    if(movements.planned_size()>0) movements.clear_planned();
                                } else {
                                    // finish this move and make pause
                                    machine.stop_all_servos();
                                    fprintf(StdLogger::DBG, "====================== pause current step after %.1lf of %.1lf mm (pos: %u..%u, for %s) /DBG/", distance_mm, distance_need_mm, pos_dough_end, pos_now, stop_art_txt);
                                    program.widthCtrl.clear();
                                    program.setAfterWidthCtrl(true);
                                    pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_ROTATE;
                                    stepPaused = true;
                                    last_pause_begin = now;
                                }
                                program.widthCtrl.setReached(true);
                            } else if(len_reached && !side_ok) {
                                // finished this move and add extra move for the right side
                                double need_gapsize = program.currentGapsize();
                                clear_current_movements("final stop after dough passed, and extra move /DBG/");
                                machine.stop_all_servos();
                                // extra move to other side
                                fprintf(StdLogger::DBG, "====================== one more move in current step /DBG/");
                                program.widthCtrl.setExtraMove();
                                if(need_gapsize<0.2) need_gapsize = 0.2;
                                program.setNextGapsize(program.gapIncreased(need_gapsize));
                            } else {
                                // finally finished this move or recalculate new gapsize
                                if(need_length>0.0 && movements.planned_size()>0) {
                                    double curr_gap = program.currentGapsize();
                                    double vol2d = now_length * curr_gap;
                                    double nextGapSize = std::round(vol2d / need_length * SystemConfig::volume_factor) / 100.0;
                                    double nextGapReal = movements.planned(0).gapsize();
                                    if(nextGapReal <= nextGapSize) { // && now_length < need_length) {
                                        double nextGapReal2 = movements.planned_size()>1 && movements.planned(1).has_gapsize() ? movements.planned(1).gapsize() : 0.0;
                                        if(nextGapReal2>0.0 && nextGapSize<nextGapReal2) {
                                            nextGapSize = nextGapReal2;
                                        }
                                        printf("====================== next gapsize for length = %.2lf cm (vol %.2lf) must be %.2lf but is %.2lf (ticks/mm=%.2lf) ... forced /DBG/", need_length/10.0, vol2d, nextGapSize, nextGapReal, ps_t2mm);
                                        program.setNextGapsize(nextGapSize);
                                    } else {
                                        printf("====================== next gapsize for length = %.2lf cm (vol %.2lf x %.2lf = %.2lf) must be %.2lf / %.2lf = %.2lf but is %.2lf (ticks/mm=%.2lf) ... ignored /DBG/",
                                               need_length/10.0,
                                               now_length, curr_gap, vol2d,
                                               vol2d, need_length, nextGapSize,
                                               nextGapReal, ps_t2mm
                                               );
                                    }
                                }
                                clear_current_movements("final stop after dough passed, revert move or stop /DBG/");
                                machine.stop_all_servos();
                                fprintf(StdLogger::DBG, "====================== continue current step%s, l=%.1lf cm (waiting for %.1lf cm, side:%s, distance:%.1lf/%.1lf, pos: %u..%u, for %s, proc=%.1lf, extra=%.1lf) /DBG/", wasExtraMove?" after extra move":"", now_length/10.0, need_length/10.0, side_ok ? "ok":"wrong", distance_mm, distance_need_mm, pos_dough_end, pos_now, stop_art_txt, v_prc, distance_extra_mm);
                            }
                        }
                    } else if ((now - timestamp_step_begin) > std::chrono::seconds(60+pause_time_s)) {
                        if (!lastLaserStatus) {
                            // timeout for dough detection
                            // after 60 seconds, still no rising edge, stop ALL movements
                            movements.clear_planned();
                            clear_current_movements("final stop - dough not passed - timeout 60 secs");
                            machine.stop_all_servos();
                        }
                    }
                }
                break;
            case Movement::COMPASS_REDUCTION_TIMER:
                assert(cur.has_duration());

                if ((!gapSizeStatusReached && !gapsize_reached()) || (inertia && program.triggerCtrl.isCheckInertia())) {
                    // still waiting for the gap to finish moving

                } else if (gapSizeStatusReached == false) {
                    // gave gaps enough time to move; now start belts
                    gapSizeStatusReached = true;
                    last_gapsize_reached = now;
                    if(move_to_center) start_to_center();
                    else if(is_in_longtime_test && longtime_test_with_reeler && SystemConfig::autoreel_exists && SystemConfig::autoreel_at_right_side) {
                        if(cur.gapsize()<=0.32 && cur.velocity()>0.01 && !doughReelerIsClosing) {
                            stressReelerTime = now;
                            doughReelerIsOpening = false;
                            stressReelerStep = 1;
                            double sec = cur.duration();
                            movements.mutable_current()->set_duration(sec+3);
                            if(movements.planned_size()>0) movements.mutable_planned(0)->set_duration(sec+3);
                            close_haspel();
                            fprintf(StdLogger::TRACE,"# # # # reeler closing");
                        } else if(stressReelerStep==2) {
                            stressReelerTime = now;
                            doughReelerIsClosing = false;
                            stressReelerStep = 3;
                            open_haspel();
                            fprintf(StdLogger::TRACE,"# # # # reeler opening");
                        } else {
                            start_belts();
                            fprintf(StdLogger::TRACE,"# # # # moving");
                        }
                    }
                    else {
                        start_belts();
                    }

                } else if(!move_to_center) {

                    if(is_in_longtime_test) {
                        if(doughReelerIsClosing) {
                            timestamp_step_begin = now;
                            if(now - stressReelerTime >= std::chrono::seconds(2)) {
                                doughReelerIsClosing = false;
                                stressReelerStep = 2;
                                start_belts();
                                fprintf(StdLogger::TRACE,"# # # # reeler closed - moving");
                            }
                            break;
                        } else if(doughReelerIsOpening) {
                            timestamp_step_begin = now;
                            if(now - stressReelerTime >= std::chrono::seconds(2)) {
                                doughReelerIsOpening = false;
                                doughReelerIsClosing = false;
                                stressReelerStep = 0;
                                start_belts();
                                fprintf(StdLogger::TRACE,"# # # # reeler opened - moving");
                            }
                            break;
                        }
                    }

                    int time_to_gapsize_reached_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                                last_gapsize_reached - timestamp_step_begin).count();
                    int duration_ms = static_cast<int>(cur.duration() * 1000) + time_to_gapsize_reached_ms;
                    if ((now - timestamp_step_begin) > std::chrono::milliseconds(duration_ms))
                    {
                        clear_current_movements("after timeout");
                        machine.stop_all_servos();
                        if(is_in_longtime_test) fprintf(StdLogger::TRACE,"# # # # move timed out - stopped");
                    }
                }
                break;
            case Movement::COMPASS_FINAL_TRANSPORT:
                handle_transport(bindata, laser_trigger_p, inertia, cur, now);
                break;
            case Movement::COMPASS_FINAL_CUTOMAT:
                handle_cutomat(bindata, laser_trigger_p, inertia, cur, now);
                break;
            case Movement::COMPASS_FINAL_MANUALREEL:
                handle_manual_reeler(bindata, laser_trigger_p, inertia, cur, now);
                break;
            case Movement::COMPASS_FINAL_AUTOREEL:
                handle_auto_reeler(bindata, laser_trigger_p, inertia, cur, now);
                break;
            }
        } else {

            if(gapmotorstate!=ServoStatus::State::ServoStatus_State_RUNNING) {
                // wait until gap motor is ready
                return;
            }


            doughWentThroughAlready = false;
            if(stepPaused) {
                if(!left_button_p && !right_button_p && movements.planned_size()>0) {
                    return;
                }
                if(safety_cage_open_p) {
                    return;
                }
                printf("pause reset - restart if possible\n");
                pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
                stepPaused = false;
                pause_time_s = 0;
                pause_time_ecostar_s = 0;
            }

            int planned_count = movements.planned_size();
            if(planned_count==0 && some_servo_running) {
                bool stop_button_p = machine_interface_t::is_stop_button_pressed(newStatus) || needPauseForAIPopupConfirmation;
                if(stop_button_p) {
                    machine.stop_all_servos();
                    rotate_for_cleaning_step = 0; // inactive
                } else if(rotate_for_cleaning_step==1) {
                    // requested
                    rotate_for_cleaning_startpos = machine.current_drum_rawposition();
                    rotate_for_cleaning_step = 2; // busy
                    printf("drum start position for cleaning is %u, now awating move of %u ticks ... busy\n", rotate_for_cleaning_startpos, rotate_for_cleaning_ticks);
                } else if(rotate_for_cleaning_step==2) {
                    int64_t diff = 0;
                    int64_t rotate_for_cleaning_endpos = machine.current_drum_rawposition();
                    if(drum_speed_r>0) {
                        if(rotate_for_cleaning_startpos>rotate_for_cleaning_endpos)
                            diff = 0x100000000ll + rotate_for_cleaning_endpos - rotate_for_cleaning_startpos;
                        else
                            diff = rotate_for_cleaning_endpos - rotate_for_cleaning_startpos;
                    } else {
                        if(rotate_for_cleaning_startpos<rotate_for_cleaning_endpos)
                            diff = 0x100000000ll + rotate_for_cleaning_startpos - rotate_for_cleaning_endpos;
                        else
                            diff = rotate_for_cleaning_startpos - rotate_for_cleaning_endpos;
                    }
                    if(diff>=rotate_for_cleaning_ticks) {
                        rotate_for_cleaning_step = 0; // inactive
                        printf("drum start/end position for cleaning is %u/%lld, passed %lld ticks, was waiting for %u ... now stop\n", rotate_for_cleaning_startpos, rotate_for_cleaning_endpos, diff, rotate_for_cleaning_ticks);
                        machine.stop_all_servos();
                    }
                }
            }

            if (left_button_p or right_button_p) {
                waitForStartButtonPressed = false;
            }
            // currently, no movement is in progress
            // check whether movements are planned
            if ((planned_count > 0) and not waitForStartButtonPressed) {

                if (safety_cage_open_p) {
                    waitForStartButtonPressed = true;
                    return;
                }

                int dmppos;
                std::string dmpstr;
                /*dmpstr = movements.DebugString();
                while((dmppos=dmpstr.find("\n"))>=0) dmpstr.replace(dmppos,1,"\\n");
                printf("Now movements is %s\n", dmpstr.c_str());*/

                Movement *newCur = nullptr;

                bool noWidthCtrl = program.widthCtrl.gapsize()>0.0 ? false : (program.widthCtrl.width()<=0.0);
                int dirToBe = 0;
                int idxOffset = 0;
                if(noWidthCtrl && movements.planned_size()>1) {
                    idxOffset = movements.planned_size()-1;
                }
                sheeter2020::Movement::MovementType typ = movements.planned(idxOffset).has_type() ? movements.planned(idxOffset).type() : sheeter2020::Movement_MovementType_COMPASS_REDUCTION_CONTINUOUS;
                switch(typ) {
                case sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL:
                    dirToBe = SystemConfig::autoreel_at_right_side ? 1 : -1;
                    break;
                case sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL:
                    dirToBe = SystemConfig::manualreel_at_right_side ? 1 : -1;
                    break;
                case sheeter2020::Movement_MovementType_COMPASS_FINAL_CUTOMAT:
                    dirToBe = SystemConfig::cutomat_at_right_side ? 1 : -1;
                    break;
                case sheeter2020::Movement_MovementType_COMPASS_FINAL_TRANSPORT:
                    dirToBe = SystemConfig::transport_at_right_side ? 1 : -1;
                    break;
                case sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER:
                    if(movements.planned_size()>0 && !program.widthCtrl.isActive()) {
                        int cnt = movements.planned_size();
                        auto lastmove = movements.planned(cnt-1);
                        if(lastmove.has_type() && lastmove.type()==sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER) {
                            if(!program.afterWidthCtrl() && SystemConfig::rotate_side) {
                                dirToBe = SystemConfig::rotate_side;
                            } else if(SystemConfig::fold_side && (
                                          program.stepArt()==::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_TOUR3 ||
                                          program.stepArt()==::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_TOUR4 ||
                                          program.stepArt()==::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_FAT ||
                                          program.stepArt()==::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_PREROLL ||
                                          program.stepArt()==::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_ENDROLL
                                          )) {
                                dirToBe = SystemConfig::fold_side;
                            } else {
                                dirToBe = -program.speedCtrl.startDirection();
                            }
                        }
                    }
                    break;
                default:
                    break;
                }

                double via_Gapsize = program.widthCtrl.gapsize();
                double nxt_Gapsize = movements.planned_size()>0 && movements.planned(0).has_gapsize() ? movements.planned(0).gapsize() : 0.0;
                if(via_Gapsize>0.0 && via_Gapsize>nxt_Gapsize) {
                    program.setNextGapsize(via_Gapsize);
                }

                if(!is_in_longtime_test) {
                    bool inserted = false;
                    if(program.isNextGapsize()) {
                        // add extra movement for width control
                        double nextGapsize = program.nextGapsize();
                        insert_planned_movement(nextGapsize, "width ctrl", false);
                        inserted = true;
                    } else if(dirToBe) {
                        // add extra movement for correct side
                        double nextGapsize = program.currentGapsize();
                        int dougside = program.doughSide();
                        if(dougside && nextGapsize>0.0 && movements.planned_size()>0) {
                            bool do_add = false;
                            if(movements.planned_size()&1) {
                                // odd movement count
                                if(dougside>0 && dirToBe>0) do_add = true;
                                else if(dougside<0 && dirToBe<0) do_add = true;
                            } else {
                                // even movement count
                                if(dougside>0 && dirToBe<0) do_add = true;
                                else if(dougside<0 && dirToBe>0) do_add = true;
                            }
                            if(do_add) {
                                double gapIncreased = program.gapIncreased(nextGapsize);
                                insert_planned_movement(gapIncreased, "correct side", true);
                                inserted = true;
                            }
                        }
                    }
                }

                // take first planned and make it current
                auto *list = movements.mutable_planned();
                if(move_to_center) {
                    logMoves.add(StdLogger::TRACE,"copy instead of swap due to move to center");
                    newCur = new Movement(list->Get(0));
                } else {
                    list->ExtractSubrange(0, 1, &newCur);
                }
                planned_count--;
                assert(newCur != nullptr);
                assert(newCur->has_type());

                if(newCur->has_gapsize()) {
                    double lastGap = program.currentGapsize();
                    double newGap = newCur->gapsize();
                    if(SystemConfig::dynamic_mode) {
                        double newF;
                        if(lastGap<=0.0) {
                            newF = 58.0/88.0;
                            lastGap = newGap / newF;
                        }
                        if(lastGap>0.0 && newGap>lastGap) {
                            lastGap = newGap;
                        }
                        if(newGap<=0.0 || lastGap<=0.0) newGap = lastGap = 45.0;
                        newF = newGap / lastGap;
                        //machine_interface_t::compas_speed_factors.feeding_belt = int(std::round(newF * machine_interface_t::compas_speed_factors.extraction_belt));
                        fprintf(StdLogger::DBG,"saving current gapsize %.2lf, prev=%.2lf /DBG/", newGap, lastGap);
                    } else {
                        fprintf(StdLogger::DBG,"saving current gapsize %.2lf, prev=%.2lf /DBG/", newGap, lastGap);
                    }
                    program.setCurrentGapsize(newCur->gapsize());
                }

                // correct speed direction
                if(newCur->has_velocity()) {
                    int nextDir = program.speedCtrl.nextDirection();
                    double v = std::fabs(newCur->velocity()) * nextDir;
                    newCur->set_velocity(v);
                    program.speedCtrl.setCurrent(v);
                }

                laserCnt = 0; //for EcoStar
                logMoves.fmt("------------------------------- current move:\n%s",newCur->DebugString().c_str());
                movements.set_allocated_current(newCur);

                // check if need to add an extra move NOT at the end of movements
                if(SystemConfig::rotate_side!=0 && !is_in_longtime_test && program.widthCtrl.isActive() &&
                        program.widthCtrl.gapsize()>0.0 && program.widthCtrl.width()<=0.0 &&
                        newCur->has_type() && newCur->type()==sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER &&
                        newCur->has_gapsize() && newCur->gapsize()>0.0 &&
                        movements.planned_size()>0) {
                    int wctrl_gapsize_offset = -1;
                    double wcgs = program.widthCtrl.gapsize();
                    for(int j=0; j<movements.planned_size(); j++) {
                        sheeter2020::Movement::MovementType movtyp = movements.planned(j).type();
                        if(movtyp!=sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER ||
                                !movements.planned(j).has_gapsize()) break;
                        double mvgs = movements.planned(j).gapsize();
                        if(mvgs<=wcgs) {
                            wctrl_gapsize_offset = j;
                            break;
                        }
                    }
                    if(wctrl_gapsize_offset>0) {
                        int curDir = program.speedCtrl.direction(newCur->velocity());
                        int odd = wctrl_gapsize_offset&1;
                        int rs = SystemConfig::rotate_side;
                        if(rs<0 && ((curDir>0 && odd==1) || (curDir<0 && odd==0))) {
                            fprintf(StdLogger::DBG,"adding extra move at early stage of gapsize %.2lf for rotation", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage for rotation", true);
                        } else if(rs>0 && ((curDir<0 && odd==1) || (curDir>0 && odd==0))) {
                            fprintf(StdLogger::DBG,"adding extra move at early stage of gapsize %.2lf for rotation", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage for rotation", true);
                        }
                    }
                } else if(!is_in_longtime_test && !program.widthCtrl.isActive() &&
                          newCur->has_type() && newCur->type()==sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER &&
                          newCur->has_gapsize() && newCur->gapsize()>0.0 &&
                          movements.planned_size()>0) {
                    sheeter2020::Movement::MovementType endtyp = movements.planned(movements.planned_size()-1).type();
                    if(endtyp==sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL) {
                        int curDir = program.speedCtrl.direction(newCur->velocity());
                        int odd = movements.planned_size()&1;
                        if(SystemConfig::autoreel_at_right_side && ((curDir>0 && odd==1) || (curDir<0 && odd==0))) {
                            fprintf(StdLogger::DBG,"adding extra move at early stage of gapsize %.2lf", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage", true);
                        } else if(!SystemConfig::autoreel_at_right_side && ((curDir<0 && odd==1) || (curDir>0 && odd==0))) {
                            fprintf(StdLogger::DBG,"adding extra move at early stage of gapsize %.2lf", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage", true);
                        }
                    } else if(endtyp==sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL) {
                        int curDir = program.speedCtrl.direction(newCur->velocity());
                        int odd = movements.planned_size()&1;
                        if(SystemConfig::manualreel_at_right_side && ((curDir>0 && odd==1) || (curDir<0 && odd==0))) {
                            logMoves.fmt("adding extra move at early stage of gapsize %.2lf", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage", true);
                        } else if(!SystemConfig::manualreel_at_right_side && ((curDir<0 && odd==1) || (curDir>0 && odd==0))) {
                            logMoves.fmt("adding extra move at early stage of gapsize %.2lf", newCur->gapsize());
                            insert_planned_movement(newCur->gapsize(),"correct side at early stage", true);
                        }
                    }
                }

                dmpstr = movements.DebugString();
                //logMoves.fmt("------------------------------- now all:\n%s",dmpstr.c_str());
                logger.save("movements-curr","%s",dmpstr.c_str());
                while((dmppos=dmpstr.find("\n"))>=0) dmpstr.replace(dmppos,1,"\\n");
                printf("(1)Now movements is %s\n", dmpstr.c_str());

                timestamp_step_begin = now;

                // initialize the movement
                switch (newCur->type())
                {
                case Movement::COMPASS_REDUCTION_CONTINUOUS:
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);
                    assert(newCur->has_gapsize());

                    //cache the pizza program start direction
                    if(isPizzaProgram){
                        if(newCur->velocity() > 0){
                            pizzaProgramStartDirection = 1;
                        }else if(newCur->velocity() < 0){
                            pizzaProgramStartDirection = -1;
                        }
                    }

                    if(setPizzaGapStep == PGAP_STEP_NEW){
                        setPizzaGapStep = PGAP_STEP_FINISH;
                    }else{
                        start_gapsize();
                    }
                    break;
                case Movement::COMPASS_REDUCTION_TIMER:
                    assert(newCur->has_duration());
                    assert(newCur->has_gapsize());
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);

                    start_gapsize();
                    break;
                case Movement::COMPASS_REDUCTION_TRIGGER:
                    assert(newCur->has_gapsize());
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);
                    if(lastLaserStatus) printf("****** dough not detected (4)");
                    lastLaserStatus = false;
                    start_gapsize();
                    break;
                case Movement::COMPASS_FINAL_CUTOMAT:
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);

                    resetPreSheets(bindata, "handle status cutomat");
                    //close_haspel();
                    start_gapsize();
                    lastLaserStatus = false;
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                    break;
                case Movement::COMPASS_FINAL_TRANSPORT:
                    assert(newCur->has_duration());
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);

                    resetPreSheets(bindata, "handle status transport");
                    //close_haspel();
                    start_gapsize();
                    lastLaserStatus = false;
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                    break;
                case Movement::COMPASS_FINAL_MANUALREEL:
                    assert(newCur->has_gapsize());
                    //assert(newCur->has_duration());
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);

                    resetPreSheets(bindata, "handle status manual reeler");
                    //close_haspel();
                    start_gapsize();
                    lastLaserStatus = false;
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                    break;
                case Movement::COMPASS_FINAL_AUTOREEL:
                    assert(newCur->has_gapsize());
                    //assert(newCur->has_duration());
                    assert(newCur->has_velocity());
                    assert(newCur->velocity() != 0.0);

                    resetPreSheets(bindata, "handle status auto reeler");
                    close_haspel();
                    start_gapsize();
                    lastLaserStatus = false;
                    autoreelMidstep = AR_STEP_UNUSED;
                    bindata.midstep = autoreelMidstep;
                    break;
                case Movement::STOP:
                case Movement::COMPASS_FINAL_UNUSED:
                    // stop andfolding steps basically just wait for a press of the left/right button
                    // no movement, no nothing
                    waitForStartButtonPressed = true;
                    clear_current_movements("on stop/single/double");
                    break;
                }
            }
            //            else if(bindata.recording && planned_count==0) {
            //                bindata.recording = 0; // no more movements
            //            }
        }
    }

    void clear_current_movements(const char *txt)
    {
        if(!movements.has_current()) return;
        if(txt) printf("CLEAR CURRENT, info: %s", txt);
        movements.clear_current();
        if(movements.planned_size()>0) program.set_us_speed(0.0);
    }

    void resetPreSheets(tBINLOG &bindata, const char *info = nullptr)
    {
        if(move_to_center) logMoves.add(StdLogger::TRACE,"move to center = OFF");
        move_to_center = false;
        preSheetLastLaserStatus = false;
        bindata.trigger_sw = 0;
        preSheetStartPositionConveyor = 0;
        preSheetStartPositionDrum = 0;
        preSheetStartTime = clock::now();
        //movementInfo.set_current_length(0.0);
        //if(info) fprintf(StdLogger::DBG,"############### %s: preSheetLastLaserStatus = false", info);
        if(info) return; // dummy usage
    }

    void handle_movement_requests(const MovementRequest &moveRequest, tBINLOG &bindata)
    {
        logMoves.fmt("------------------------------ move request:\n%s",moveRequest.DebugString().c_str());
        auto t0 = clock::now();
        assert(moveRequest.has_type());
        bool failed = false;
        bool sent = false;
        MovementResponse rep;
        switch (moveRequest.type())
        {
        case MovementRequest::CANCEL_ALL: {
            //bindata.recording = 0; // cancel all
            flourduster_delayed = false;
            program.set_us_speed(0.0);
            dusterAfterPause = false;
            if(movements.current().has_flourduster()){
                movements.mutable_current()->set_flourduster(false);
            }
            movements.mutable_planned()->Clear();          
            movements.clear_current();
            pauseReason = sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE;
            stepPaused = false;
            machine.change_duster(false);
            needPauseForAIPopupConfirmation = false;
            // send response before stopping servos
            sent = true;
            rep.set_error(MovementResponse::OK);
            int nout = rep.ByteSize();
            char *outbuf = new char[nout];
            rep.SerializeToArray(outbuf,nout);
            nn_send(move_command_s, outbuf, nout, 0);
            delete[] outbuf;

            machine.stop_all_servos();
            program.reset();
            open_haspel();
            laserCnt = headCnt = tailCnt = 0; //clear EcoStar counter
            break; }
        case MovementRequest::CANCEL_ALL_BUT_CURRENT:
            movements.mutable_planned()->Clear();
            program.reset();
            break;
        case MovementRequest::PAUSE_CURRENT:
            needPauseForAIPopupConfirmation = true;
            logMoves.fmt("-------------------recieved pause current.......................... \n...");
            break;
        case MovementRequest::CONTINUE_CURRENT:
            needPauseForAIPopupConfirmation = false;
            logMoves.fmt("-------------------recieved CLEAR  pause current.......................... \n...");
            break;
        case MovementRequest::CLEAR_INFEED_PERCENTAGE:
            machine.set_infeed_percentage(0);
            logMoves.fmt("-------------------recieved CLEAR  the infeed percentage request.......................... \n...");
            break;
        case MovementRequest::REPLACE:
            if(moveRequest.movement_size()==1 && moveRequest.movement(0).has_type()) {
                if(moveRequest.movement(0).type()==Movement::CHANGE_WIDTH_CTRL) {
                    if(moveRequest.movement(0).has_presheet_gapsize()) {
                        bool curr = false;
                        double gs = 0.0;
                        double gsn = moveRequest.movement(0).presheet_gapsize();
                        if(movements.has_current() && movements.current().has_gapsize()) {
                            curr = true;
                            gs = movements.current().gapsize();
                        } else if(movements.planned_size()>0 && movements.planned(0).has_gapsize()) {
                            gs = movements.planned(0).gapsize();
                        }
                        fprintf(StdLogger::DBG,"received change width ctrl to gapsize %.2lf mm, %s is %.2lf mm",
                                gsn, curr ? "current":"planned", gs);
                        program.widthCtrl.correct_gapsize(gsn);
                        program.setAfterWidthCtrl(false);
                        //sw_left_right = true;
                    } else if(moveRequest.movement(0).has_presheet_width()) {
                        double new_wctl = moveRequest.movement(0).presheet_width();
                        if(new_wctl>0) {
                            bool curr = false;
                            double gs = 0.0;
                            if(movements.has_current() && movements.current().has_gapsize()) {
                                curr = true;
                                gs = movements.current().gapsize();
                            } else if(movements.planned_size()>0 && movements.planned(0).has_gapsize()) {
                                gs = movements.planned(0).gapsize();
                            }
                            fprintf(StdLogger::DBG,"received change width ctrl to messure of %.2lf mm, %s gapsize is %.2lf mm",
                                    new_wctl, curr ? "current":"planned", gs);
                            program.widthCtrl.correct_wctrl(new_wctl);
                            if(curr && gs>0.01) {
                                program.setNextGapsize(gs);
                                program.setAfterWidthCtrl(false);
                                //insert_planned_movement(gs,"corrected width ctrl for messure",false);
                            }
                        }
                    } else {
                        fprintf(StdLogger::DBG,"received change width ctrl, but error params");
                        failed = true;
                    }
                    break;
                } else if(moveRequest.movement(0).type()==Movement::CHANGE_FLOUR_DUSTER) {
                    flourduster_delayed = false;
                    if(moveRequest.movement(0).has_gapsize() && moveRequest.movement(0).has_flourduster()) {
                        double gs = std::round(moveRequest.movement(0).gapsize()*100.0)/100.0;
                        bool st = moveRequest.movement(0).flourduster();
                        fprintf(StdLogger::DBG,"received change flour duster %s for gapsize %.2lf", st?"ON":"OFF", gs);
                        if(movements.has_current() && movements.current().has_gapsize() && std::abs(movements.current().gapsize()-gs)<0.001) {
                            // change duster for current move
                            fprintf(StdLogger::DBG,"... changed flour duster %s for current gapsize", st?"ON":"OFF");
                            movements.mutable_current()->set_flourduster(st);
                            if(!stepPaused) machine.change_duster(st);
                        } else {
                            // change duster in planned movements
                            for(int m=0; m<movements.planned_size(); m++) {
                                if(movements.planned(m).has_gapsize() && std::abs(movements.planned(m).gapsize()-gs)<0.001) {
                                    fprintf(StdLogger::DBG,"... changed flour duster %s for gapsize %.2lf", st?"ON":"OFF", gs);
                                    movements.mutable_planned(m)->set_flourduster(st);
                                }
                            }
                        }
                    }else {
                        fprintf(StdLogger::DBG,"received change flour duster, but error params");
                        failed = true;
                    }
                    break;
                }else if(moveRequest.movement(0).type()==Movement::CHANGE_INFEED_SPEED) {
                    int dirServo0;
                    int dirServo2;
                    int32_t velocityServoO;
                    int32_t velocityServo2;
                    int32_t newInfeedSpeedPercent;
                    double new_velo_ticks_s;

                    if (movements.has_current() && moveRequest.movement(0).has_velocity_percentage()) {
                        newInfeedSpeedPercent = moveRequest.movement(0).velocity_percentage();

                        for (int i = 0; i <= 2; i++) {
                            if(i==0){
                                int dir = program.speedCtrl.direction(movements.current().velocity());
                                velocityServoO = movements.current().velocity();
                                dirServo0=dir;
                            } else if(i == 2) {
                                int dir = program.speedCtrl.direction(movements.current().velocity());
                                velocityServo2 = movements.current().velocity();
                                dirServo2=dir;
                            }
                        }
                        if(dirServo0<0 && dirServo2<0){
                            //newInfeedSpeedPercent = -newInfeedSpeedPercent;
                            int32_t newInfeedSpeed = (static_cast<double>(newInfeedSpeedPercent) * 0.001) * static_cast<double>(velocityServo2) +
                                    static_cast<double>(velocityServo2);

                            fprintf(StdLogger::DBG,"received change infeed speed by %d",newInfeedSpeed);

                            new_velo_ticks_s = (static_cast<double>(newInfeedSpeed)) *
                                    100000.0 / 1500.0 * 4778.0;

                            machine.set_infeed_percentage(newInfeedSpeedPercent);

                            if(movements.has_current() && !stepPaused)
                                machine.change_belts_speed(velocityServoO, dynamic_feeding_factor(), dynamic_extraction_factor());

                            printf("CHANGED INFEED SPEED %d mm/s = %.3lf ticks/s for servo motor %d\n", newInfeedSpeed, new_velo_ticks_s, 2);


                        }else if(dirServo0>0 && dirServo2>0){
                            int32_t newInfeedSpeed = (static_cast<double>(newInfeedSpeedPercent) * 0.001) * static_cast<double>(velocityServoO) +
                                    static_cast<double>(velocityServo2);

                            fprintf(StdLogger::DBG,"received change infeed speed by %d",newInfeedSpeed);

                            new_velo_ticks_s = (static_cast<double>(newInfeedSpeed))*
                                    100000.0 / 1500.0 * 4778.0;



                            machine.set_infeed_percentage(newInfeedSpeedPercent);

                            if(movements.has_current() && !stepPaused)
                                machine.change_belts_speed(velocityServoO, dynamic_feeding_factor() , dynamic_extraction_factor());

                            printf("CHANGED INFEED SPEED %d mm/s = %.3lf ticks/s for servo motor %d\n", newInfeedSpeed, new_velo_ticks_s, 0);
                        }

                    }else {
                        fprintf(StdLogger::DBG,"received change infeed speed, but no params");
                        failed = true;
                    }
                    break;
                }
            }

            resetPreSheets(bindata, "handle movement replace");
            program.reset();
            movements.mutable_planned()->Clear();
            movements.mutable_planned()->MergeFrom(moveRequest.movement());
            break;
        case MovementRequest::APPEND: {
            //bindata.recording = 0; // append moves
            bool doReset = false;
            if(!movements.has_current()) {
                resetPreSheets(bindata, "handle movement append");
                program.reset();
                doReset = true;
            }
            int old_planned = movements.planned_size();
            movements.mutable_planned()->MergeFrom(moveRequest.movement());
            if(doReset && movements.planned_size()>0) {
                if(old_planned==0) {
                    //                    if(movements.planned(0).has_type() &&
                    //                            movements.planned(0).type()==Movement::COMPASS_REDUCTION_TIMER &&
                    //                            movements.planned(0).has_duration() &&
                    //                            std::abs(movements.planned(0).duration()-9.0)<0.001 &&
                    //                            SystemConfig::dynamic_mode==0 &&
                    //                            SystemConfig::drum_mode==0) {
                    //                        if(!move_to_center) logMoves.add(StdLogger::TRACE,"move to center = ON");
                    //                        move_to_center = true;
                    //                        is_in_longtime_test = false;
                    //                    } else {
                    if(!is_in_longtime_test) stressReelerStep = 0;
                    is_in_longtime_test = true;
                    longtime_test_with_reeler = false;
                    if(movements.planned(0).has_type() &&
                            movements.planned(0).type()==Movement::COMPASS_REDUCTION_TIMER &&
                            movements.planned(0).has_velocity_slow() &&
                            std::abs(movements.planned(0).velocity_slow()-1.0)<0.001 &&
                            SystemConfig::dynamic_mode==0 &&
                            SystemConfig::drum_mode==0) {
                        longtime_test_with_reeler = true;
                    }
                    //                    }
                }
                program.widthCtrl.setReached(false);
                if(movements.planned(0).has_velocity()) {
                    double v = movements.planned(0).velocity();
                    program.speedCtrl.reset(v);
                }
                double w=0.0,l=0.0,gs=0.0;
                if(movements.planned(0).has_presheet_width()) {
                    w = movements.planned(0).presheet_width();
                }
                if(movements.planned(0).has_presheet_length()) {
                    l = movements.planned(0).presheet_length();
                }
                if(movements.planned(0).has_presheet_gapsize()) {
                    gs = movements.planned(0).presheet_gapsize();
                }
                if(w<0.0) w = 0.0;
                if(l<0.0) l = 0.0;
                if(gs<0.0) gs = 0.0;
                if(w>0.0 || l>0.0 || gs>=0.0) program.widthCtrl.set_ctrl(gs>0.0?gs:w,l,gs>0.0);
            }
            break; }
        case MovementRequest::ADD_IF_EMPTY:
            is_in_longtime_test = false;
            if (movements.planned_size() > 0 or movements.has_current()) {
                failed = true;
            } else {
                //bindata.recording = 1; // new recipe
                flourduster_delayed = false;
                resetPreSheets(bindata, "handle movement add_if_empty");
                program.reset();
                movements.mutable_planned()->MergeFrom(moveRequest.movement());
                if(movements.planned_size()>0) {
                    stats.reset(movements.planned(0).has_gapsize()?movements.planned(0).gapsize():0.0,
                                movements.planned(0).has_velocity()?int(movements.planned(0).velocity()):0);
                    program.widthCtrl.setReached(false);
                    program.setStepArt(moveRequest.has_step_art()?
                                           moveRequest.step_art()
                                         :
                                           ::sheeter2020::MovementRequest::StepArt::MovementRequest_StepArt_UNKNOWN);
                    if(movements.planned(0).has_velocity()) {
                        double v = movements.planned(0).velocity();
                        program.speedCtrl.reset(v);
                        program.setDoughSide(v>0.0?-1:(v<0.0?1:0));
                    }
                    double w=0.0,l=0.0,gs=0.0;
                    if(movements.planned(0).has_presheet_width()) {
                        w = movements.planned(0).presheet_width();
                    }
                    if(movements.planned(0).has_presheet_length()) {
                        l = movements.planned(0).presheet_length();
                    }
                    if(movements.planned(0).has_presheet_gapsize()) {
                        gs = movements.planned(0).presheet_gapsize();
                    }
                    if(w<0.0) w = 0.0;
                    if(l<0.0) l = 0.0;
                    if(gs<0.0) gs = 0.0;
                    if(w>0.0 || l>0.0 || gs>=0.0) {
                        program.widthCtrl.set_ctrl(gs>0.0?gs:w,l,gs>0.0);
                        if(gs>0.0 || w>0.0) program.setAfterWidthCtrl(false);
                    }
                }
            }
            break;
        }
        if (failed)
            rep.set_error(MovementResponse::ERROR);
        else
            rep.set_error(MovementResponse::OK);
        auto t1 = clock::now();
        double timediff = std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
        logMoves.fmt("response: %s\n...",rep.DebugString().c_str());
        logMoves.fmt("now movements:\n%s",movements.DebugString().c_str());
        int nout = rep.ByteSize();
        if(!sent) {
            logMoves.fmt("response: %s\n...",rep.DebugString().c_str());
            char *outbuf = new char[nout];
            rep.SerializeToArray(outbuf,nout);
            nn_send(move_command_s, outbuf, nout, 0);
            delete[] outbuf;
        }
        //printf("Received request %s\n", moveRequest.DebugString().c_str());
        std::string dmpstr = movements.DebugString();
        //int dmppos;
        std::string::size_type dmppos;
        while((dmppos=dmpstr.find("\n"))!=std::string::npos) dmpstr.replace(dmppos,1,"\\n");
        printf("(2: %.3lf ms)Now movements is %s\n", timediff/1000.0, dmpstr.c_str());
        logger.save("movements-recv","%s",movements.DebugString().c_str());
    }

    std::pair<bool, MovementRequest> get_pending_movement_request()
    {
        void *buf = nullptr;

        int nbytes = nn_recv(move_command_s, &buf, NN_MSG, NN_DONTWAIT);
        if (nbytes < 0)
        {
            int error = nn_errno();
            if(buf) nn_freemsg(buf);
            if (error == EAGAIN)
                return std::make_pair(false, MovementRequest());
            printf("Error receiving movement request: %s", nn_strerror(error));
            return std::make_pair(false, MovementRequest());
        }
        MovementRequest mov_req;
        if (!mov_req.ParseFromArray(buf, nbytes))
        {
            printf("Unable to parse MovementRequest!");
            nn_freemsg(buf);
            return std::make_pair(false, MovementRequest());
        }
        return std::make_pair(true, mov_req);
    }

    void publish_current_movements()
    {
        const sheeter2020::Movement *curr = movements.has_current() ? &movements.current() : nullptr;
        movementInfo.set_current_gapsize(curr && curr->has_gapsize() ? curr->gapsize() : 0.0);
        movementInfo.set_in_progress(curr!=nullptr);
        movementInfo.set_planned_count(movements.planned_size());
        double dummy=0.0;
        movementInfo.set_transfer_us_waiting(program.is_us_valid(dummy));
        movementInfo.set_finishing(curr && (
                                       curr->type()==::sheeter2020::Movement_MovementType_COMPASS_FINAL_CUTOMAT ||
                                       curr->type()==::sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL ||
                                       curr->type()==::sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL ||
                                       curr->type()==::sheeter2020::Movement_MovementType_COMPASS_FINAL_TRANSPORT
                                       ));
        if(curr) {
            if(stepPaused) {
                movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_PAUSE);
                movementInfo.set_pause_reason(pauseReason);
            } else {
                movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_BUSY);
                movementInfo.set_pause_reason(sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE);
            }
        } else if(movements.planned_size()>0) {
            movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_BUSY);
            movementInfo.set_pause_reason(sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE);
        } else {
            if(movementInfo.progress()==sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_BUSY) {
                movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_FINISHED);
                movementInfo.set_pause_reason(sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE);
            } else if(movementInfo.progress()!=sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_FINISHED) {
                movementInfo.set_progress(sheeter2020::MovementInfoStatus_MovementProgress::MovementInfoStatus_MovementProgress_PROGRESS_NONE);
                movementInfo.set_pause_reason(sheeter2020::MovementInfoStatus_PauseReason_PAUSE_NONE);
            }
        }
        double l = program.widthCtrl.width();
        movementInfo.set_waiting_length(l);
        movementInfo.set_length_reached(program.widthCtrl.reached());
        movementInfo.set_move_direction(!stepPaused && curr && curr->has_velocity() ? program.speedCtrl.direction(curr->velocity()) : 0);

        char *buf = new char[movementInfo.ByteSize()];
        if (movementInfo.SerializeToArray(buf, movementInfo.ByteSize()))
        {
            nn_send(move_status_s, buf, movementInfo.ByteSize(), 0);
        } else {
            fprintf(StdLogger::DBG,"send movement status failed - not serialized");
        }
        delete[] buf;
        buf = nullptr;

        if(sendCnt > 0){
            sendCnt -= 1; //hold the empty run gap size for a while, for garantee recieve
        }else{
            if(movementInfo.has_extra_empty_run_gapsize() && movementInfo.extra_empty_run_gapsize() != 0){
                movementInfo.set_extra_empty_run_gapsize(0);
                fprintf(StdLogger::DBG,"inserted empty run gap size is been sent, so set it back to 0 \n");
            }
        }
    }

    ServoStatusBatch wait_for_new_status() {
        return machine.wait_for_new_status();
    }

private:
    machine_interface_t machine;

    int move_status_s;  // socket
    int move_status_e;  // endpoint
    int move_command_s; // socket
    int move_command_e; // endpoint
    int log_pipe_s; // socket
    int log_pipe_e; // endpoint

    time_point timestamp_step_begin;
    time_point lasertrigger_rising_edge;
    time_point lasertrigger_falling_edge;
    time_point autohaspel_starttime_slow;
    time_point autohaspel_starttime_normal;
    time_point autohaspel_dough_end_time; //For EcoStar
    time_point haspel_end_delay_time; //For EcoStar, add delay before finish
    //double autohaspel_last_check;
    int64_t autohaspel_dough_start_position;
    int64_t autohaspel_dough_end_position;
    int64_t autohaspel_dough_end_position_raw;
    //double table_oneside_length_mm;
    double finish_length_factor;
    double positionTicksPerMillimeter;
    time_point last_pause_begin;
    time_point last_gapsize_reached;
    enum AutoreelMidStep {AR_STEP_UNUSED, AR_STEP_TRIGGER_START, AR_STEP_SLOW_MOVE, AR_STEP_WHILE_SLOW_MOVE, AR_STEP_AFTER_SLOW_MOVE, AR_STEP_FINISH_DELAY, AR_STEP_FINISH};
    AutoreelMidStep autoreelMidstep;
    enum RestarGapStep {GAP_STEP_UNUSED, GAP_STEP_RESTART, GAP_STEP_FINISH};
    TRACED_VAR(restarGapStep,RestarGapStep,GAP_STEP_UNUSED);
    enum SetPizzaGapStep {PGAP_STEP_UNUSED, PGAP_STEP_NEW, PGAP_STEP_FINISH};
    SetPizzaGapStep setPizzaGapStep;
    bool hasEndPosition;
    uint64_t pause_time_s;
    uint64_t pause_time_ecostar_s;

    TRACED_VAR(lastLaserStatus,bool,false);
    bool gapSizeStatusReached;
    bool waitForStartButtonPressed;
    bool doughReelerIsOpening;
    bool doughReelerIsClosing;
    bool doughReelerIsActived;
    time_point doughReelerIsActivedTime;
    bool stepPaused;
    sheeter2020::MovementInfoStatus_PauseReason sw_stop_request;
    bool sw_left_right;
    sheeter2020::MovementInfoStatus_PauseReason pauseReason;
    bool doughWentThroughAlready;
    //bool dynamic_speed_correction;

    bool preSheetLastLaserStatus;
    int64_t preSheetStartPositionConveyor;
    int64_t preSheetStartPositionDrum;
    time_point preSheetStartTime;
    bool lastHWLaserTrigger;
    int last_torque;
    bool move_to_center;
    bool transport_bit;
    uint32_t transport_val;
    bool is_in_longtime_test;
    bool longtime_test_with_reeler;
    time_point stressReelerTime;
    int stressReelerStep;

    time_point flourduster_delay_start;
    bool flourduster_delayed;

    PlannedMovements movements;
    MovementInfoStatus movementInfo;

    double infeedSpeedPreviousStep;
    double extractionSpeedPreviousStep;

    class Stats {
    public:
        Stats(){off=0; reset(0.0, 0);}
        void reset(double gp, int sp){
            if(off>0 && off<sizeof(val)/sizeof(val[0])) log();
            off = 0;
            gap = gp;
            speed = sp;
            for(size_t i=0; i<sizeof(val)/sizeof(val[0]); i++) val[i] = 0;
            la.reset();
            ra.reset();
            start = clock::now();
        }
        void add(int l, int r){
            if(off>=sizeof(val)/sizeof(val[0])) return;
            la.add(l);
            ra.add(r);
            time_point t = clock::now();
            std::chrono::duration<double> diff_time = t - start;
            double diff_ms = std::chrono::duration_cast<std::chrono::milliseconds>(diff_time).count();
            if(diff_ms>=50.0) {
                start = t;
                val[off] = ra.value() - la.value();
                off++;
                if(off>=sizeof(val)/sizeof(val[0])) log();
            }
        }
    private:
        size_t off;
        double gap;
        int speed;
        time_point start;
        Average<int, int64_t, 6> la, ra;
        int val[10];
        void log() {
            switch(off) {
            case 1:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d", speed, gap, val[0]);
                break;
            case 2:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d", speed, gap, val[0], val[1]);
                break;
            case 3:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d", speed, gap, val[0], val[1], val[2]);
                break;
            case 4:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3]);
                break;
            case 5:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4]);
                break;
            case 6:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4], val[5]);
                break;
            case 7:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4], val[5], val[6]);
                break;
            case 8:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7]);
                break;
            case 9:
                fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7], val[8]);
                break;
            default:
                if(off>0) fprintf(StdLogger::TRACE,"SPEED=%d GAP=%.2lf TRQ: %d %d %d %d %d %d %d %d %d %d", speed, gap, val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7], val[8], val[9]);
                break;
            }
        }
    } stats;

    class PrgBlock {
    public:
        PrgBlock() {
            const char *stmp;
            set_us_speed(0.0);
            nxtGapsize = 0.0;
            nowGapsize = 0.0;
            prevGapsize = 0.0;
            time_speed_factor = 0.0;
            step_art = ::sheeter2020::MovementRequest_StepArt_UNKNOWN;
            dough_side = 0;
            after_width_ctrl = true;

            //pre_ticks2mm = 329500.0;
            //rmode_factor = 1.136;

            stmp = std::getenv("RONDO_TIMESPEED_FACTOR");
            if(stmp) {
                double tmp = std::atof(stmp);
                if(tmp>0.0) {
                    time_speed_factor = tmp;
                    fprintf(StdLogger::DBG,"time mode set to ON, factor = %.5lf", time_speed_factor);
                }
            }

            //with_drum_pos_mode = false;
            /*stmp = std::getenv("RONDO_DRUM_MODE");
            if(stmp) {
                int tmp = std::atoi(stmp);
                if(tmp>0) {
                    with_drum_pos_mode = true;
                    fprintf(StdLogger::DBG,"drum positioning mode set to ON");
                }
            }*/

            gap_reserve_max = 5.0;
            stmp = std::getenv("RONDO_GAP_ADD_MAX");
            if(stmp) {
                int tmp = std::atoi(stmp);
                if(tmp>0 && tmp<=10) {
                    gap_reserve_max = tmp;
                    fprintf(StdLogger::DBG,"gap_reserve_max changed to %.1lf", gap_reserve_max);
                }
            }

            gap_reserve_proc = 50;
            stmp = std::getenv("RONDO_GAP_ADD_PERCENT");
            if(stmp) {
                int tmp = std::atoi(stmp);
                if(tmp>0 && tmp<=100) {
                    gap_reserve_proc = tmp;
                    fprintf(StdLogger::DBG,"gap_reserve_proc changed to %.1lf", gap_reserve_proc);
                }
            }
        }

        bool is_us_valid(double &speed) {
            if(!us_valid) return false;
            speed = us_speed;
            return true;
        }

        void set_us_speed(double speed) {
            us_speed = std::abs(speed);
            us_valid = us_speed>0.01;
        }

        void reset() {
            speedCtrl.reset(0.0);
            widthCtrl.set_ctrl(0.0, 0.0, false);
            prevGapsize = 0.0;
            nxtGapsize = 0.0;
            nowGapsize = 0.0;
            dough_side = 0;
            after_width_ctrl = true;
            step_art = ::sheeter2020::MovementRequest_StepArt_UNKNOWN;
        }

        int doughSide() const {
            return dough_side;
        }

        void setDoughSide(int side) {
            dough_side = side<0 ? -1 : (side>0 ? 1 : 0);
        }

        bool afterWidthCtrl() const {
            return after_width_ctrl;
        }

        void setAfterWidthCtrl(bool yes) {
            after_width_ctrl = yes;
        }

        void setStepArt(::sheeter2020::MovementRequest::StepArt art)
        {
            step_art = art;
        }

        ::sheeter2020::MovementRequest::StepArt stepArt() const
        {
            return step_art;
        }

        double previousGapsize(){
            if(prevGapsize<=0.0) return nowGapsize;
            return prevGapsize;
        }

        bool isTimeMode() {
            return time_speed_factor > 0.000001;
        }

        double timespeedFactor() {
            return time_speed_factor;
        }

        void setNextGapsize(double val) {
            nxtGapsize = val;
        }
        void setCurrentGapsize(double val) {
            prevGapsize = nowGapsize;
            nowGapsize = val;
        }
        double currentGapsize() {
            return nowGapsize;
        }
        bool isNextGapsize() {
            return (nxtGapsize>0.0);
        }
        double nextGapsize() {
            double ret = nxtGapsize;
            nxtGapsize = 0.0;
            return ret;
        }

        uint32_t distance(uint32_t start, uint32_t end, int dir) {
            int64_t d;
            if(dir<0) {
                if(start>=end) {
                    d = start - end;
                } else {
                    d =  0x100000000L + start;
                    d -= end;
                }
            } else {
                if(end>=start) {
                    d = end - start;
                } else {
                    d = 0x100000000L + end;
                    d -= start;
                }
            }
            return uint32_t(d);
        }

        double gapIncreased(double gapsize) {
            //            double ret = std::fmin(std::fmin(gapsize + gap_reserve_proc*gapsize/100.0, gapsize + gap_reserve_max), 45.0);
            //            if(ret<gapsize) ret = gapsize;
            //            return ret;
            return gapsize; // without increasing gapsize
        }

        class SpeedControl {
        public:
            SpeedControl(){
                reset(0.0);
            }
            void reset(double val) {
                start_speed = val;
                current_speed = -val;
                count = 0;
                //                flourduster_step = 0;
            }
            void setCurrent(double val) {
                current_speed = val;
            }
            double current() {
                return current_speed;
            }
            int nextDirection() {
                count++;
                int d = direction(start_speed);
                if(count&1) {
                    // same as start direction
                    return d;
                } else {
                    // oposit to start direction
                    return -d;
                }
                //current_speed = -current_speed;
                //return d;
            }
            int startDirection() {
                return direction(start_speed);
            }
            static int direction(double val) {
                if(val<0.0) return -1;
                else if(val>0.0) return 1;
                return 0;
            }
            //            void setFlourdusterStep(int val)
            //            {
            //                if(val>=0 && val<=5) flourduster_step = val;
            //            }

            //            bool flourdusterStep() {
            //                if(flourduster_step<=0) return false;
            //                if(flourduster_step==1) return true;
            //                return (count%flourduster_step)==0;
            //            }

        private:
            int count;
            double start_speed;
            double current_speed;
            //            int flourduster_step;
        } speedCtrl;

        class WidthControl {
        public:
            WidthControl(){
                raw_last = 0;
                raw_current = 0;
                dough_end_left = dough_end_drum = dough_end_right = 0;
                //volume_factor = 100.0;
                length_reached = false;
                /*const char *stmp = std::getenv("RONDO_VOLUME_FACTOR");
                if(stmp) {
                    double tmp = std::atof(stmp);
                    if(tmp>0.0) {
                        volume_factor = tmp;
                        fprintf(StdLogger::DBG,"volume factor changed to %.5lf", volume_factor);
                    }
                }*/
                set_ctrl(0.0, 0.0, false);
            }
            void correct_gapsize(double gs) {
                if(gs>0.0) {
                    set_ctrl(gs,requested_length,true);
                    length_reached = false;
                }
            }
            void correct_wctrl(double w) {
                if(w>0.0) {
                    set_ctrl(w,requested_length,false);
                    length_reached = false;
                }
            }
            void set_ctrl(double widthOrGapsize, double length, bool asGapsize) {
                if(asGapsize) {
                    requested_width = 0.0;
                    requested_gapsize = widthOrGapsize>0.0? widthOrGapsize : 0.0;
                    if(requested_gapsize<0.2) requested_gapsize = 0.0;
                } else {
                    requested_width = widthOrGapsize>0.0? widthOrGapsize : 0.0;
                    requested_gapsize = 0.0;
                }
                requested_length = length>0.0 ? length : 0.0;
                needStop = requested_width<=0.0 && requested_gapsize<=0.0 && requested_length>0.0 ? true : false;
                raw_current = 0;
                extraMove = false;
                dough_end_left = dough_end_drum = dough_end_right = 0;
                if(requested_width>0.0) logMoves.fmt("#### SET WIDTH CTRL TO %.2lf mm as messure", requested_width);
                if(requested_gapsize>0.0) logMoves.fmt("#### SET WIDTH CTRL TO %.2lf mm as gapsize", requested_gapsize);
                if(requested_length>0.0) logMoves.fmt("#### SET LENGTH CTRL TO %.2lf mm", requested_length);
                if(requested_width<=0.0 && requested_gapsize<=0.0 && requested_length>0.0) {
                    clear();
                }
                //fprintf(StdLogger::DBG,"RESET: drum position on dough passed: %u, w=%.1lf, l=%.1lf, g=%.2lf", dough_end, requested_width, requested_length, requested_gapsize);
            }
            bool reached() {
                return length_reached;
            }
            void setReached(bool yes) {
                if(yes != length_reached) {
                    length_reached = yes;
                }
            }
            //            double volumeFactor() {
            //                return volume_factor;
            //            }
            //            void setVolumeFactor(double val) {
            //                if(val>0.0) {
            //                    volume_factor = val;
            //                    fprintf(StdLogger::INFO,"volume factor set to %.2lf", volume_factor);
            //                }
            //            }
            double width() {
                return requested_width;
            }
            double gapsize() {
                return requested_gapsize;
            }
            bool isActive() {
                return requested_width>0.0 || requested_gapsize>0.0;
            }
            void clear() {
                requested_width = requested_length;
                requested_length = 0.0;
                requested_gapsize = 0.0;
                needStop = requested_width > 0.0;
                extraMove = false;
                dough_end_left = dough_end_drum = dough_end_right = 0;
                //fprintf(StdLogger::DBG,"CLEAR: drum position on dough passed: %u, w=%.1lf, l=%.1lf", dough_end, requested_width, requested_length);
            }
            bool shouldStop() {
                return needStop;
            }
            void setCurrentRawLength(int64_t val, uint32_t pos_drum, uint32_t pos_left, uint32_t pos_right) {
                fprintf(StdLogger::DBG, "set current raw length: %lld (drum pos %u) /DBG/", val, pos_drum);
                raw_current = val;
                if(val>0) raw_last = val;
                dough_end_drum = pos_drum;
                dough_end_left = pos_left;
                dough_end_right = pos_right;
            }
            int64_t currentRawLength() {
                return raw_current;
            }
            int64_t lastRawLength() {
                return raw_last;
            }
            void setExtraMove() {
                extraMove = true;
            }
            bool isExtraMove() {
                return extraMove;
            }

            uint32_t start_rawposition(int src=0) {
                if(src<0) return dough_end_left;
                if(src>0) return dough_end_right;
                return dough_end_drum;
            }
        private:
            double requested_width;
            double requested_length;
            double requested_gapsize;
            bool needStop;
            bool extraMove;
            int64_t raw_current;
            int64_t raw_last;
            uint32_t dough_end_left, dough_end_drum, dough_end_right;
            //double volume_factor;
            bool length_reached;
        } widthCtrl;

        class TriggerControl {
        public:
            TriggerControl(){
                trigger2.state = false;
                trigger2.start_pos = 0;
                trigger2.end_pos = 0;
                trigger2.dir = 0;
                //trigger2.start_time = std::chrono::steady_clock::now();
                //correction_value = 0;
                reset(0, "init");
            }
            bool isCheckInertia() {
                return SystemConfig::safe_stop;
            }
            void reset(uint32_t pos, const char *txt){
                start_time = std::chrono::steady_clock::now();
                setTriggerCheckPosition(pos, txt);
                needResetPos = true;
                fprintf(StdLogger::DBG, "laser trigger needResetPos=true (while reset)");
            }
            int trigger2Dir() {
                return trigger2.dir;
            }
            bool trigger2Active() {
                return trigger2.state;
            }
            bool setTrigger2State(bool off, uint32_t pos, int dir, int idx) {
                if(!off && !trigger2.state) {
                    if(dir==0) {
                        fprintf(StdLogger::DBG,"HW laser trigger2 state ON skipped due to dir=0 at pos %u", pos);
                        return false;
                    }
                    trigger2.dir = dir;
                    trigger2.state = true;
                    trigger2.start_pos = pos;
                    fprintf(StdLogger::DBG,"HW laser trigger2 changed to ON at pos %u of servo[%d] moving to %s", pos, idx, dir<0?"left":"right");
                } else if(off && trigger2.state) {
                    trigger2.state = false;
                    trigger2.end_pos = pos;
                    fprintf(StdLogger::DBG,"HW laser trigger2 changed to OFF at pos %u of servo[%d] moving to %s", pos, idx, dir<0?"left":"right");
                    return true;
                }
                return false;
            }
            uint32_t trigger2Pos(bool start) {
                if(trigger2.state) return 0;
                return start ? trigger2.start_pos : trigger2.end_pos;
            }
            void setTriggerCheckPosition(uint32_t pos, const char *txt) {
                pos_trigger_on = pos;
                fprintf(StdLogger::DBG,"SW laser trigger validation position set to %u ... %s", pos, txt);
            }
            void checkMove(int dirNow, int dirToBe, int32_t pos) {
                //fprintf(StdLogger::DBG, "check move: now=%d, tobe=%d, pos=%u", dirNow, dirToBe, uint32_t(pos));
                if(dirNow==0 || dirToBe==0 || dirNow!=dirToBe) {
                    if(!needResetPos) {
                        needResetPos = true;
                        fprintf(StdLogger::DBG, "laser trigger needResetPos=true (while monitoring: dir now=%d, should=%d)",dirNow,dirToBe);
                    }
                }
                else if(needResetPos) {
                    setTriggerCheckPosition(uint32_t(pos), "speed monitoring, needResetPos=false");
                    needResetPos = false;
                }
            }
            bool isValid(uint32_t pos, int direction){
                if(direction==0 || needResetPos) return false;
                int64_t diff;
                bool overflowed = false;
                if(direction<0){
                    if(pos > pos_trigger_on) {
                        overflowed = true;
                        diff = 0x100000000LL + pos_trigger_on;
                        diff -= pos;
                    } else {
                        diff = pos_trigger_on - pos;
                    }
                } else {
                    if(pos < pos_trigger_on) {
                        overflowed = true;
                        diff = 0x100000000LL + pos;
                        diff -= pos_trigger_on;
                    } else {
                        diff = pos - pos_trigger_on;
                    }
                }
                if(diff >= SystemConfig::trigger_ignore_ticks) {
                    //if(overflowed) fprintf(StdLogger::DBG, "trigger valid: %u - %u = %lld > %d (direction: %d)", pos_trigger_on, pos, diff, limit, direction);
                    return true;
                }
                return false;
            }
            //            double correction() {
            //                return correction_value;
            //            }
            //            void setCorrection(double val) {
            //                if(val>=0.0) {
            //                    correction_value = val;
            //                    fprintf(StdLogger::INFO,"trigger correction set to %.2lf ms", correction_value);
            //                }
            //            }
            uint32_t triggerStartPos() {
                return pos_trigger_on;
            }
        private:
            std::chrono::time_point<clock> start_time;
            uint32_t pos_trigger_on;
            struct ST_TRIGER2 {
                //std::chrono::time_point<clock> start_time;
                uint32_t start_pos, end_pos;
                bool state;
                int dir;
            } trigger2;

            //double correction_value;
            bool needResetPos;
        } triggerCtrl;

    private:
        double nxtGapsize;
        double nowGapsize;
        double prevGapsize;
        double gap_reserve_max;
        double gap_reserve_proc;
        double time_speed_factor;
        ::sheeter2020::MovementRequest::StepArt step_art;
        int dough_side;
        bool after_width_ctrl;
        double us_speed;
        bool us_valid;
    } program;
};

static void save_after(tBINLOG &data, const sheeter2020::ServoStatusBatch &status, const RecipeInterpreter &interp)
{
    if(status.ByteSize()<=0) return;

    bool rec = false;
    for(int i=0; i<status.statuses_size(); i++) {
        if(!status.statuses(i).has_servo_id()) continue;
        uint32_t drvid = status.statuses(i).servo_id();
        if(drvid>=4) continue;
        const sheeter2020::ServoStatus &servo = status.statuses(i);
        tBINMOTOR &motor = data.motor[drvid];
        if(drvid==3) motor.speed_requested = servo.has_target_pos() ? servo.target_pos() : 0;
        else {
            motor.speed_requested = servo.has_target_velocity() ? servo.target_velocity() : 0;
            if(motor.speed_requested != 0) rec = 1;
        }
        switch(servo.state()) {
        case sheeter2020::ServoStatus_State::ServoStatus_State_RUNNING:
            motor.mstate.start = 0;
            motor.mstate.running = 1;
            break;
        case sheeter2020::ServoStatus_State::ServoStatus_State_STANDBY:
            motor.mstate.start = 1;
            motor.mstate.running = 0;
            break;
        default:
            motor.mstate.start = 0;
            motor.mstate.running = 0;
            break;
        }
    }
    data.motor[3].dough_length = interp.currentDoughLength();
    data.pause = interp.isPaused()?1:0;
    data.gap_reached = interp.isGapReached()?1:0;
    static int64_t last_rec = 0;
    if(!data.pause && !data.cage_opened && rec) {
        data.recording = 1;
        last_rec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    } else if(data.recording && !rec) {
        int64_t mx = interp.isBusy() ? 60000ll : 2000ll;
        int64_t t = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        if(t-last_rec > mx)
            data.recording = 0;
    }
}

static void save_before(tBINLOG &data, const sheeter2020::ServoStatusBatch &status)
{
    if(status.ByteSize()<=0) return;

    for(int i=0; i<status.statuses_size(); i++) {
        if(!status.statuses(i).has_servo_id()) continue;
        uint32_t drvid = status.statuses(i).servo_id();
        if(drvid>=4) continue;
        const sheeter2020::ServoStatus &servo = status.statuses(i);
        tBINMOTOR &motor = data.motor[drvid];
        motor.speed_current = servo.has_velocity() ? servo.velocity() : 0;
        if(drvid!=3) motor.rawspeed_current = servo.has_velocity_raw() ? servo.velocity_raw() : 0;
        motor.status_hw = servo.has_lowlevel_status() ? servo.lowlevel_status() : 0;
        motor.error_hw = servo.has_lowlevel_error() ? servo.lowlevel_error() : 0;
        motor.status_sys = servo.has_state() ? servo.state() : 0;
        motor.error_sys = servo.has_error() ? servo.error() : 0;
        motor.position = servo.has_position() ? servo.position() : 0;
        if(drvid!=3) motor.position_raw = servo.has_position_raw() ? servo.position_raw() : 0;
        motor.torque = servo.has_torque() ? servo.torque() : 0;
        if(drvid==1) {
            // I/O
            if(servo.has_digital_in()) {
                data.btn_left = servo.digital_in().has_mon2() ? servo.digital_in().mon2() : 0;
                data.btn_right = servo.digital_in().has_mon3() ? servo.digital_in().mon3() : 0;
                data.btn_stop = servo.digital_in().has_mon4() ? servo.digital_in().mon4() : 0;
                data.cage_opened = servo.digital_in().has_mon1() ? servo.digital_in().mon1() : 0;
                data.trigger_hw = servo.digital_in().has_mon5() ? servo.digital_in().mon5() : 0;
            } else {
                data.btn_left = data.btn_right = data.btn_stop = data.trigger_hw = 0;
                data.cage_opened = 1;
                //data.recording = 0; // no dig I/O
            }
            if(servo.has_ext_coupler()) {
                data.transport = servo.ext_coupler().has_digital_in_ext() && servo.ext_coupler().digital_in_ext() ? 1:0;
                data.motor[3].u16.transport = servo.ext_coupler().has_analog_in_ext() ? uint16_t(servo.ext_coupler().analog_in_ext()) : 0;
            }
        }
    }
}

void interpreter_loop()
{
    using sheeter2020::ServoStatusBatch;

    RecipeInterpreter interp;

    tBINLOG bindata;
    bindata.clear();
#ifndef NO_BINDATA
    bool recording = false;
#endif

    while (1)
    {
        ServoStatusBatch newStatus = interp.wait_for_new_status();
        save_before(bindata,newStatus);
        interp.handle_servo_status(newStatus, bindata);

        bool has_pending_reqs = true;
        while (has_pending_reqs) {
            auto req = interp.get_pending_movement_request();
            if (req.first) {
                interp.handle_movement_requests(req.second, bindata);
            }
            has_pending_reqs = req.first;
        }

        save_after(bindata,newStatus,interp);

#ifndef NO_BINDATA
        if(bindata.recording) {
            recording = true;
            binlog.addData(bindata);
        } else if(recording) {
            recording = false;
            binlog.endData();
        }
#endif

        interp.publish_current_movements();
    }
}
