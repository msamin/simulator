#include <global_state.hpp>

namespace ec {
    ec_master_t *master = NULL;
    ec_master_state_t master_state;

    ec_domain_t *domain1 = NULL;
    ec_domain_state_t domain1_state;

    ec_slave_config_t* sc_0;
    ec_slave_config_t* sc_1;
    ec_slave_config_t* sc_2;
    ec_slave_config_t* sc_3;
    ec_slave_config_t*  sc_ext_0;
    ec_slave_config_t*  sc_ext_1;

    ec_slave_config_t*  sc_digiIn_0;
    ec_slave_config_t*  sc_digiIn_1;
    ec_slave_config_t*  sc_digiOut_0;
    ec_slave_config_t*  sc_digiOut_1;

    ec_slave_config_state_t sc_state_0;
    ec_slave_config_state_t sc_state_1;
    ec_slave_config_state_t sc_state_2;
    ec_slave_config_state_t sc_state_3;
    ec_slave_config_state_t sc_state_4;
    ec_slave_config_state_t sc_state_ext_0;
    ec_slave_config_state_t sc_state_ext_1;
}

// Global process data
uint8_t *domain1_pd = NULL;
process_data_t process_data[NUMBER_MOTORS];
process_data_t process_data_buffer[NUMBER_MOTORS];
std::mutex lock_process_data[NUMBER_MOTORS];
std::array<std::atomic<uint32_t>, NUMBER_MOTORS> din_latch;
std::array<std::atomic<uint32_t>, NUMBER_MOTORS> dout_latch;

// Global process data for extra coupler
process_data_t process_data_ext;
process_data_t process_data_buffer_ext;
std::mutex lock_process_data_ext;

// Global command data
command_data_t command_data[NUMBER_MOTORS];
std::mutex lock_command_data[NUMBER_MOTORS];

// offsets for PDO entries
offset_t offset[NUMBER_MOTORS];
