#include <r88d.hpp>
#include <stdlogger.h>
#include <cmath>
#include <string.h>
#include "motorgaptable.h"

namespace status {

    uint16_t remove_vendor_extension(uint16_t status) {
        status &= ~status_bit::VOLTAGE_ENABLED;
        status &= 0x7F; // Remove bits after 6
        return status;
    }


    void read(uint16_t status) {
        char tmpbuf[100];
        sprintf(tmpbuf,"status              : [%u", status);
        if (status & status_bit::VOLTAGE_ENABLED) strcat(tmpbuf,", Power enabled");

        status = remove_vendor_extension(status);

        switch (status) {
            case status::NOT_READY:
                strcat(tmpbuf,", NOT_READY]\n");
                break;
            case status::SWITCH_ON_DISABLED:
                strcat(tmpbuf,", SWITCH_ON_DISABLED]\n");
                break;
            case status::READY_SWITCH_ON:
                strcat(tmpbuf,", READY_SWITCH_ON]\n");
                break;
            case status::SWITCHED_ON:
                strcat(tmpbuf,", SWITCHED_ON]\n");
                break;
            case status::OPERATION_ENABLED:
                strcat(tmpbuf,", OPERATION_ENABLED]\n");
                break;
            case status::FAULT_REACTION:
                strcat(tmpbuf,", FAULT_REACTION]\n");
                break;
            case status::FAULT:
                strcat(tmpbuf,", FAULT]\n");
                break;
            default:
                strcat(tmpbuf,", UNKNOWN]\n");
                break;
        }
        printf("%s",tmpbuf);
    }
}

// Linear approach to the slope of the mechanical construction
/*constexpr double m_slope = 13764429.1879; //update from Rondo Burgdorf at 26.11.2018
                         //13535963.8272; // -14000000.0;//-14279107.0;//From Repository 14.08.18 //from original 14000000.0;

// Offset of the encoder at 0mm gapsize
// Rondo Prototype: -574649522.0
// PreciBake FuMu: +1369842239.0
constexpr double b_offset = 0.0;


int32_t gap_to_position(double gap) {
    return std::round((-1.0 * m_slope * gap) + b_offset);
}

double position_to_gap(int32_t position) {
    //double gap = (b_offset - static_cast<double>(position)) / m_slope;
    double gap;
    if(position == 0){
      gap = 0;
    }else{
      gap = std::fabs(static_cast<double>(position)) / m_slope;

    }    
    return gap;
}*/

#if NUMBER_MOTORS == 2
uint8_t gap_to_position(double gap) {

    gap = gap * 10.0;
    int gapAsIndex = (int)(gap);
    int32_t tickt;
    if(gapAsIndex > -1  && gapAsIndex < totalTableNum){
         tickt = motorGapTable[gapAsIndex];
    }else{

        tickt = motorGapTable[200]; //something is wrong, set in the middle
    }

    //printf(" -------- gap to posiiton----, input gap: %f  ,  gap as index: %d , tickt: %d     ---- \n", gap, gapAsIndex, tickt );
    return tickt;
}

double position_to_gap(uint8_t position) {
    uint16_t position100 = (uint16_t)position * 100; //tmp solution for fast search
    double gap;
    unsigned int indx = 0;
    indx = searchClosestGap(position100);
    gap = motorGapSortedIndexTable[indx];
    gap = gap / 10;
    if(gap < 0.2){
        gap = 0.2;
    }else if(gap > 45){
        gap = 45;
    }
    //printf("  ,,,,,,,,, positon to gap :  input poisiton: %d,  postion 100: %d,  gap : %f  ----------- \n", position, position100, gap);
    return gap;
}

#else
int32_t gap_to_position(double gap) {

    gap = gap * 10.0;
    int gapAsIndex = (int)(gap);
    int32_t tickt;
    if(gapAsIndex > -1  && gapAsIndex < totalTableNum){
         tickt = -1 * motorGapTable[gapAsIndex] + gapShifted;
    }else{

        tickt = -1 * motorGapTable[300] + gapShifted; ; //something is wrong, set in the middle
    }
    return tickt;
}

double position_to_gap(int32_t position) {
    position = position - gapShifted; //tmp solution for fast search
    double gap;
    if(position == 0){
      gap = 0.0;
    }else{
      gap = 0.1*searchClosestGap(position);
    }
    return gap;
}
#endif
