#include <stdlogger.h>
#include <fstream>
#include <algorithm>
#include <sys/stat.h>
#include <unistd.h>
#include <stdarg.h>
#include <sstream>
#include <signal.h>

#define MAX_WRITTEN_BYTES 250000LL

static void sig_handler(int sig)
{
    if(sig==SIGINT) {
        logger.exit();
        exit(0);
    }
}

StdLogger::StdLogger(const char *name)
{
    is_running = false;
    needExit = false;
    currList = 0;
    writtenBytes = 0;
    thread = nullptr;

#ifdef __x86_64__
    init(".","LOG",name);
#else
    init("/var/log","rondo",name);
#endif
    signal(SIGINT, sig_handler);
}

StdLogger::~StdLogger()
{
    exit();
    if(thread!=nullptr)
    {
        //delete thread; // exception - why does it happen hier
    }
}

void StdLogger::init(const std::string &dirname, const std::string &subdirname, const std::string &basename)
{
    if(!dirname.empty() && !subdirname.empty() && thread==nullptr)
    {
        baseName = basename;
        dirName = dirname + "/" + subdirname;
        mkdir(dirName.data(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

        renameFiles();
        writtenBytes = 0;

        is_running = true;
#if NUMBER_MOTORS == 2
        add(INFO, "program started (EcoStar)");
#else
        add(INFO, "program started (RondoStar/Compas)");
#endif
        thread = new std::thread(start, this);
    }
}

void StdLogger::exit()
{
    if(!needExit)
    {
        add(INFO, "program stopped");
        needExit = true;

        if(thread && is_running)
        {
            for(int i=0; i<10; i++) {
                usleep(500000ll);
                if(!is_running) break;
            }
        }
    }
}

void StdLogger::add(int filehandle, const std::string &text)
{
    std::lock_guard<std::mutex> lock(mux);
    tLOGEVENT ev;

    ev.filehandle = filehandle;
    ev.timestamp = std::chrono::system_clock::now();
    ev.text = text;
    list[currList].push_back(ev);
}

void StdLogger::add(int filehandle, const std::string &text, const char *par, const char *suffix)
{
    std::string tmp = text;
    if(par) tmp += par;
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::add(int filehandle, const std::string &text, int par, const char *suffix)
{
    std::string tmp = text + std::to_string(par);
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::add(int filehandle, const std::string &text, unsigned int par, const char *suffix)
{
    std::string tmp = text + std::to_string(par);
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::fmt(const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(1,buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::fmt(FILE *handle, const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(handle==stderr?2:1,buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::fmt(int lvl, const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(lvl,buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::renameFiles()
{
    std::fstream f;
    std::string newname, fname = dirName + "/" + baseName + "9.log";
    f.open(fname,std::ios_base::in);
    if(f.is_open()) {
        f.close();
        std::remove(fname.data());
    }
    for(int i=8; i>=0; i--)
    {
        fname = dirName + "/" + baseName + std::to_string(i) + ".log";
        newname = dirName + "/" + baseName + std::to_string(i+1) + ".log";
        f.open(fname,std::ios_base::in);
        if(f.is_open()) {
            f.close();
            std::rename(fname.data(),newname.data());
        }
    }
}

void StdLogger::start(void *ptr)
{
    StdLogger *me = (StdLogger*)ptr;
    me->run();
}

void StdLogger::run()
{
    while(true)
    {
        int idx;
        {
            std::lock_guard<std::mutex> lock(mux);
            idx = currList;
            currList = (currList+1)&1;
        }

        if(list[idx].size()>0)
        {
            std::string fname = dirName + "/" + baseName + "0.log";
            std::fstream logStream;
            std::string txt;
            for(const tLOGEVENT &data : list[idx])
            {
                //std::time_t t = data.timestamp;
                std::chrono::time_point<std::chrono::system_clock> tp = data.timestamp;

                if(!logStream.is_open())
                {
                    logStream.open(fname,std::ios_base::out | std::ios_base::app); // append
                }

                if(logStream.is_open())
                {
                    std::time_t t = std::chrono::system_clock::to_time_t(tp);
                    long ms = std::chrono::duration_cast<std::chrono::milliseconds>(tp.time_since_epoch()).count() % 1000;
                    char buf[62];
                    const char *grp;
                    switch(data.filehandle) {
                    case 1: grp = "stdout"; break;
                    case 2: grp = "stderr"; break;
                    case INFO: grp = "info"; break;
                    case WARN: grp = "warning"; break;
                    case ALERT: grp = "critical"; break;
                    case DBG: grp = "debug"; break;
                    case TRACE: grp = "trace"; break;
                    default: grp = "unknown"; break;
                    }
                    std::tm ts = *std::localtime(&t);
                    std::sprintf(buf,"%04d-%02d-%02d %02d:%02d:%02d.%03ld [%s]  ",
                                 ts.tm_year+1900, ts.tm_mon+1, ts.tm_mday, ts.tm_hour, ts.tm_min, ts.tm_sec>59?59:ts.tm_sec, ms, grp);

                    std::istringstream lst(data.text);
                    std::string line;
                    while(std::getline(lst, line, '\n')) {
                        if(line.empty()) continue;
                        txt = buf + line;
                        std::replace(txt.begin(),txt.end(),'\r',' ');
                        logStream << txt << "\n";
                        writtenBytes += txt.length();
                    }

                    /*txt = buf + data.text;
                    std::replace(txt.begin(),txt.end(),'\n',' ');
                    logStream << txt << "\n";
                    writtenBytes += txt.length();*/
                }
            }

            if(logStream.is_open())
            {
                logStream.flush();
                logStream.close();

                if(writtenBytes>MAX_WRITTEN_BYTES)
                {
                    renameFiles();
                    writtenBytes = 0;
                }
            }
            list[idx].clear();
            usleep(10000);
        }
        else
        {
            if(needExit) break;
            usleep(200000);
        }
    }

    is_running = false;
}

StdLogger logger("servo");
StdLogger logServo("servcmd");
StdLogger logMoves("moves");
StdLogger logMotors("motors");
