#include <binlogger.h>
#include <fstream>
#include <sys/stat.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlogger.h>

#ifndef NO_BINDATA
BinLogger binlog;
#endif

BinLogger::BinLogger()
{
    is_running = false;
    needExit = false;
    currList = 0;
    elems_written = 0;
    thread = nullptr;

#ifndef NO_BINDATA
#ifdef __x86_64__
    init(".","LOG");
#else
    init("/var/log","rondo");
#endif
#endif
}

BinLogger::~BinLogger()
{
    exit();
    if(thread!=nullptr)
    {
        //delete thread; // exception happens hier
    }
}

void BinLogger::init(const std::string &dirname, const std::string &subdirname, const std::string &basename)
{
    if(!dirname.empty() && !subdirname.empty() && thread==nullptr)
    {
        baseName = basename;
        dirName = dirname + "/" + subdirname;
        mkdir(dirName.data(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

        renameFiles();
        is_running = true;
        thread = new std::thread(start, this);
    }
}

void BinLogger::exit()
{
    if(!needExit)
    {
        needExit = true;

        if(thread && is_running)
        {
            for(int i=0; i<10; i++) {
                usleep(500000ll);
                if(!is_running) break;
            }
        }
    }
}

void BinLogger::start(void *ptr)
{
    BinLogger *me = (BinLogger*)ptr;
    me->run();
}

void BinLogger::renameFiles()
{
#ifndef NO_BINDATA
#define MAX_BIN_FILES 30 // if defined, it must be below 100
    std::fstream f;
    std::string newname, fname = dirName + "/" + baseName + "99.log";
    f.open(fname,std::ios_base::in);
    if(f.is_open()) {
        f.close();
        std::remove(fname.data());
    }
    for(int i=98; i>=0; i--)
    {
        if(i<10) fname = dirName + "/" + baseName + "0" + std::to_string(i) + ".log";
        else fname = dirName + "/" + baseName + std::to_string(i) + ".log";
        if(i<9) newname = dirName + "/" + baseName + "0" + std::to_string(i+1) + ".log";
        else newname = dirName + "/" + baseName + std::to_string(i+1) + ".log";
        f.open(fname,std::ios_base::in);
        if(f.is_open()) {
            f.close();
#ifdef MAX_BIN_FILES
            if(i==MAX_BIN_FILES)
                std::remove(fname.data());
            else
#endif
            std::rename(fname.data(),newname.data());
        }
    }
#endif
}

void BinLogger::run()
{
    printf("binary element size: %u bytes", sizeof(tBINLOG));
    std::size_t max_elements = 0;
    while(!needExit) {
        int idx;
        {
            std::lock_guard<std::mutex> lock(mux);
            idx = currList;
            currList = (currList+1)&1;
        }
        if(list[idx].size()>0) {
            if(max_elements<list[idx].size()) {
                max_elements = list[idx].size();
                printf("max binary log elements: %u", max_elements);
            }
            std::string fname = dirName + "/" + baseName + "00.log";
            std::fstream logStream;
            for(const tBINLOG &data : list[idx]) {
                if(data.size==0 || elems_written>25000) {
                    // end of recording, close file
                    if(logStream.is_open()) {
                        logStream.close();
                        renameFiles();
                        elems_written = 0;
                    }
                    if(data.size==0) continue;
                }
                if(!logStream.is_open())
                {
                    logStream.open(fname,std::ios_base::out | std::ios_base::app); // append
                }

                if(logStream.is_open()) {
                    // write data to file
                    logStream.write((const char*)&data,data.size);
                    elems_written++;
                }
            }
            list[idx].clear();
            if(logStream.is_open()) {
                logStream.flush();
                logStream.close();
            }
            usleep(100000);
        } else {
            usleep(200000);
        }
    }
    is_running = false;
}

void BinLogger::endData()
{
    std::lock_guard<std::mutex> lock(mux);
    tBINLOG ev;

    std::chrono::time_point<std::chrono::system_clock> t = std::chrono::system_clock::now();
    ev.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(t.time_since_epoch()).count();
    ev.size = 0;
    list[currList].push_back(ev);
}

void BinLogger::addData(const tBINLOG &dta)
{
    std::lock_guard<std::mutex> lock(mux);
    tBINLOG ev = dta;

    std::chrono::time_point<std::chrono::system_clock> t = std::chrono::system_clock::now();
    ev.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(t.time_since_epoch()).count();
    list[currList].push_back(ev);
}
