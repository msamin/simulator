#include <sdo_writer.h>
#include <stdlogger.h>


SDOWriter::SDOWriter()
{
    req = nullptr;
    bytesize = 0;
    count = 0;
    write_status = ST_READY;
    m_addr = m_subaddr = 0;
}

SDOWriter::~SDOWriter()
{

}

bool SDOWriter::init32(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr)
{
    return init(hw,main_addr,sub_addr,4);
}

bool SDOWriter::init16(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr)
{
    return init(hw,main_addr,sub_addr,2);
}

bool SDOWriter::init8(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr)
{
    return init(hw,main_addr,sub_addr,1);
}

bool SDOWriter::init(ec_slave_config_t *hw, uint16_t main_addr, uint8_t sub_addr, size_t size)
{
    if(req) return false;

    bytesize = size;
    m_addr = main_addr;
    m_subaddr = sub_addr;

    req = ecrt_slave_config_create_sdo_request(hw, main_addr, sub_addr, bytesize);
    if(!req) {
        bytesize = 0;
        logMotors.fmt("init write to 0x%04X.%02X failed",m_addr,m_subaddr);
        return false;
    }
    return true;
}

bool SDOWriter::start_write(uint value)
{
    if(!req || write_status!=ST_READY) {
        logMotors.fmt("write to 0x%04X.%02X impossible",m_addr,m_subaddr);
        return false;
    }
    m_value = value;
    write_status = ST_NEW;
    return true;
}

bool SDOWriter::check_write()
{
    if(!req) {
        return false;
    }

    ec_request_state_t state;

    if(write_status==ST_NEW) {
        state = ecrt_sdo_request_state(req);
        if(state == EC_REQUEST_BUSY) {
            return false;
        }
        count = 0;
        write_status = ST_BUSY;
        switch(bytesize) {
        case 4:
            EC_WRITE_U32(ecrt_sdo_request_data(req), uint32_t(m_value));
            break;
        case 2:
            EC_WRITE_U16(ecrt_sdo_request_data(req), uint16_t(m_value));
            break;
        case 1:
            EC_WRITE_U8(ecrt_sdo_request_data(req), uint8_t(m_value));
            break;
        default:
            write_status = ST_READY;
            return true;
        }
        logMotors.fmt("write %u(0x%X) to 0x%04X.%02X %s",m_value,m_value,m_addr,m_subaddr,"requested");
    }

    if(write_status==ST_READY) return true;

    state = ecrt_sdo_request_state(req);

    const char *errtxt = "ERROR(UNKNOWN)";
    bool ret = false;
    switch (state) {
    case EC_REQUEST_UNUSED: // request was not used yet
        state = EC_REQUEST_BUSY;
        ecrt_sdo_request_write(req);
        errtxt = "ERROR(UNUSED)";
        break;
    case EC_REQUEST_BUSY:
        errtxt = "ERROR(BUSY)";
        break;
    case EC_REQUEST_SUCCESS:
        write_status = ST_READY;
        ret = true;
        ecrt_sdo_request_write(req);
        logMotors.fmt("write %u(0x%X) to 0x%04X.%02X OK",m_value,m_value,m_addr,m_subaddr);
        break;
   case EC_REQUEST_ERROR:
        count++;
        ecrt_sdo_request_write(req);
        errtxt = "ERROR(WRITE)";
        break;
    }

    if(!ret) {
        if(count>100) {
            write_status = ST_READY;
            logMotors.fmt("write %u(0x%X) to 0x%04X.%02X ... %s, RESET",m_value,m_value,m_addr,m_subaddr,errtxt);
        } else {
            logMotors.fmt("write %u(0x%X) to 0x%04X.%02X ... %s",m_value,m_value,m_addr,m_subaddr,errtxt);
        }
    }
    return ret;
}
