from sheeter2020.servo_pb2 import ServoCommandBatch, ServoCommand
import nnpy
from sys import argv

host = "10.1.2.149"

if len(argv) != 2:
    print("Usage: send_servo_req.py <action>")
    exit(1)

action = None

if argv[1].lower() == "reboot":
    action = ServoCommand.REBOOT
if argv[1].lower() == "reset":
    action = ServoCommand.RESET
if argv[1].lower() == "turn_on":
    action = ServoCommand.TURN_ON
if argv[1].lower() == "turn_off":
    action = ServoCommand.TURN_OFF
if argv[1].lower() == "write_parameters":
    action = ServoCommand.WRITE_PARAMETERS
if argv[1].lower() == "led":
    action = ServoCommand.SET_DIGITAL_OUTPUTS


s = nnpy.Socket(nnpy.AF_SP, nnpy.REQ)
s.connect("tcp://%s:8081" % host)


for i in range(4):
    cmd = ServoCommandBatch(statuses=[
        ServoCommand(servo_id=i,
                     target_position=20,
                     command=action,
                     digital_out={"out1": True, "out2": True, "out3": True})
    ])
    print(cmd)
    s.send(cmd.SerializeToString())
    print(s.recv())
