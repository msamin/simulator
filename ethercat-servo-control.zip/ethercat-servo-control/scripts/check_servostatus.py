from sheeter2020 import servo_pb2
import nnpy
import sys

host = "10.1.8.32"

s = nnpy.Socket(nnpy.AF_SP, nnpy.SUB)
s.connect("tcp://%s:8080" % host)
s.setsockopt(nnpy.SUB, nnpy.SUB_SUBSCRIBE, "")

status = servo_pb2.ServoStatusBatch()
status.ParseFromString(str(s.recv()))

if len(sys.argv) == 2:
    print(str(status.statuses[int(sys.argv[1])]))
else:
    print(str(status))
