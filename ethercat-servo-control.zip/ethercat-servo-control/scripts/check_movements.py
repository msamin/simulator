from sheeter2020 import movements_pb2
import nnpy

host = "10.1.2.149"

s = nnpy.Socket(nnpy.AF_SP, nnpy.SUB)
s.connect("tcp://%s:8082" % host)
s.setsockopt(nnpy.SUB, nnpy.SUB_SUBSCRIBE, "")

movements = movements_pb2.PlannedMovements()
movements.ParseFromString(str(s.recv()))

print(str(movements))
