from sheeter2020.servo_pb2 import ServoCommandBatch, ServoCommand
import nnpy
from sys import argv
from itertools import cycle
from time import sleep

host = "10.1.2.149"

s = nnpy.Socket(nnpy.AF_SP, nnpy.REQ)
s.connect("tcp://%s:8081" % host)


for p in cycle([10, 500]):
    cmds = ServoCommandBatch(commands=[
        ServoCommand(servo_id=3,
                     target_position=p,
                     command=ServoCommand.SET_POSITION)
    ])
    s.send(cmds.SerializeToString())
    s.recv()
    sleep(3)
