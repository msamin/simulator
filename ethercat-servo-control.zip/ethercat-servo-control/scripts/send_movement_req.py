from sheeter2020 import movements_pb2
import nnpy

host = "10.1.2.149"

s = nnpy.Socket(nnpy.AF_SP, nnpy.REQ)
s.connect("tcp://%s:8083" % host)

m1 = movements_pb2.Movement(type=movements_pb2.Movement.COMPASS_REDUCTION_TRIGGER, velocity=1000, gapSize=25)
m2 = movements_pb2.Movement(type=movements_pb2.Movement.COMPASS_REDUCTION_TRIGGER, velocity=-1000, gapSize=35)
m3 = movements_pb2.Movement(type=movements_pb2.Movement.COMPASS_REDUCTION_TRIGGER, velocity=1000, gapSize=25)
m4 = movements_pb2.Movement(type=movements_pb2.Movement.COMPASS_REDUCTION_TRIGGER, velocity=-1000, gapSize=35)
movements = movements_pb2.MovementRequest(type=movements_pb2.MovementRequest.REPLACE, movement=[m1, m2, m3, m4])
# import pdb;pdb.set_trace()
s.send(movements.SerializeToString())
print(s.recv())
