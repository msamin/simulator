from sheeter2020 import servo_pb2
import nnpy
import sys
from time import time
from google.protobuf.json_format import MessageToJson
import os


if len(sys.argv) == 2:
    host = sys.argv[1]
else:
    host = "10.1.2.149"

s = nnpy.Socket(nnpy.AF_SP, nnpy.SUB)
s.connect("tcp://%s:8080" % host)
s.setsockopt(nnpy.SUB, nnpy.SUB_SUBSCRIBE, "")

status = servo_pb2.ServoStatusBatch()

for i in range(9999):
    logfile = "log.%s.txt" % i

    if os.path.exists(logfile):
        continue
    else:
        break
try:
    with open(logfile, "wt") as f:
        print("Writing to file %s!" % logfile)
        while True:
            status.Clear()
            status.ParseFromString(str(s.recv()))
            f.write(MessageToJson(status).replace("\n", "").replace(" ", ""))
            f.write("\n")
            f.flush()
except KeyboardInterrupt:
    print("Don't forget to zip the file, it is very compressible!")

