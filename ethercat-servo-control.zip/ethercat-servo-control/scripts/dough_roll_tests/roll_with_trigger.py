from sheeter2020.servo_pb2 import ServoCommandBatch, ServoCommand
from sheeter2020.servo_pb2 import ServoStatusBatch, ServoStatus
from sheeter2020.servo_pb2 import ServoReplyBatch, ServoReply
import nnpy
from itertools import cycle
from threading import Thread, Event
from time import sleep
from movements import gapsize, drive

host = "10.1.2.149"

s = nnpy.Socket(nnpy.AF_SP, nnpy.REQ)
s.connect("tcp://%s:8081" % host)

thicknesses = cycle(range(10, 2, -1))
velocity = 400

gap_reached = Event()
laser_trigger = Event()


def get_status_updates():
    sub = nnpy.Socket(nnpy.AF_SP, nnpy.SUB)
    sub.connect("tcp://%s:8080" % host)
    sub.setsockopt(nnpy.SUB, nnpy.SUB_SUBSCRIBE, "")
    status = ServoStatusBatch()

    last_trigger = False
    last_gap = False

    while True:
        status.Clear()
        status.ParseFromString(str(sub.recv()))
        if status.statuses[3].target_position_reached and not last_gap:
            gap_reached.set()
            print("just reached: %s" % status.statuses[3].position)
        last_gap = status.statuses[3].target_position_reached

        if not status.statuses[1].digital_in.mon5 and last_trigger:
            laser_trigger.set()

        last_trigger = status.statuses[1].digital_in.mon5


def ok():
    res = ServoReplyBatch.FromString(s.recv())
    for r in res.replies:
        assert r.status == ServoReply.OK


tr = Thread(target=get_status_updates)
tr.setDaemon(True)
tr.start()

velocity = 1000

for t in thicknesses:
    print("Thickness: %s" % t)
    s.send(gapsize(t).SerializeToString())
    ok()
    print("waiting for gap to close...")
    gap_reached.wait()
    gap_reached.clear()
    s.send(drive(velocity).SerializeToString())
    ok()
    print("waiting for trigger")
    laser_trigger.wait()
    laser_trigger.clear()

    velocity *= -1

    s.send(drive(0).SerializeToString())
    ok()
    sleep(1)
