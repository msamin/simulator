#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sheeter2020.servo_pb2 import ServoCommandBatch, ServoCommand
idx = {"left": 0, "drum": 1, "right": 2, "gap": 3}


def drive(velocity):
    cmds = [ServoCommand(servo_id=idx[motor],
                         target_velocity=velocity,
                         command=ServoCommand.SET_VELOCITY)
            for motor in ["left", "drum", "right"]]

    return ServoCommandBatch(commands=cmds)



def gapsize(gap_mm):
    return ServoCommandBatch(commands=[
        ServoCommand(servo_id=idx["gap"],
                     target_position=gap_mm,
                     command=ServoCommand.SET_POSITION)]
    )
