#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model

x = np.array([4.0, 38.85]).reshape(-1, 1)
y = np.array([-629629126, -1108638924]).reshape(-1, 1)

regr = linear_model.LinearRegression()
regr.fit(x, y)

print("m=%s" % round(regr.coef_[0][0]))
print("b=%s" % round(regr.predict(0)[0][0]))

plt.scatter(x, y, color='black')
plt.plot(x, regr.predict(x), color='blue', linewidth=3)


plt.show()
