from sheeter2020 import servo_pb2
import nnpy
import sys
from time import time
import matplotlib.pyplot as plt
from threading import Thread
from matplotlib import style
style.use('fivethirtyeight')

fig = plt.figure()
ax1 = fig.add_subplot(2, 1, 1)
ax2 = fig.add_subplot(2, 1, 2)


torques = []
positions = []
target_positions = []
ts = []
t0 = time()

if len(sys.argv) >= 2:
    host = sys.argv[1]
else:
    host = "10.1.2.149"

if len(sys.argv) >= 3:
    servo_idx = sys.argv[2]
else:
    servo_idx = 0

s = nnpy.Socket(nnpy.AF_SP, nnpy.SUB)
s.connect("tcp://%s:8080" % host)
s.setsockopt(nnpy.SUB, nnpy.SUB_SUBSCRIBE, "")


def rcv_data():
    global ts
    global torques
    global positions
    global target_positions
    status = servo_pb2.ServoStatusBatch()
    idx = 0
    while True:
        idx += 1
        s.recv()
        if idx % 10:
            continue

        status.Clear()
        status.ParseFromString(str(s.recv()))

        torque = status.statuses[3].torque
        position = status.statuses[3].position
        target_pos = status.statuses[3].target_pos

        ts.append(time() - t0)
        positions.append(position)
        torques.append(torque)
        target_positions.append(target_pos)

        if len(ts) > 300:
            torques = torques[1:]
            positions = positions[1:]
            target_positions = target_positions[1:]
            ts = ts[1:]


t = Thread(target=rcv_data)
t.setDaemon(True)
t.start()

while True:
    ax1.clear()
    ax1.plot(ts, torques)
    ax2.clear()
    ax2.plot(ts, positions)
    ax2.plot(ts, target_positions, "r--")
    plt.draw()
    plt.pause(0.02)
