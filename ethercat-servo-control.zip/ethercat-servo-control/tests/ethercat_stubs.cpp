#include <cstdint>
struct ec_slave_config;

void write_to_flash(ec_slave_config*) {};
void configure_common_sdos(ec_slave_config*){};
void configure_for_position_control(ec_slave_config*){};
void configure_for_velocity_control(ec_slave_config*){};
void reboot(ec_slave_config*){};
