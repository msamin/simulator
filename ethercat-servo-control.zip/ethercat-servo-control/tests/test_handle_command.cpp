#include <nanomsg_loop.hpp>
#include <sheeter2020/servo.pb.h>
#include <assert.h>
#include <iostream>
#include <cstdlib>

#include <sdo_writer.h>
SDOWriter reqAccBelts[2];
SDOWriter reqDecBelts[2];
SDOWriter reqAccDrum;
SDOWriter reqDecDrum;

#define SYSVARIABLE
#include <systemconfig.h>

namespace settings {
    bool do_invert_trigger = true;
    int trigger_pin = 7;
    int trigger_drive = 0;
}

uint32_t servo_sync_counter = 0;
int rotate_for_cleaning_step = 0; // 0=unused 1=request 2=busy
uint32_t rotate_for_cleaning_ticks = 0;

namespace SystemConfig {
    void SetBeltSpeedFactors(int, int) {}
}

using namespace std;

void test_noop() {
    // Send empty request, no error should occur
    cout << "test_noop...";
    sheeter2020::ServoCommandBatch requests;
    sheeter2020::ServoReplyBatch replies;

    //handle_command(requests, replies);
    cout << "PASS" << endl;
}
/*
void test_set_velocity() {
    // Set velocity for all servos - ethercat command data should contain new velocity
    cout << "test_set_velocity...";
    sheeter2020::ServoCommandBatch requests;
    sheeter2020::ServoReplyBatch replies;

    requests.Clear();
    for (int idx=0; idx < 4; idx++) {
        auto c = requests.add_commands();
        c->set_servo_id(idx);
        c->set_target_velocity(200);
        c->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
    }

    handle_command(requests, replies);
    for (int idx=0; idx < 4; idx++) {
        assert(command_data[idx].target_velocity == 200 * 100000);
        assert(replies.replies().Get(idx).status() == sheeter2020::ServoReply::OK);
    }
    cout << "PASS" << endl;
}

void test_invalid_velocity() {
    // Request invalid velocity for all servos, response should be ERROR
    cout << "test_set_velocity...";
    sheeter2020::ServoCommandBatch requests;
    sheeter2020::ServoReplyBatch replies;
    requests.Clear();
    for (int idx=0; idx < 4; idx++) {
        auto c = requests.add_commands();
        c->set_servo_id(idx);
        c->set_target_velocity(-9999999);
        c->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
    }

    handle_command(requests, replies);
    assert(replies.replies_size() == 4);
    for (int idx=0; idx < 4; idx++) {
        assert(replies.replies().Get(idx).status() == sheeter2020::ServoReply::ERROR);
    }
    cout << "PASS" << endl;
}
*/

int main() {
    char *trg_pin = std::getenv("TRIGGER_PIN");
    if(trg_pin) {
        bool inv = false;
        if(*trg_pin=='!') {inv=true; trg_pin++;}
        char *end = nullptr;
        int pin = std::strtol(trg_pin, &end, 10);
        if(end && *end==0) {
            //trigger_pin = pin;
            //do_invert_trigger = inv;
            //printf("settings::trigger_pin changed to %c%d\n", do_invert_trigger?'!':' ', trigger_pin);
        }
    }
    
    reqAccBelts[0].init32(ec::sc_0, 0x3021, 0x01);
    reqDecBelts[0].init32(ec::sc_0, 0x3021, 0x02);
    reqAccBelts[1].init32(ec::sc_2, 0x3021, 0x01);
    reqDecBelts[1].init32(ec::sc_2, 0x3021, 0x02);
    reqAccDrum.init32(ec::sc_1, 0x3021, 0x01);
    reqDecDrum.init32(ec::sc_1, 0x3021, 0x02);
    
    test_noop();
//    test_set_velocity();
//   test_invalid_velocity();
}
