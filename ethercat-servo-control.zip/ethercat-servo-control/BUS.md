=== Master 0, Slave 0 === Left Belt
Identity:
  Vendor Id:       0x00000083
  Product code:    0x000000b0
  Revision number: 0x00010001
  Serial number:   0x0000bedf
  Device name: R88D-1SN04H-ECT 200V/400W ServoDrive

PDO: control, velocity, torque, digital_in, digital_out
Mode: Sync Velocity Control

=== Master 0, Slave 1 === Drum driver?
Identity:
  Vendor Id:       0x00000083
  Product code:    0x000000b1
  Revision number: 0x00010001
  Serial number:   0x0000df71
  Device name: R88D-1SN08H-ECT 200V/750W ServoDrive

PDO: control, velocity, torque
Mode: Sync Velocity Control


=== Master 0, Slave 2 === Right Belt?
Identity:
  Vendor Id:       0x00000083
  Product code:    0x000000b0
  Revision number: 0x00010001
  Serial number:   0x0000bede
  Device name: R88D-1SN04H-ECT 200V/400W ServoDrive

PDO: control, velocity, torque
Mode: Sync Velocity Control


=== Master 0, Slave 3 === Gap adjust?
Identity:
  Vendor Id:       0x00000083
  Product code:    0x000000ae
  Revision number: 0x00010000
  Serial number:   0x00000000
  Device name: R88D-1SN01H-ECT 200V/100W ServoDrive

PDO: control, position, torque
Mode: Sync Pos Control
