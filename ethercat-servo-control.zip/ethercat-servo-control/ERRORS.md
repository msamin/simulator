# Motor Errors

This here is the beginning of a list of errors and their cause and resolution

| Error Code | Error Description | Possible Cause | Correction |
| ---------- | ----------------- | -------------- | ---------- |
| `0x8301` | EtherCAT State Change Error  | 1. servo-ctrl is not running<br/>2. The ethernet cable between HMI unit and servo drives is disconnected
| `0x1500` | Servo Drive Overheat
| `0x1600` | Overload Error<br/>The load ratio of servo drive or motor exceeded 100%
| `0x2100` | Encoder Communications Disconnection Error | The cable between servo drive and motor/encoder is damaged or disconnected
| `0x9101` | Command Error<br/>A mistake was made in using a command | 1. The servo-control crashed during a command<br/>2. You executed an ethercat command manually and incorrectly |
| `0x9505` | Motor Replacement Detected<br/>The connected motor is different from the motor that was connected the last time. | The motor was replaced | 1. Set the encoder type (`0x4510` `0x01`)<br/>2. Execute Absolute Encoder Setup (`0x4510` `0xF1`)<br/>3. Execute Motor Setup (`0x4410` `0xF1`)<br/>4. Execute motor reset (`0x2400` `0x01`) |