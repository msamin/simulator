#include "logmodel.h"
#include <QMutexLocker>

LogModel::LogModel(QObject *parent) : QStandardItemModel(parent)
{
    mux = new QMutex();
    //connect(this,SIGNAL(addLog(QString ts, QString txt)),SLOT(onLog(QString ts, QString txt)));
}

LogModel::~LogModel()
{
    delete mux;
}

QVariant LogModel::data(const QModelIndex &index, int role) const
{
    QMutexLocker lck(mux);

    if(role==Qt::UserRole+1) {
        int r = index.row();
        QModelIndex idx = this->index(r,1);
        role = Qt::DisplayRole;
        return QStandardItemModel::data(idx, role);
    } else {
        return QStandardItemModel::data(index, role);
    }
}

void LogModel::log(const QString& ts, const QString& txt)
{
    Q_UNUSED(ts);
    Q_UNUSED(txt);

    //emit addLog(ts, txt);
}

void LogModel::onLog(QString ts, QString txt)
{
    QMutexLocker lck(mux);

    if(rowCount()>10) {
        removeRow(0);
    }

    QList<QStandardItem*> row;
    QStandardItem *it;
    it = new QStandardItem(ts);
    row.append(it);
    it = new QStandardItem(txt);
    row.append(it);
    appendRow(row);
}
