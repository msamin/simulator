#ifndef SERVOSOMMANDSERVER_H
#define SERVOSOMMANDSERVER_H

#include <QObject>
#include <QSharedPointer>
#include <nanomsgsocket.h>
#include <sheeter2020/servo.pb.h>
#include <sheeter2020/movements.pb.h>
#include <chrono>
#include <QThread>


class ServoCommandServer : public QThread{
    Q_OBJECT
    Q_PROPERTY(bool turnedOn READ turnedOn WRITE setTurnedOn NOTIFY turnedOnChanged)
    Q_PROPERTY(double leftBeltSpeed READ leftBeltSpeed WRITE setLeftBeltSpeed NOTIFY leftBeltSpeedChanged)
    Q_PROPERTY(double rightBeltSpeed READ rightBeltSpeed WRITE setRightBeltSpeed NOTIFY rightBeltSpeedChanged)
    Q_PROPERTY(double drumDriveSpeed READ drumDriveSpeed WRITE setDrumDriveSpeed NOTIFY drumDriveSpeedChanged)
    Q_PROPERTY(double gapSize READ gapSize WRITE setGapSize NOTIFY gapSizeChanged)
    Q_PROPERTY(bool laserStatus READ laserStatus WRITE setLaserStatus NOTIFY laserStatusChanged)
    Q_PROPERTY(bool outFlourDuster READ outFlourDuster NOTIFY outFlourDusterChanged)
    Q_PROPERTY(bool outReelerMove READ outReelerMove NOTIFY outReelerMoveChanged)
    Q_PROPERTY(bool outReelerClose READ outReelerClose NOTIFY outReelerCloseChanged)
    Q_PROPERTY(bool transportBit READ transportBit WRITE setTransportBit NOTIFY transportBitChanged)
    Q_PROPERTY(unsigned int transportValue READ transportValue WRITE setTransportValue NOTIFY transportValueChanged)

signals:
    void turnedOnChanged(bool newValue);
    void leftBeltSpeedChanged(double newValue);
    void rightBeltSpeedChanged(double newValue);
    void drumDriveSpeedChanged(double newValue);
    void gapSizeChanged(double newValue);
    void laserStatusChanged(bool newValue);
    void outFlourDusterChanged(bool newValue);
    void outReelerMoveChanged(bool newValue);
    void outReelerCloseChanged(bool newValue);
    void transportBitChanged();
    void transportValueChanged();

public:
   explicit ServoCommandServer(QString host);
   virtual ~ServoCommandServer();
   void run() override;

   QString m_host = "127.0.0.1";
   bool turnedOn() const;
   void setTurnedOn(const bool value);
   void setTurnedOn(const bool value, const int servoId);

   bool transportBit() const {return transport_bit;}
   void setTransportBit(bool v);

   unsigned int transportValue() const {return transport_value;}
   void setTransportValue(unsigned int v);

   double leftBeltSpeed() const {return m_leftBeltSpeed;}
   void setLeftBeltSpeed(const double value);

   double rightBeltSpeed() const {return m_rightBeltSpeed;}
   void setRightBeltSpeed(const double value);

   double drumDriveSpeed() const {return m_drumDriveSpeed;}
   void setDrumDriveSpeed(const double value);

   double gapSize() const {return m_gapSize;}
   void setGapSize(const double value);

   bool laserStatus() const {return m_laserStatus;}
   void setLaserStatus(bool newValue);

   bool outFlourDuster() const {return m_outFlourDuster;}
   bool outReelerMove() const {return m_outReelerMove;}
   bool outReelerClose() const {return m_outReelerClose;}

   bool stop_button_pressed(const sheeter2020::ServoStatusBatch& newStatus);
   bool left_button_pressed(const sheeter2020::ServoStatusBatch& newStatus);
   bool right_button_pressed(const sheeter2020::ServoStatusBatch& newStatus);

   void send_servo_request(const sheeter2020::ServoCommandBatch& cmd);

   void handle_movement_requests(const sheeter2020::MovementRequest& moveRequest);
   void handle_servo_status(const sheeter2020::ServoStatusBatch &newStatus);

   Q_INVOKABLE void stopButtonPressed(bool pressed);
   Q_INVOKABLE void leftButtonPressed(bool pressed);
   Q_INVOKABLE void rightButtonPressed(bool pressed);

   Q_INVOKABLE QString infoline() const;

private slots:
   void onDataReceived(const QByteArray data);
   //void onMovementCmdDataReceived(const QByteArray data);
   sheeter2020::ServoStatusBatch updateStatus();
   void onLaserStatusChanged(bool newValue);

private:

   static QSharedPointer<NanomsgSocket> getCommandSocket(const char* host);
   static QSharedPointer<NanomsgSocket> getStatusSocket(const char* host);
   //static QSharedPointer<NanomsgSocket> getMovementCommandSocket(const char* host);
   //static QSharedPointer<NanomsgSocket> getMovementStatusSocket(const char* host);

   QSharedPointer<NanomsgSocket> m_socket;
   QSharedPointer<NanomsgSocket> m_statusSocket;
   //QSharedPointer<NanomsgSocket> m_movementStatusSocket;
   //QSharedPointer<NanomsgSocket> m_movementCmdSocket;

   std::map<int, bool> m_turnedOn;

   std::atomic<double> m_leftBeltSpeed;
   std::atomic<double> m_rightBeltSpeed;
   std::atomic<double> m_drumDriveSpeed;
   std::atomic<double> m_gapSize;
   std::atomic<bool> m_laserStatus;

   const double factorMotorSpeed = 1.0; //100000.0;
   const double factorMotorPosition = 0.25; //100000.0;
   const double nullMotorPosition = -11000.0;
   qint64 currMotorPosition[3][2];

   sheeter2020::PlannedMovements movements;
   std::chrono::time_point<std::chrono::steady_clock> timestamp_step_begin;
   std::chrono::time_point<std::chrono::steady_clock> timestamp_last_servo_status;

   std::pair<bool, sheeter2020::MovementRequest> pairMovementReq;

   bool stopButtonIsPressed;
   bool leftButtonIsPressed;
   bool rightButtonIsPressed;

   bool m_outReelerMove;
   bool m_outReelerClose;
   bool m_outFlourDuster;

   bool transport_bit;
   unsigned int transport_value;
};

#endif
