
#include <servocommandserver.h>
#include <sheeter2020/servo.pb.h>
#include <sheeter2020/servo.pb.cc>
#include <sheeter2020/movements.pb.h>
#include <recipe_interpreter.hpp>

#include <QMap>
#include <QDebug>
#include <QDateTime>
#include <stdlogger.h>

enum ServoMotor : uint32_t {
    LeftBelt = 0,
    DrumDrive = 1,
    RightBelt = 2,
    DrumGap = 3
};

static bool newMovementInd = false;

#define MPOS_ZERO 0
#define MPOS_NOW 1

ServoCommandServer::ServoCommandServer(QString host) : m_host(host)
{
    transport_bit = false;
    transport_value = 0;
    m_drumDriveSpeed = m_leftBeltSpeed = m_rightBeltSpeed = 0.0;
    m_gapSize = 0.0;
    for(int i=0; i<3; i++) {
        currMotorPosition[i][MPOS_ZERO] = currMotorPosition[i][MPOS_NOW] = QDateTime::currentMSecsSinceEpoch();
    }
    m_laserStatus = false;
    m_outReelerMove = false;
    m_outReelerClose = false;
    m_outFlourDuster = false;

    m_turnedOn[LeftBelt] = true;
    m_turnedOn[DrumDrive] = true;
    m_turnedOn[RightBelt] = true;
    m_turnedOn[DrumGap] = true;

    stopButtonIsPressed = false;
    leftButtonIsPressed = false;
    rightButtonIsPressed = false;

    m_socket = getCommandSocket("tcp://0.0.0.0:8081");
    m_statusSocket = getStatusSocket("tcp://0.0.0.0:8080");

    /*m_movementCmdSocket = getMovementCommandSocket("tcp://127.0.0.1:8083");
    m_movementStatusSocket = getStatusSocket("tcp://127.0.0.1:8082");*/
    QObject::connect(m_socket.data(), &NanomsgSocket::dataReceived, this, &ServoCommandServer::onDataReceived);
    //QObject::connect(m_movementCmdSocket.data(), &NanomsgSocket::dataReceived, this, &ServoCommandServer::onMovementCmdDataReceived);
}

ServoCommandServer::~ServoCommandServer()
{
    this->requestInterruption();
    this->wait();

}

uint16_t tick_servocmd_loop = 0;
void ServoCommandServer::run() {
    while (true) {
        tick_servocmd_loop++;
        if ( QThread::currentThread()->isInterruptionRequested() ) {
            return;
        }
        sheeter2020::ServoStatusBatch newStatus = updateStatus();
        handle_servo_status(newStatus);

        if(newMovementInd){
            if (pairMovementReq.first)
            {
                handle_movement_requests(pairMovementReq.second);
                qInfo() << "Handling the new movement done... ";
            }
            newMovementInd = false ;
        }
        msleep(100);

    }
}

bool ServoCommandServer::turnedOn() const {
    return m_turnedOn.at(LeftBelt) && m_turnedOn.at(DrumDrive) && m_turnedOn.at(RightBelt);// && m_turnedOn.at(DrumGap);
}

void ServoCommandServer::setTurnedOn(const bool value)
{
    m_turnedOn[LeftBelt] = value;
    m_turnedOn[DrumDrive] = value;
    m_turnedOn[RightBelt] = value;
    m_turnedOn[DrumGap] = value;
    emit turnedOnChanged(value);
}

void ServoCommandServer::setTurnedOn(const bool value, const int servoId)
{
    m_turnedOn[servoId] = value;
    emit turnedOnChanged(turnedOn());
}

void ServoCommandServer::setLeftBeltSpeed(const double newValue)
{
    m_leftBeltSpeed = newValue;
    currMotorPosition[0][MPOS_ZERO] = QDateTime::currentMSecsSinceEpoch();
    emit leftBeltSpeedChanged(newValue);
}

void ServoCommandServer::setRightBeltSpeed(const double value)
{
    m_rightBeltSpeed = value;
    currMotorPosition[2][MPOS_ZERO] = QDateTime::currentMSecsSinceEpoch();
    emit rightBeltSpeedChanged(value);
}

void ServoCommandServer::setDrumDriveSpeed(const double value)
{
    m_drumDriveSpeed = value;
    currMotorPosition[1][MPOS_ZERO] = QDateTime::currentMSecsSinceEpoch();
    emit drumDriveSpeedChanged(value);
}

void ServoCommandServer::setGapSize(const double value)
{
    m_gapSize = value;
    emit gapSizeChanged(value);
}

void ServoCommandServer::stopButtonPressed(bool pressed){
     if(pressed  != stopButtonIsPressed) stopButtonIsPressed = pressed;
}

void ServoCommandServer::leftButtonPressed(bool pressed){
     if(pressed != leftButtonIsPressed) leftButtonIsPressed = pressed;
}

void ServoCommandServer::rightButtonPressed(bool pressed){
     if(pressed != rightButtonIsPressed) rightButtonIsPressed = pressed;
}

bool ServoCommandServer::stop_button_pressed(const sheeter2020::ServoStatusBatch& newStatus) {
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++) {
        const sheeter2020::ServoStatus& s = newStatus.statuses(i);

        if (s.servo_id() == 1) {
            if (s.has_digital_in()) {
                const sheeter2020::DigitalInputs& in = s.digital_in();
                if (in.has_mon4()) {
                    pressed = in.mon4();
                }
            }
        }
    }
    return pressed;
}

bool ServoCommandServer::left_button_pressed(const sheeter2020::ServoStatusBatch& newStatus) {
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++) {
        const sheeter2020::ServoStatus& s = newStatus.statuses(i);

        if (s.servo_id() == 1) {
            if (s.has_digital_in()) {
                const sheeter2020::DigitalInputs& in = s.digital_in();
                if (in.has_mon2()) {
                    pressed = in.mon2();
                }
            }
        }
    }
    return pressed;
}

bool ServoCommandServer::right_button_pressed(const sheeter2020::ServoStatusBatch& newStatus) {
    bool pressed = false;
    for (int i = 0; i < newStatus.statuses_size(); i++) {
        const sheeter2020::ServoStatus& s = newStatus.statuses(i);

        if (s.servo_id() == 1) {
            if (s.has_digital_in()) {
                const sheeter2020::DigitalInputs& in = s.digital_in();
                if (in.has_mon3()) {
                    pressed = in.mon3();
                }
            }
        }
    }
    return pressed;
}


void ServoCommandServer::onDataReceived(const QByteArray data)  //for the servo command 8081
{
    sheeter2020::ServoCommandBatch cmds;
    sheeter2020::ServoReplyBatch replies;
    replies.Clear();
    sheeter2020::ServoReply &rep = *replies.add_replies();
    if (cmds.ParseFromArray(data.data(), data.size())) {

        //qInfo() << "--------------------------------- received ServoCommand" << QString::fromStdString(cmds.DebugString());

        for (int i=0; i < cmds.commands_size(); i++) {
            const sheeter2020::ServoCommand& req = cmds.commands(i);

            switch (req.command()) {
            case sheeter2020::ServoCommand_Command_NOTHING:
                rep.set_status(sheeter2020::ServoReply::OK);
                break;
            case sheeter2020::ServoCommand_Command_RESET:
                break;
            case sheeter2020::ServoCommand_Command_REBOOT:
                break;
            case sheeter2020::ServoCommand_Command_TURN_ON:
                if (req.has_servo_id()) {
                    setTurnedOn(true, req.servo_id());
                    rep.set_status(sheeter2020::ServoReply::OK);
                } else {
                    qWarning() << "TURN_ON without servo id";
                    rep.set_status(sheeter2020::ServoReply::ERROR);
                }
                break;
            case sheeter2020::ServoCommand_Command_STOP:
                if (req.has_servo_id()) {
                    switch (req.servo_id()) {
                    case ServoMotor::LeftBelt:
                        m_leftBeltSpeed = 0.0;
                        emit leftBeltSpeedChanged(0.0);
                        break;
                    case ServoMotor::RightBelt:
                        m_rightBeltSpeed = 0.0;
                        emit rightBeltSpeedChanged(0.0);
                        break;
                    case ServoMotor::DrumDrive:
                        m_drumDriveSpeed = 0.0;
                        emit drumDriveSpeedChanged(0.0);
                    }
                    rep.set_status(sheeter2020::ServoReply::OK);
                } else {
                    qWarning() << "STOP without servo id";
                    rep.set_status(sheeter2020::ServoReply::ERROR);
                }
                break;
            case sheeter2020::ServoCommand_Command_TURN_OFF:
                if (req.has_servo_id()) {
                    setTurnedOn(false, req.servo_id());
                    rep.set_status(sheeter2020::ServoReply::OK);
                } else {
                    qWarning() << "TURN_ON without servo id";
                    rep.set_status(sheeter2020::ServoReply::ERROR);
                }
                break;
            case sheeter2020::ServoCommand_Command_SET_VELOCITY:
                if (req.has_target_velocity()) {
                    switch (req.servo_id()) {
                    case ServoMotor::LeftBelt:
                        m_leftBeltSpeed = req.target_velocity() / factorMotorSpeed;
                        emit leftBeltSpeedChanged(m_leftBeltSpeed);
                        break;
                    case ServoMotor::DrumDrive:
                        m_drumDriveSpeed = req.target_velocity() / factorMotorSpeed;
                        emit drumDriveSpeedChanged(m_drumDriveSpeed);
                        break;
                    case ServoMotor::RightBelt:
                        m_rightBeltSpeed = req.target_velocity() / factorMotorSpeed;
                        emit rightBeltSpeedChanged(m_rightBeltSpeed);
                        break;
                    }
                    rep.set_status(sheeter2020::ServoReply::OK);
                } else {
                    qWarning() << "SET_VELOCITY without servo id";
                    rep.set_status(sheeter2020::ServoReply::ERROR);
                }
                break;
            case sheeter2020::ServoCommand_Command_SET_POSITION:
                if (req.has_target_position()) {
                    m_gapSize = req.target_position() / factorMotorPosition + nullMotorPosition;
                    qDebug("set gap size %d => %.5lf",req.target_position(),double(m_gapSize));
                    emit gapSizeChanged(m_gapSize);
                    rep.set_status(sheeter2020::ServoReply::OK);
                } else {
                    rep.set_status(sheeter2020::ServoReply::ERROR);
                }
                break;
            case sheeter2020::ServoCommand_Command_SET_ZERO_POINT:
                break;
            case sheeter2020::ServoCommand_Command_SET_DIGITAL_OUTPUTS:
                if(req.has_digital_out() && req.digital_out().has_out1() && m_outReelerMove != req.digital_out().out1()) {
                    m_outReelerMove = req.digital_out().out1();
                    emit outReelerMoveChanged(m_outReelerMove);
                }
                if(req.has_digital_out() && req.digital_out().has_out2() && m_outReelerClose != req.digital_out().out2()) {
                    m_outReelerClose = req.digital_out().out2();
                    emit outReelerCloseChanged(m_outReelerClose);
                }
                if(req.has_digital_out() && req.digital_out().has_out3() && m_outFlourDuster!=req.digital_out().out3()) {
                    m_outFlourDuster = req.digital_out().out3();
                    emit outFlourDusterChanged(m_outFlourDuster);
                }
                break;
            case sheeter2020::ServoCommand_Command_WRITE_PARAMETERS:
                break;
            }
        }
    } else {
        qWarning() << "Failed to parse ServoCommand message: " << data;
        rep.set_status(sheeter2020::ServoReply::ERROR);
    }

    //qInfo() << "--------------------------------- response:" << QString::fromStdString(replies.DebugString());

    QByteArray ar = QByteArray::fromStdString(replies.SerializeAsString());
    int nbytes = m_socket->sendData(ar);
}

void ServoCommandServer::send_servo_request(const sheeter2020::ServoCommandBatch& cmd) {
        qInfo() << "prepare to send  Servo request command is ... .. " << QString::fromStdString(cmd.DebugString());
        //if ( cmd.SerializeToArray(buf, cmd.ByteSize()) ) {

       onDataReceived(QByteArray::fromStdString(cmd.SerializeAsString()));

 }

void ServoCommandServer::handle_movement_requests(const sheeter2020::MovementRequest& moveRequest) {
        assert(moveRequest.has_type());
        QString movData = "UNKNOWN";
        int cnt = 0;
        switch (moveRequest.type()) {
        case sheeter2020::MovementRequest::CANCEL_ALL:
            // TODO: implement stop & clear movements.current
            movData = "CANCEL_ALL";
            movements.mutable_planned()->Clear();
            break;
        case sheeter2020::MovementRequest::CANCEL_ALL_BUT_CURRENT:
            movData = "CANCEL_ALL_BUT_CURRENT";
            movements.mutable_planned()->Clear();
            break;
        case sheeter2020::MovementRequest::REPLACE:
            cnt = moveRequest.movement_size();
            movData = QString("REPLACE: %1 movements").arg(cnt);
            movements.mutable_planned()->Clear();
            if(cnt>0) movements.mutable_planned()->MergeFrom(moveRequest.movement());
            break;
        case sheeter2020::MovementRequest::APPEND:
            cnt = moveRequest.movement_size();
            movData = QString("APPEND: %1 movements").arg(cnt);
            if(cnt>0) movements.mutable_planned()->MergeFrom(moveRequest.movement());
            break;
        case sheeter2020::MovementRequest::ADD_IF_EMPTY:
            cnt = moveRequest.movement_size();
            movData = QString("ADD_IF_EMPTY: %1 movements").arg(cnt);
            if(cnt>0) movements.mutable_planned()->MergeFrom(moveRequest.movement());
            break;
        }

        #define CASE_MV_TYPE(art) case art: typ = #art; typ.replace("::sheeter2020::Movement_MovementType_",""); break

        qInfo() << ("handle_movement_requests received request " + movData);
        for(int i=0; i<cnt; i++) {
            QString typ;
            switch(moveRequest.movement(i).type())
            {
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_CHANGE_SPEED_FACTORS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_UNUSED);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_CUTOMAT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_TRANSPORT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_CONTINUOUS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TIMER);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER);
            }
            qInfo() << QString("... %1) speed:%2 time:%3 gap:%4 flour:%5 type:%6")
                       .arg(i+1,2,10,QChar('0'))
                       .arg(moveRequest.movement(i).has_velocity()?moveRequest.movement(i).velocity():0.0,0,'f',3)
                       .arg(moveRequest.movement(i).has_duration()?moveRequest.movement(i).duration():0.0,0,'f',3)
                       .arg(moveRequest.movement(i).has_gapsize()?moveRequest.movement(i).gapsize():0.0,0,'f',3)
                       .arg((moveRequest.movement(i).has_flourduster()?moveRequest.movement(i).flourduster():false)?"YES":"NO")
                       .arg(typ)
                       ;
        }
        qInfo() << QString("now movements:");
        if(movements.has_current() && movements.mutable_current()) {
            QString typ;
            switch(movements.mutable_current()->type())
            {
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_CHANGE_SPEED_FACTORS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_UNUSED);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_CUTOMAT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_TRANSPORT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_CONTINUOUS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TIMER);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER);
            }
            qInfo() << QString("... %1) speed:%2 time:%3 gap:%4 flour:%5 type:%6 / current")
                       .arg(0,2,10,QChar('0'))
                       .arg(movements.mutable_current()->has_velocity()?movements.mutable_current()->velocity():0.0,0,'f',3)
                       .arg(movements.mutable_current()->has_duration()?movements.mutable_current()->duration():0.0,0,'f',3)
                       .arg(movements.mutable_current()->has_gapsize()?movements.mutable_current()->gapsize():0.0,0,'f',3)
                       .arg((movements.mutable_current()->has_flourduster()?movements.mutable_current()->flourduster():false)?"YES":"NO")
                       .arg(typ)
                       ;
        }
        cnt = movements.planned_size();
        for(int i=0; i<cnt; i++) {
            QString typ;
            switch(movements.planned(i).type())
            {
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_CHANGE_SPEED_FACTORS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_AUTOREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_UNUSED);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_MANUALREEL);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_CUTOMAT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_FINAL_TRANSPORT);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_CONTINUOUS);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TIMER);
            CASE_MV_TYPE(::sheeter2020::Movement_MovementType_COMPASS_REDUCTION_TRIGGER);
            }
            qInfo() << QString("... %1) speed:%2 time:%3 gap:%4 flour:%5 type:%6 / planned")
                       .arg(i+1,2,10,QChar('0'))
                       .arg(movements.planned(i).has_velocity()?movements.planned(i).velocity():0.0,0,'f',3)
                       .arg(movements.planned(i).has_duration()?movements.planned(i).duration():0.0,0,'f',3)
                       .arg(movements.planned(i).has_gapsize()?movements.planned(i).gapsize():0.0,0,'f',3)
                       .arg((movements.planned(i).has_flourduster()?movements.planned(i).flourduster():false)?"YES":"NO")
                       .arg(typ)
                       ;
        }
        //qInfo() << "handle_movement_requests now movements is \n" << QString::fromStdString(movements.DebugString());
    }


void ServoCommandServer::handle_servo_status(const sheeter2020::ServoStatusBatch &newStatus)
{

    bool stop_button_p = stop_button_pressed(newStatus);
    if (movements.has_current()) {
                const sheeter2020::Movement& cur = movements.current();
                assert(cur.has_type());
                switch (cur.type()) {
                case sheeter2020::Movement::COMPASS_REDUCTION_CONTINUOUS:
                    // we are currently in the progress of running with constant velocity
                    // this never automatically ends
                    // it only ends when someone presses the STOP button
                    if ((stop_button_p)) { // || (stopButtonIsPressed)) {
                        //stopButtonIsPressed = false;
                        movements.clear_current();
                        // request motor stop
                        sheeter2020::ServoCommandBatch stop_all_motors;
                        for (int i=0; i<4; i++) {
                            sheeter2020::ServoCommand* cmd_p = stop_all_motors.add_commands();
                            cmd_p->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
                            cmd_p->set_servo_id(i);
                            cmd_p->set_target_velocity(0);
                        }
                        send_servo_request(stop_all_motors);
                    }
                    // if the motor stopped moving for an external reason (emergency off)
                    // we also want to stop
                    // or if there is an error
                    break;
                case sheeter2020::Movement::COMPASS_REDUCTION_TRIGGER:
                    break;
                case sheeter2020::Movement::COMPASS_REDUCTION_TIMER:
                    assert(cur.has_duration());
                    int duration_ms = static_cast<int>(cur.duration() * 1000);
                    //if ((clock::now() - timestamp_step_begin) > std::chrono::milliseconds(duration_ms)) {
                    if ((std::chrono::steady_clock::now() - timestamp_step_begin) > std::chrono::milliseconds(duration_ms)) {
                        // time until end of step has passed
                        movements.clear_current();
                        // request motor stop
                        sheeter2020::ServoCommandBatch stop_all_motors;
                        for (int i=0; i<4; i++) {
                            sheeter2020::ServoCommand* cmd_p = stop_all_motors.add_commands();
                            cmd_p->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
                            cmd_p->set_servo_id(i);
                            cmd_p->set_target_velocity(0);
                        }
                        send_servo_request(stop_all_motors);
                    }
                    break;
                }
            } else {
                // currently, no movement is in progress
                // check whether movements are planned
                if ( movements.planned_size() > 0 ) {
                    qInfo() << "i m here 4  ..." ;
                    // take first planned and make it current
                    auto* list = movements.mutable_planned();
                    sheeter2020::Movement* newCur = nullptr;
                    list->ExtractSubrange(0, 1, &newCur);
                    assert(newCur != nullptr);
                    assert(newCur->has_type());
                    movements.set_allocated_current(newCur);

                    //timestamp_step_begin = std::chrono::clock::now();
                    timestamp_step_begin = std::chrono::steady_clock::now();

                    sheeter2020::ServoCommandBatch servo_command;

                    // initialize the movement
                    switch (newCur->type()) {
                    case sheeter2020::Movement::COMPASS_REDUCTION_CONTINUOUS:
                        assert( newCur->has_velocity() );
                        assert( newCur->has_gapsize() );
                        for (int i=0; i<4; i++) {
                            sheeter2020::ServoCommand* cmd = servo_command.add_commands();
                            cmd->set_servo_id(i);
                            if (i == 3) {
                                cmd->set_command(sheeter2020::ServoCommand::SET_POSITION);
                                cmd->set_target_position(newCur->gapsize());
                            } else {
                                cmd->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
                                //printf("machine-cont: set target_velocity = %.3lf => %d", newCur->velocity(), int(newCur->velocity()));
                                cmd->set_target_velocity(newCur->velocity());
                            }
                        }
                        break;
                    case sheeter2020::Movement::COMPASS_REDUCTION_TIMER:
                        assert( newCur->has_duration() );
                        assert( newCur->has_gapsize() );
                        assert( newCur->has_velocity() );
                        for (int i=0; i<4; i++) {
                            sheeter2020::ServoCommand* cmd = servo_command.add_commands();
                            cmd->set_servo_id(i);
                            if (i == 3) {
                                cmd->set_command(sheeter2020::ServoCommand::SET_POSITION);
                                cmd->set_target_position(newCur->gapsize());
                            } else {
                                cmd->set_command(sheeter2020::ServoCommand::SET_VELOCITY);
                                //printf("machine-time: set target_velocity = %.3lf => %d", newCur->velocity(), int(newCur->velocity()));
                                cmd->set_target_velocity(newCur->velocity());
                            }
                        }
                        break;
                    }
                    send_servo_request(servo_command);
                }
            }
}


/*void ServoCommandServer::onMovementCmdDataReceived(const QByteArray data){

    void* buf = nullptr;
    sheeter2020::MovementRequest mov_req;

    if (mov_req.ParseFromArray(data.data(), data.size())) {
        qInfo() << "onMovementCmdDataReceived Received Movement command " << QString::fromStdString(mov_req.DebugString());
        pairMovementReq = std::make_pair(true, mov_req);
    }else {
        //qInfo() << "onMovementCmdDataReceived Unable to parse MovementRequest!";

        pairMovementReq = std::make_pair(false, mov_req);
    }

    newMovementInd = true;
    sheeter2020::MovementResponse rep;
    rep.set_error(sheeter2020::MovementResponse::OK);
    m_movementCmdSocket->sendData(QByteArray::fromStdString(rep.SerializeAsString()));

}*/

sheeter2020::ServoStatusBatch ServoCommandServer::updateStatus()
{
    using namespace sheeter2020;

    //m_movementStatusSocket->sendData(QByteArray::fromStdString(movements.SerializeAsString()));

    ServoStatusBatch status;

    double ticksPerMillimeter = 362549097.0 / 1020.0;
    qint64 tpm,t = QDateTime::currentMSecsSinceEpoch();
    tpm = ticksPerMillimeter * 1600.0 / 4000.0 * (0.65*std::abs(m_drumDriveSpeed)/1125.0); // tick per millisecond scaled
    //d = t * tpm;

    // left belt
    ServoStatus* servo0 = status.add_statuses();
    servo0->set_servo_id(ServoMotor::LeftBelt);
    if (m_turnedOn.at(0)) {
        servo0->set_state(ServoStatus::RUNNING);
    } else {
        servo0->set_state(ServoStatus::STANDBY);
    }
    servo0->set_target_velocity(m_leftBeltSpeed * factorMotorSpeed);
    servo0->set_velocity(m_leftBeltSpeed * factorMotorSpeed);
    if(m_leftBeltSpeed!=0) {
        currMotorPosition[0][MPOS_NOW] = (m_leftBeltSpeed<0?-1:1) * (t-currMotorPosition[0][MPOS_ZERO]) * tpm;
    }
    servo0->set_position((qint32)currMotorPosition[0][MPOS_NOW]);
    servo0->set_position_raw((qint32)currMotorPosition[0][MPOS_NOW]);

    // drum drive
    ServoStatus* servo1 = status.add_statuses();
    servo1->set_servo_id(ServoMotor::DrumDrive);
    if (m_turnedOn.at(1) ) {
        servo1->set_state(ServoStatus::RUNNING);
    } else {
        servo1->set_state(ServoStatus::STANDBY);
    }
    servo1->set_target_velocity(m_drumDriveSpeed * factorMotorSpeed);
    servo1->set_velocity(m_drumDriveSpeed * factorMotorSpeed);
    servo1->set_target_velocity_raw(m_drumDriveSpeed * factorMotorSpeed);
    servo1->set_velocity_raw(m_drumDriveSpeed * factorMotorSpeed);
    if(m_drumDriveSpeed!=0) {
        currMotorPosition[1][MPOS_NOW] = (m_drumDriveSpeed<0?-1:1) * (t-currMotorPosition[1][MPOS_ZERO]) * tpm;
    }
    servo1->set_position((qint32)currMotorPosition[1][MPOS_NOW]);
    servo1->set_position_raw((qint32)currMotorPosition[1][MPOS_NOW]);
    if(servo1->mutable_digital_in()) {
        servo1->mutable_digital_in()->set_mon1(!turnedOn()); // false = cage is closed
        servo1->mutable_digital_in()->set_mon5(m_laserStatus);
        servo1->mutable_digital_in()->set_mon4(stopButtonIsPressed);
        servo1->mutable_digital_in()->set_mon2(leftButtonIsPressed);
        servo1->mutable_digital_in()->set_mon3(rightButtonIsPressed);
    }
    if(servo1->mutable_digital_out()) {
        servo1->mutable_digital_out()->set_out1(m_outReelerMove);
        servo1->mutable_digital_out()->set_out2(m_outReelerClose);
        servo1->mutable_digital_out()->set_out3(m_outFlourDuster);
    }
    servo1->mutable_ext_coupler()->set_digital_in_ext(transport_bit ? 1:0);
    servo1->mutable_ext_coupler()->set_analog_in_ext(transport_value);

    //else qWarning() << "no servo1.digital_in !!!";
    // TODO: set left/right/stop button, laser trigger, haspel

    // right belt
    ServoStatus* servo2 = status.add_statuses();
    servo2->set_servo_id(ServoMotor::RightBelt);
    if (m_turnedOn.at(2)) {
        servo2->set_state(ServoStatus::RUNNING);
    } else {
        servo2->set_state(ServoStatus::STANDBY);
    }
    servo2->mutable_digital_in()->set_mon3(!m_laserStatus);
    servo2->mutable_digital_in()->set_mon2(!m_laserStatus);
    servo2->set_target_velocity(m_rightBeltSpeed * factorMotorSpeed);
    servo2->set_velocity(m_rightBeltSpeed * factorMotorSpeed);
    //servo2->set_position(qint32(t));
    //servo2->set_position_raw(qint32(t));
    if(m_rightBeltSpeed!=0) {
        currMotorPosition[2][MPOS_NOW] = (m_rightBeltSpeed<0?-1:1) * (t-currMotorPosition[2][MPOS_ZERO]) * tpm;
    }
    servo2->set_position((qint32)currMotorPosition[2][MPOS_NOW]);
    servo2->set_position_raw((qint32)currMotorPosition[2][MPOS_NOW]);

    // drum gap
    ServoStatus* servo3 = status.add_statuses();
    servo3->set_servo_id(ServoMotor::DrumGap);
    if (m_turnedOn.at(3)) {
        servo3->set_state(ServoStatus::RUNNING);
    } else {
        servo3->set_state(ServoStatus::STANDBY);
    }
    servo3->set_target_pos((m_gapSize-nullMotorPosition) * factorMotorPosition);
    servo3->set_position((m_gapSize-nullMotorPosition) * factorMotorPosition);
    servo3->set_position_raw((m_gapSize-nullMotorPosition) * factorMotorPosition);

    logger.save("servo-status","%s",status.DebugString().c_str());
    m_statusSocket->sendData(QByteArray::fromStdString(status.SerializeAsString()));
    return status;
}



QSharedPointer<NanomsgSocket> ServoCommandServer::getCommandSocket(const char *host)
{
    static QMap<const char*, QWeakPointer<NanomsgSocket>> commandSocketMap;

    if (commandSocketMap.contains(host)) {
        // was already created before
        QWeakPointer<NanomsgSocket> ptr = commandSocketMap[host];
        return ptr.toStrongRef();
    } else {
        // create new
        QSharedPointer<NanomsgSocket> ptr = QSharedPointer<NanomsgSocket>(new NanomsgSocket(NanomsgSocket::REP));
        ptr->bind(host);
        commandSocketMap[host] = ptr.toWeakRef();
        return ptr;
    }
}

/*QSharedPointer<NanomsgSocket> ServoCommandServer::getMovementCommandSocket(const char *host)
{
    static QMap<const char*, QWeakPointer<NanomsgSocket>> commandSocketMap;

    if (commandSocketMap.contains(host)) {
        // was already created before
        QWeakPointer<NanomsgSocket> ptr = commandSocketMap[host];
        return ptr.toStrongRef();
    } else {
        // create new
        QSharedPointer<NanomsgSocket> ptr = QSharedPointer<NanomsgSocket>(new NanomsgSocket(NanomsgSocket::REP));
        ptr->bind(host);
        commandSocketMap[host] = ptr.toWeakRef();
        return ptr;
    }
}*/

QSharedPointer<NanomsgSocket> ServoCommandServer::getStatusSocket(const char *host)
{
    static QMap<const char*, QWeakPointer<NanomsgSocket>> statusSocketMap;

    if (statusSocketMap.contains(host)) {
        // was already created before
        QWeakPointer<NanomsgSocket> ptr = statusSocketMap[host];
        return ptr.toStrongRef();
    } else {
        // create new
        QSharedPointer<NanomsgSocket> ptr = QSharedPointer<NanomsgSocket>(new NanomsgSocket(NanomsgSocket::PUB));
        ptr->bind(host);
        statusSocketMap[host] = ptr.toWeakRef();
        return ptr;
    }
}

void ServoCommandServer::setLaserStatus(bool newValue)
{
    if(newValue != m_laserStatus) {
        m_laserStatus = newValue;
        emit laserStatusChanged(newValue);
    }
}

void ServoCommandServer::onLaserStatusChanged(bool newValue)
{
    Q_UNUSED(newValue);
}

/*QSharedPointer<NanomsgSocket> ServoCommandServer::getMovementStatusSocket(const char *host)
{
    static QMap<const char*, QWeakPointer<NanomsgSocket>> statusSocketMap;

    if (statusSocketMap.contains(host)) {
        // was already created before
        QWeakPointer<NanomsgSocket> ptr = statusSocketMap[host];
        return ptr.toStrongRef();
    } else {
        // create new
        QSharedPointer<NanomsgSocket> ptr = QSharedPointer<NanomsgSocket>(new NanomsgSocket(NanomsgSocket::PUB));
        ptr->bind(host);
        statusSocketMap[host] = ptr.toWeakRef();
        return ptr;
    }
}*/

extern volatile uint16_t tick_recipe_loop;
extern volatile uint16_t tick_movement_loop;
extern volatile uint16_t status_processing;
extern volatile uint16_t movement_processing;

QString ServoCommandServer::infoline() const
{
    return QString("%1/%2/%3/%4/%5").arg(tick_servocmd_loop,5,10,QChar('0')).arg(tick_recipe_loop,5,10,QChar('0')).arg(tick_movement_loop,5,10,QChar('0')).arg(status_processing,4,10,QChar('0')).arg(movement_processing,4,10,QChar('0'));
}

void ServoCommandServer::setTransportBit(bool v)
{
    if(v != transport_bit) {
        transport_bit = v;
        emit transportBitChanged();
    }
}

void ServoCommandServer::setTransportValue(unsigned int v)
{
    if(v != transport_value) {
        transport_value = v;
        emit transportValueChanged();
    }
}
