#ifndef LOGMODEL_H
#define LOGMODEL_H

#include <QStandardItemModel>
#include <QMutex>

class LogModel : public QStandardItemModel
{
    Q_OBJECT
public:
    explicit LogModel(QObject *parent = nullptr);
    ~LogModel();
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    void log(const QString& ts, const QString& txt);

signals:
    //void addLog(QString ts, QString txt);

private slots:
    void onLog(QString ts, QString txt);

private:
    QMutex *mux;
};

#endif // LOGMODEL_H
