#include "nanomsgsocket.h"

#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>
#include <nanomsg/reqrep.h>

#include <QDebug>
#include <QTimer>

NanomsgSocket::NanomsgSocket(const SocketType type, QObject *parent) :
    m_type(type), QObject(parent)
{
    switch (type) {
    case PUB:
        m_socket = nn_socket(AF_SP, NN_PUB);
        break;
    case SUB:
        m_socket = nn_socket(AF_SP, NN_SUB);
        break;
    case REQ:
        m_socket = nn_socket(AF_SP, NN_REQ);
        break;
    case REP:
        m_socket = nn_socket(AF_SP, NN_REP);
        break;
    }

    if (m_socket < 0) {
        qFatal("Couldn't create nanomsg socket!");
    }

    if (type == SUB) {
        int ret = nn_setsockopt(m_socket, NN_SUB, NN_SUB_SUBSCRIBE, "", 0);
        if (ret < 0)
            qWarning() << "Couldn't subscribe()!";
    }

    QObject::connect(&m_timer, &QTimer::timeout, this, &NanomsgSocket::checkForData);

    m_timer.setInterval(10); // milliseconds
    m_timer.start();
}

NanomsgSocket::~NanomsgSocket()
{
    int ret;
    for (int i = 0; i < m_endpoints.size(); i++) {
        ret = nn_shutdown(m_socket, m_endpoints.at(i));
        if (ret < 0) {
            qCritical("Could not shutdown endpoint!");
        }
    }
    ret = nn_close(m_socket);
    if (ret < 0) {
        qCritical("Could not shutdown endpoint!");
    }
}

void NanomsgSocket::bind(const char *host)
{
    int ret = nn_bind(m_socket, host);

    if (ret < 0) {
        qCritical() << QString("Couldn't bind to host %1!").arg(host);
    } else {
        m_endpoints.push_back(ret);
    }
}

void NanomsgSocket::connect(const char *host)
{
    int ret = nn_connect(m_socket, host);

    if (ret < 0) {
        qFatal("Couldn't connect to host %s!",host?host:"<NULL>");
    } else {
        m_endpoints.push_back(ret);
    }
}

int NanomsgSocket::sendData(const QByteArray &data)
{
    //qDebug(">>> sending servo status");
    int ret = nn_send(m_socket, data.data(), data.length(), 0);
    return ret;
}

void NanomsgSocket::checkForData()
{
    char* buf = nullptr;
    int ret = nn_recv(m_socket, &buf, NN_MSG, NN_DONTWAIT);
    if (ret > 0) {
        // QByteArray makes a deep copy
        QByteArray data(buf, ret);
        emit dataReceived(data);
        ret = nn_freemsg(buf);
        if (ret < 0) {
            qWarning() << "Message not freed successfully!";
        }
    } else {

    }
}
