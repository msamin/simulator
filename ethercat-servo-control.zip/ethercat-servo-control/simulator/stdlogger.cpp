#define NO_DEF_PRINTF
#include <stdlogger.h>
#include <fstream>
#include <algorithm>
#include <sys/stat.h>
#include <unistd.h>
#include <stdarg.h>
#include <sstream>

#include "logthread.h"
extern LogThread mainlogger;

#include <recipe_interpreter.hpp>

StdLogger::StdLogger()
{
    is_running = false;
    needExit = false;
    currList = 0;
    writtenBytes = 0;
    thread = nullptr;
}

StdLogger::~StdLogger()
{
    exit();
}

void StdLogger::init(const std::string &dirname, const std::string &subdirname, const std::string &basename)
{
    if(dirname.empty() || subdirname.empty() || basename.empty()) return;
}

void StdLogger::exit()
{
}

void StdLogger::add(int filehandle, const std::string &text)
{
    mainlogger.add(filehandle, QString::fromStdString(text));
}

void StdLogger::add(int filehandle, const std::string &text, const char *par, const char *suffix)
{
    std::string tmp = text;
    if(par) tmp += par;
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::add(int filehandle, const std::string &text, int par, const char *suffix)
{
    std::string tmp = text + std::to_string(par);
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::add(int filehandle, const std::string &text, unsigned int par, const char *suffix)
{
    std::string tmp = text + std::to_string(par);
    if(suffix!=nullptr) tmp += suffix;
    add(filehandle, tmp);
}

void StdLogger::save(const char *filenr, const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            mainlogger.save(filenr, buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::fmt(const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(1, buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::fmt(FILE *handle, const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(handle==stderr?2:1,buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::fmt(int lvl, const char* sfmt, ...)
{
    va_list lst, tmp;
    va_start(tmp,sfmt);
    va_copy(lst,tmp);
    int sz = std::vsnprintf(nullptr, 0, sfmt, tmp);
    if(sz>0) {
        try {
            char *buf = new char[sz+1];
            std::vsnprintf(buf, sz+1, sfmt, lst);
            va_end(tmp);
            va_end(lst);
            add(lvl,buf);
            delete[] buf;
            return;
        } catch(const std::bad_alloc& err) {
            if(err.what()) ::printf("%s",err.what());
        }
    }
    va_end(tmp);
    va_end(lst);
}

void StdLogger::renameFiles()
{
}

void StdLogger::start(void *ptr)
{
    if(ptr) {}
}

void StdLogger::run()
{
}
