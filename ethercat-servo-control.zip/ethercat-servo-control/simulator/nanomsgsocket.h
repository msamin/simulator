#ifndef NANOMSGSOCKET_H
#define NANOMSGSOCKET_H

#include <QObject>
#include <QVector>
#include <QByteArray>
#include <QTimer>

class NanomsgSocket : public QObject {
    Q_OBJECT

public:
    enum SocketType{
        PUB,
        SUB,
        REQ,
        REP
    };
    NanomsgSocket(const SocketType type, QObject* parent = 0);
    virtual ~NanomsgSocket();

    void bind(const char* host);
    void connect(const char* host);

signals:
    void dataReceived(QByteArray);
    void movementDataReceived(QByteArray);

public slots:
    int sendData(const QByteArray& data);

private slots:
    void checkForData();

private:
    int m_socket;
    QVector<int> m_endpoints;
    SocketType m_type;
    QTimer m_timer;
};

#endif
