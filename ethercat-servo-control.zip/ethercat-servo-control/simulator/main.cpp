#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QDebug>
#include <QCommandLineParser>
#include <QIcon>
#ifdef __x86_64__
#include <QTcpSocket>
#include <QHostAddress>
#endif
#include <servocommandserver.h>
#include "recipeinterpreterbridge.h"

#define SYSVARIABLE
#include <systemconfig.h>

#include "logthread.h"
LogThread mainlogger;
#include <stdlogger.h>
StdLogger logger;

static void myMessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    Q_UNUSED(context);
    //Q_UNUSED(msg);

    int tp = 1;
    switch(type) {
    case QtMsgType::QtInfoMsg: tp = LogThread::INFO; break;
    case QtMsgType::QtWarningMsg: tp = LogThread::WARN; break;
    case QtMsgType::QtCriticalMsg: tp = LogThread::ALERT; break;
    case QtMsgType::QtDebugMsg: tp = LogThread::DBG; break;
    case QtMsgType::QtFatalMsg: tp = LogThread::ALERT; break;
    }
    mainlogger.add(tp, msg);
}

static QString host = "127.0.0.1";

ServoCommandServer *servoRecipe = nullptr;
static QObject *register_servo_command(QQmlEngine *engine, QJSEngine *scriptEngine)
{
    Q_UNUSED(engine)
    Q_UNUSED(scriptEngine)

    return servoRecipe;
}

static RecipeInterpreterBridge *servoMovementsBridge = nullptr;
static QObject *register_servo_movements_bridge(QQmlEngine *engine, QJSEngine *scriptEngine)
{
    Q_UNUSED(engine)
    Q_UNUSED(scriptEngine)

    return servoMovementsBridge;
}

int main(int argc, char *argv[])
{
    // set SYSTEM CONFIGURATION
    SystemConfig::init_system_config();

    QGuiApplication app(argc, argv);

#ifdef __x86_64__not_always_working
    // assure only one app is running
    QTcpSocket appLock;
    if(!appLock.bind(QHostAddress::LocalHost,8085)) {
        QString err = appLock.errorString();
        qDebug("simulator already running or network error !!! (%s)",err.toLocal8Bit().constData());
        return 0;
    }
#endif

    qDebug("LOG file in %s/LOG",app.applicationDirPath().toLocal8Bit().constData());
    mainlogger.init(app.applicationDirPath(),"LOG");
    qInstallMessageHandler(myMessageOutput);
    servoRecipe = new ServoCommandServer(host);
    servoMovementsBridge = new RecipeInterpreterBridge();

    app.setApplicationDisplayName("Sheeter2020 Simulator");
    app.setOrganizationName("PreciBake");
    app.setWindowIcon(QIcon(":/pics/main_icon.svg"));

    /*QCommandLineParser parser;
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption targetHost(QStringList() << "i" << "target-ip", "nanomsg target host", "host");
    parser.addOption(targetHost);
    parser.process(app);
    if(parser.isSet(targetHost)) host = parser.value(targetHost);*/

    //qmlRegisterSingletonType<ServoCommand>("com.servo.command", 1, 0, "ServoCommand", register_servo_command);
    //qmlRegisterSingletonType<ServoCommand>("com.servo.status", 1, 0, "ServoStatus", register_servo_status);

    //qmlRegisterType<ServoCommandServer>("com.rondo.servos", 1, 0, "ServoCommand");
    qmlRegisterSingletonType<ServoCommandServer>("com.rondo.servos", 1, 0, "ServoCommand", register_servo_command);
    qmlRegisterSingletonType<RecipeInterpreterBridge>("com.servo.movements", 1, 0, "ServoMovements", register_servo_movements_bridge);

    QQmlApplicationEngine engine;
    //engine.rootContext()->setContextProperty("logModel", &mainlogger.mdl);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    servoRecipe->start();
    servoMovementsBridge->start();
    int ret = app.exec();
    servoMovementsBridge->stop();
    mainlogger.exit();
    qInstallMessageHandler(nullptr);

    return ret;
}
