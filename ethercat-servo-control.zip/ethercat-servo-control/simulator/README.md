# Rondo Sheeter2020 Simulator

You can use this GUI to completely replace the actual functional prototype.

The LEFT/STOP/RIGHT button currently don't work.

![](sheeter2020_simulator.png)
