/********************************************************************************
** Form generated from reading UI file 'simulatorform.ui'
**
** Created by: Qt User Interface Compiler version 5.9.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIMULATORFORM_H
#define UI_SIMULATORFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SimulatorForm
{
public:

    void setupUi(QWidget *SimulatorForm)
    {
        if (SimulatorForm->objectName().isEmpty())
            SimulatorForm->setObjectName(QStringLiteral("SimulatorForm"));
        SimulatorForm->resize(930, 62);

        retranslateUi(SimulatorForm);

        QMetaObject::connectSlotsByName(SimulatorForm);
    } // setupUi

    void retranslateUi(QWidget *SimulatorForm)
    {
        SimulatorForm->setWindowTitle(QApplication::translate("SimulatorForm", "Form", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SimulatorForm: public Ui_SimulatorForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIMULATORFORM_H
