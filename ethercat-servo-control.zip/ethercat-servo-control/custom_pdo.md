# Custom Tx/Rx Mappings
0x1600 1st Receive PDO Mapping
Sub 00 Number of Entries
Sub 0x1 - 0xA Output objects


0x1A00 1st transmit PDO Mapping
Sub 0x0 Number of Entries
Sub 0x1 - 0xA Input objects


# Enable Custom PDO Mapping:
## Setup RxPDO - data written to the servo
0x1600:0 = 4
0x1600:1 = 0x6040 0010 // control word
0x1600:2 = 0x60ff 0020 // target velocity
0x1600:3 = 0x607a 0020 // target position
0x1600:4 = 0x60fe 0020 // digital output

## Setup TxPDO - data read from the servo
0x1A00:0 = 8
0x1A00:1 = 0x6041 0010 // status word
0x1A00:2 = 0x603f 0010 // error code
0x1A00:3 = 0x606c 0020 // actual velocity
0x1A00:4 = 0x606b 0020 // target velocity
0x1A00:5 = 0x6064 0020 // actual position
0x1A00:6 = 0x6062 0020 // target position
0x1A00:7 = 0x6077 0010 // actual torque
0x1A00:8 = 0x60fd 0020 // digital input

## Enable RxPDO for writing to the servo
0x1c12:0 = 0
0x1c12:1 = 0x1600
0x1c12:0 = 1

## Enable TxPDO for reading from the servo
0x1c13:0 = 0
0x1c13:1 = 0x1A00
0x1c13:0 = 1

## Bash
See or run [custom_pdo.bash](custom_pdo.bash) to set the servos to the Custom PDO described in this doc.
