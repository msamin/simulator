#!/bin/bash

ethercat download -p0 0x2400 0x01 --type octet_string tesera
ethercat download -p1 0x2400 0x01 --type octet_string tesera
ethercat download -p2 0x2400 0x01 --type octet_string tesera
ethercat download -p3 0x2400 0x01 --type octet_string tesera
